﻿import json
import math
import random
import secrets
import shutil
import subprocess
import threading
import time
import re
import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog, messagebox, simpledialog, ttk
from typing import Any, Optional

import keyboard

# Optional mouse hotkey support (Mouse Button 4/5)
try:
    from pynput import mouse as _pynput_mouse  # global hook (Button.x1)
except Exception:
    _pynput_mouse = None
try:
    import mouse as _mouse_lib  # polling fallback
except Exception:
    _mouse_lib = None
try:
    import ctypes as _ct

    _GetAsyncKeyState = (
        getattr(getattr(_ct, "windll", None), "user32", None).GetAsyncKeyState
        if hasattr(getattr(_ct, "windll", None), "user32")
        else None
    )
except Exception:
    _GetAsyncKeyState = None
import contextlib
import io
import os
import sys
import tempfile
from datetime import datetime
from pathlib import Path

from config import (DISCORD_ALLOWED_GUILD_IDS, DISCORD_OWNER_ID,
                    DISCORD_TEXT_CHANNEL_ID, DISCORD_VOICE_CHANNEL_ID,
                    HOTKEY_PTT, MINECRAFT_LOG_PATH, OPENAI_MODEL_CHAT,
                    STREAM_STATUS_FILE, TTS_VOICE, TITANFALL2_AUTOPILOT,
                    TITANFALL2_AUTOVOICE, TITANFALL2_BRIEFING_CHANNEL_ID,
                    TITANFALL2_CALLSIGN, TITANFALL2_DISCORD_CHANNEL_ID,
                    TITANFALL2_ENABLED, TITANFALL2_IDLE_CHANNEL_ID,
                    TITANFALL2_LOG_PATH, TITANFALL2_REPORT_CHANNEL_ID,
                    TITANFALL2_TELEMETRY_FILE, VISION_CAMERA_INDEX,
                    VISION_CAMERA_NAME, VISION_SOURCE, VM_MUTE_HOTKEY,
                    VR_OVERLAY_ENABLED, VR_OVERLAY_PORT)

# Stable aliases to avoid any accidental shadowing in methods
_os = os
_sys = sys

try:
    import psutil  # type: ignore
except Exception:
    psutil = None


def _env_flag(name: str, default: str = "0") -> bool:
    try:
        return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}
    except Exception:
        return False


_SHOW_VOICEMEETER_UI = _env_flag("VOICEMEETER_UI_ENABLED", "0")
MOOD_POSITIVE = {
    "joy",
    "happiness",
    "fun",
    "glee",
    "amusement",
    "love",
    "adoration",
    "gratitude",
    "admiration",
    "supportive",
    "wonder",
    "curiosity",
    "playful",
}
MOOD_SHADOW = {
    "anger",
    "fear",
    "disgust",
    "envy",
    "sadness",
    "guilt",
    "shame",
    "awkward",
    "embarrassed",
    "disappointed",
    "overwhelmed",
    "cautious",
}
MOOD_CALM = {"comfortable", "calm", "relaxed", "acceptance", "forgiveness", "empathy"}
from core import mood, reflection, user_profile
from runtime import coreloop
from systems import audio, audio_sense, discord_bridge, gaming_bridge, notify
from systems import reloader as _reloader
from systems import stories, stt, therapy
from ui import theme
from ui.clock_window import ClockWindow
from ui.logs_window import LogsWindow
from ui.meter import RollingWaveform
from ui.tasks_window import TaskWindow

try:
    from ui.oscilloscope import NeonScopeRenderer, OscilloscopeWindow
except Exception:
    OscilloscopeWindow = None  # type: ignore
try:
    from ui.skin_designer import SkinDesigner
except Exception:
    SkinDesigner = None  # type: ignore
try:
    from PIL import Image, ImageOps, ImageTk  # type: ignore
except Exception:
    Image = ImageTk = ImageOps = None
try:
    import pystray  # type: ignore
except Exception:
    pystray = None


class BjorgsunUI:
    def __init__(self, dev_mode: bool | None = None):
        self.root = tk.Tk()
        self._dev_mode = (
            bool(dev_mode)
            if dev_mode is not None
            else _env_flag("UI_DEV_MODE") or _env_flag("BJORGSUN_DEV_MODE")
        )
        self._dev_panel = None
        self._tray_icon = None
        # Default to the new prime theme unless the user explicitly set UI_THEME
        if not os.getenv("UI_THEME"):
            try:
                theme.set_theme("prime")
            except Exception:
                pass
        try:
            coreloop.register_shutdown_hook(self._handle_core_shutdown)
        except Exception:
            pass
        try:
            self.root.protocol(
                "WM_DELETE_WINDOW", lambda: self._shutdown_app(confirm=False)
            )
        except Exception:
            pass
        try:
            theme.try_apply_custom_font(self.root)
        except Exception:
            pass
        try:
            self._main_geometry = self.root.geometry()
        except Exception:
            self._main_geometry = ""
        self._login_compact = False
        self.face_display = None
        # App icon (.ico) if available (also set taskbar icon on Windows)
        try:
            self._apply_app_icon()
        except Exception:
            pass
        try:
            theme.apply_ttk_theme(self.root)
        except Exception:
            pass
        self.root.title(
            "Bjorgsun-26 // Resonant Interface" + (" [DEV]" if self._dev_mode else "")
        )
        # Let Tk compute natural size; enforce a sensible minimum to avoid cutoff.
        # Auto-scale vs screen size (can override with UI_SCALE env)
        try:
            sw = self.root.winfo_screenwidth()
            sh = self.root.winfo_screenheight()
            try:
                env_scale = float(os.getenv("UI_SCALE", "0"))
            except Exception:
                env_scale = 0.0
            auto_scale = max(0.70, min(1.00, sh / 1080.0))
            self._ui_scale = env_scale if env_scale > 0 else auto_scale
            # Window size ~75% of screen, adjusted by scale
            base_w = int(sw * 0.78)
            base_h = int(sh * 0.76)
            w = max(820, int(base_w * self._ui_scale))
            h = max(520, int(base_h * self._ui_scale))
            self.root.geometry(f"{w}x{h}+60+40")
            self.root.minsize(int(720 * self._ui_scale), int(480 * self._ui_scale))
            self.root.attributes("-topmost", True)
        except Exception:
            pass
        self.root.configure(bg=theme.COLORS["bg"])
        enable_env = os.getenv("BJORGSUN_ENABLE_SKIN")
        disable_env = os.getenv("BJORGSUN_DISABLE_SKIN")
        if enable_env is not None:
            self._skin_enabled = enable_env.strip().lower() in {
                "1",
                "true",
                "yes",
                "on",
            }
        elif disable_env is not None:
            self._skin_enabled = disable_env.strip().lower() not in {
                "1",
                "true",
                "yes",
                "on",
            }
        else:
            self._skin_enabled = False  # default to vanilla look during prototyping
        if self._dev_mode:
            try:
                from ui.dev_panel import DevPanel

                self._dev_panel = DevPanel(self)
            except Exception:
                self._dev_panel = None
        self._skip_login = _env_flag("BJORGSUN_SKIP_LOGIN")
        self._skin_refs: list = []
        self._skin_base = os.path.join(os.path.dirname(__file__), "skins", "MySkin")
        self._skin_cache: dict[str, object] = {}
        self._launch_epoch = time.time()
        _root_dir = Path(__file__).resolve().parents[1]
        self._tablet_prompt_path = _root_dir / "data" / "tablet_prompt.json"
        self._tablet_choice_path = _root_dir / "data" / "tablet_mode_choice.json"
        self._tablet_status_path = _root_dir / "data" / "tablet_status.json"
        self._tablet_prompt_mtime = 0.0
        self._tablet_prompt_window: Optional[tk.Toplevel] = None  # type: ignore[name-defined]
        self.var_tablet_status = tk.StringVar(
            value="Tablet status: waiting for connection."
        )
        self._tablet_details_widget = None
        self._tablet_details_buffer = ""
        self.mood_face_label = None
        self.mood_summary_label = None
        self.discord_status_card = None
        self.health_labels: dict[str, tk.Label] = {}
        self._layout_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "data", "ui_layout.json")
        )
        self._layout_loaded = False
        self._skin_assets = self._load_skin_assets() if self._skin_enabled else {}
        self._hush_texture_base = None
        self._hush_texture_cache: dict[str, ImageTk.PhotoImage] = {}
        self._hush_texture_checked = False
        self._reflection_win = None
        self._dashboard_win = None
        self._family_win = None
        self._channel_win = None
        self._transcript_win = None
        try:
            self.root.after(2000, self._poll_tablet_prompt)
        except Exception:
            pass
        try:
            self.root.after(2500, self._schedule_tablet_status_refresh)
        except Exception:
            pass
        # Ensure window is visible and focused (especially when launched from an EXE)
        try:
            self.root.after(100, self._bring_to_front)
        except Exception:
            pass

        # Core state
        self._stop = False
        self.voice_enabled = _env_flag("UI_VOICE", "1")
        self.thinking = False
        self._scope = None
        self._scope_levels: list[float] = []
        self._tts_wave_cache: list[float] = []
        self._tts_progress = 0.0
        self._clock = None
        self._awake = False
        self._greeted = False
        # Mouse hotkey runtime flags
        self._mouse4_down = False
        self._mouse5_down = False
        self._mouse_listener = None
        # Global mic mute state (for UI only; VM is truth)
        self._vm_mic_muted = False
        self._settings_panel = None
        self._gaming_events_box = None
        self._stream_url_cached = ""
        self._gaming_status_job = None

        self._init_right_vars()
        self._init_notebook_style()

        # Layout containers: left (console+input) and right (toggles)
        try:
            self.root.grid_rowconfigure(1, weight=1)
            self.root.grid_rowconfigure(2, weight=0)
            self.root.grid_columnconfigure(0, weight=1)
        except Exception:
            pass

        self.top_bar = tk.Frame(self.root, bg=theme.COLORS["bg"])
        self.top_bar.grid(row=0, column=0, sticky="ew")

        self.content = tk.Frame(self.root, bg=theme.COLORS["bg"])
        self.content.grid(row=1, column=0, sticky="nsew")
        try:
            self.content.grid_columnconfigure(0, weight=1)
            self.content.grid_columnconfigure(1, weight=0)
            self.content.grid_rowconfigure(0, weight=1)
        except Exception:
            pass

        self.left = tk.Frame(self.content, bg=theme.COLORS["bg"])
        self.left.grid(row=0, column=0, sticky="nsew", padx=(12, 6), pady=(0, 10))

        # Right side: container (individual tabs handle their own scrolling)
        self.right_container = tk.Frame(self.content, bg=theme.COLORS["bg"])
        try:
            rpw = self._min_right_width()
        except Exception:
            rpw = 320
        self.right_container.configure(width=rpw)
        self.right_container.grid_propagate(False)
        self._right_grid_opts = {
            "row": 0,
            "column": 1,
            "sticky": "ns",
            "padx": (6, 12),
            "pady": (0, 10),
        }
        self.right_container.grid(**self._right_grid_opts)
        try:
            rpw_inner = max(240, rpw - 40)
        except Exception:
            rpw_inner = 260
        self.right_container.grid_rowconfigure(0, weight=0)
        self.right_container.grid_rowconfigure(1, weight=1)
        self.right_container.grid_rowconfigure(2, weight=0)
        self.right_container.grid_columnconfigure(0, weight=1)
        self.right = tk.Frame(
            self.right_container, bg=theme.COLORS["bg"], width=rpw_inner
        )
        self.right.grid(row=1, column=0, sticky="nsew")
        self.hush_bar = tk.Frame(self.right_container, bg=theme.COLORS["bg"])
        self.hush_bar.grid(row=2, column=0, sticky="ew", padx=(8, 12), pady=(0, 8))
        try:
            hush_img = self._get_hush_photo("off")
        except Exception:
            hush_img = None
        if hush_img is not None:
            try:
                self._hush_big = tk.Label(
                    self.hush_bar,
                    image=hush_img,
                    bg=theme.COLORS["bg"],
                    cursor="hand2",
                    borderwidth=0,
                    highlightthickness=0,
                )
                self._hush_big.image = hush_img
                self._hush_big.bind("<Button-1>", lambda _e: self._toggle_hush())
                self._hush_big.pack(side="right", padx=(0, 6), pady=(4, 2))
                self._hush_big_mode = "image"
                self._refresh_hush_button()
            except Exception:
                self._hush_big = None
        try:
            self.hush_bar.bind("<Configure>", lambda _e: self._refresh_hush_button())
        except Exception:
            pass
        if not getattr(self, "_hush_big", None):
            try:
                self._hush_big = self._make_big_button(
                    self.hush_bar,
                    text="HUSH",
                    color="#ff3ea5",
                    command=self._toggle_hush,
                )
                self._hush_big.pack(side="right", padx=(0, 6), pady=(4, 2))
                self._hush_big_mode = "canvas"
                self._refresh_hush_button()
            except Exception:
                self._hush_big = None
        try:
            self.right_container.bind(
                "<Configure>", lambda e: self._ensure_right_width()
            )
        except Exception:
            pass

        try:
            self.top_bar.grid_columnconfigure(0, weight=1)
            self.top_bar.grid_columnconfigure(1, weight=0)
            self.top_bar.grid_columnconfigure(2, weight=0)
            self.top_bar.grid_columnconfigure(3, weight=0)
            self.top_bar.grid_columnconfigure(4, weight=0)
            self.top_bar.grid_columnconfigure(5, weight=0)
        except Exception:
            pass

        # UI Elements
        header_left = tk.Frame(self.top_bar, bg=theme.COLORS["bg"])
        header_left.grid(row=0, column=0, sticky="w", padx=(8, 0))
        self.mood_label = tk.Label(
            header_left,
            text="🧠 Mood: Neutral",
            fg="#77ccff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 14, "bold"),
        )
        self.status_label = tk.Label(
            header_left,
            text="System Online",
            fg=theme.COLORS["ok"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 12),
        )
        self.route_label = tk.Label(
            header_left,
            text="Routing: Custom",
            fg="#aaaaaa",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 11),
        )
        self.mood_label.grid(row=0, column=0, sticky="w", padx=(4, 6), pady=(10, 4))
        self.status_label.grid(row=0, column=1, sticky="w", padx=(0, 6), pady=(10, 4))
        self.route_label.grid(row=0, column=2, sticky="w", padx=(0, 6), pady=(10, 4))

        # Live hearing LEDs (MIC / DESK) — larger and more visible
        try:
            led_w = max(38, int(54 * getattr(self, "_ui_scale", 1.0)))
            led_h = max(10, int(12 * getattr(self, "_ui_scale", 1.0)))
        except Exception:
            led_w, led_h = 54, 12
        hear_frame = tk.Frame(self.top_bar, bg=theme.COLORS["bg"])
        hear_frame.grid(row=0, column=2, sticky="e", padx=(6, 6))
        self.hear_mic = tk.Canvas(
            hear_frame,
            width=led_w,
            height=led_h,
            bg=theme.COLORS["bg"],
            highlightthickness=0,
        )
        self.hear_mic_bar = self.hear_mic.create_rectangle(
            0, 0, 0, led_h, fill="#0a2630", width=0
        )
        self.lbl_mic = tk.Label(
            hear_frame,
            text=" MIC",
            fg="#335a66",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
        )
        self.hear_desktop = tk.Canvas(
            hear_frame,
            width=led_w,
            height=led_h,
            bg=theme.COLORS["bg"],
            highlightthickness=0,
        )
        self.hear_desktop_bar = self.hear_desktop.create_rectangle(
            0, 0, 0, led_h, fill="#0a2630", width=0
        )
        self.lbl_desktop = tk.Label(
            hear_frame,
            text=" DESK",
            fg="#335a66",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
        )
        self.hear_desktop.grid(row=0, column=0, padx=(0, 2), pady=(8, 4))
        self.lbl_desktop.grid(row=1, column=0, padx=(0, 2), pady=(0, 4))
        self.hear_mic.grid(row=0, column=1, padx=(8, 2), pady=(8, 4))
        self.lbl_mic.grid(row=1, column=1, padx=(8, 2), pady=(0, 4))

        # Clock (live)
        self.clock_label = tk.Label(
            self.top_bar,
            text="--:--:--",
            fg="#c7ffe9",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 12),
        )
        self.clock_label.grid(row=0, column=3, sticky="e", padx=(6, 12), pady=(8, 2))

        self.settings_btn = tk.Button(
            self.top_bar,
            text="⚙",
            command=self._open_settings_panel,
            bg=theme.COLORS["bg"],
            fg="#9fe8ff",
            font=(theme.get_font_family(), 14, "bold"),
            relief="flat",
            bd=0,
            activebackground=theme.COLORS["panel"],
            activeforeground="#ffffff",
            highlightthickness=0,
            cursor="hand2",
        )
        self.settings_btn.grid(row=0, column=4, sticky="e", padx=(0, 6), pady=(6, 4))

        # Optional custom window chrome to match theme
        try:
            if os.getenv("UI_CUSTOM_TITLE", "0").strip().lower() in {
                "1",
                "true",
                "yes",
                "on",
            }:
                try:
                    self.root.overrideredirect(True)
                except Exception:
                    pass

                def _drag_start(e):
                    self._dragx, self._dragy = e.x_root, e.y_root

                def _drag_move(e):
                    dx, dy = e.x_root - self._dragx, e.y_root - self._dragy
                    self._dragx, self._dragy = e.x_root, e.y_root
                    x = self.root.winfo_x() + dx
                    y = self.root.winfo_y() + dy
                    self.root.geometry(f"+{x}+{y}")

                self.top_bar.bind("<Button-1>", _drag_start)
                self.top_bar.bind("<B1-Motion>", _drag_move)
                ctrl = tk.Frame(self.top_bar, bg=theme.COLORS["bg"])
                ctrl.grid(row=0, column=5, sticky="e", padx=(0, 6), pady=(6, 2))
                self._make_hud_button(
                    ctrl, "—", lambda: self.root.iconify(), width=34
                ).grid(row=0, column=0, padx=2)
                self._make_hud_button(
                    ctrl, "□", lambda: self.root.state("zoomed"), width=34
                ).grid(row=0, column=1, padx=2)
                self._make_hud_button(
                    ctrl, "✕", lambda: self._shutdown_app(confirm=False), width=34
                ).grid(row=0, column=2, padx=2)
        except Exception:
            pass

        # Controls toolbar moved to tabs; keep hidden unless UI_TOOLBAR=1
        self.toolbar = None
        try:
            if os.getenv("UI_TOOLBAR", "0").strip().lower() in {
                "1",
                "true",
                "yes",
                "on",
            }:
                self.toolbar = tk.Frame(self.root, bg=theme.COLORS["bg"])
                self.toolbar.grid(row=2, column=0, sticky="ew")
                self._make_hud_button(self.toolbar, "Tasks…", self._open_tasks).pack(
                    side="right", padx=(0, 6), pady=(6, 4)
                )
                self._make_hud_button(
                    self.toolbar, "Self‑Check", self._run_selfcheck
                ).pack(side="right", padx=(0, 6), pady=(6, 4))
                self._make_hud_button(self.toolbar, "Logs", self._open_logs).pack(
                    side="right", padx=(0, 6), pady=(6, 4)
                )
                self._make_hud_button(self.toolbar, "Sleep", self._sleep_toggle).pack(
                    side="right", padx=(0, 6), pady=(6, 4)
                )
                self._make_hud_button(
                    self.toolbar, "I'm Awake!", self._awake_brief
                ).pack(side="right", padx=(0, 6), pady=(6, 4))
                self._make_hud_button(
                    self.toolbar, "Reload", self._reload_systems
                ).pack(side="right", padx=(0, 6), pady=(6, 4))
                self._make_hud_button(self.toolbar, "Reboot", self._reboot_app).pack(
                    side="right", padx=(0, 6), pady=(6, 4)
                )
                self._make_hud_button(self.toolbar, "Diag", self._run_diagnostics).pack(
                    side="right", padx=(0, 6), pady=(6, 4)
                )
                self._make_hud_button(
                    self.toolbar, "Overlay", self._toggle_overlay
                ).pack(side="right", padx=(0, 6), pady=(6, 4))
                self._make_hud_button(
                    self.toolbar, "Pin", self._toggle_topmost_btn
                ).pack(side="right", padx=(0, 6), pady=(6, 4))
        except Exception:
            pass

        # Left stack holds scrolling console + indicators
        try:
            self.left.grid_rowconfigure(0, weight=1)
            self.left.grid_rowconfigure(1, weight=0)
            self.left.grid_columnconfigure(0, weight=1)
        except Exception:
            pass
        self.left_stack = tk.Frame(self.left, bg=theme.COLORS["bg"])
        self.left_stack.grid(row=0, column=0, sticky="nsew")
        try:
            self.left_stack.grid_columnconfigure(0, weight=1)
        except Exception:
            pass
        self._left_stack_row = 0

        # Decorative rails under the top bar
        self.rails = tk.Canvas(
            self.left_stack, height=6, bg=theme.COLORS["bg"], highlightthickness=0
        )
        try:
            self._stack_left_widget(self.rails, sticky="ew")
            self.rails.create_line(10, 3, 200, 3, fill=theme.COLORS["accent"], width=2)
            self.rails.create_line(210, 3, 260, 3, fill=theme.COLORS["peach"], width=2)
        except Exception:
            pass

        # HUD ring — organic, circular center piece (thinking/hearing)
        try:
            hud_h = int(112 * getattr(self, "_ui_scale", 1.0))
        except Exception:
            hud_h = 112
        self.hud_canvas = tk.Canvas(
            self.left_stack, height=hud_h, bg=theme.COLORS["bg"], highlightthickness=0
        )
        self._stack_left_widget(self.hud_canvas, sticky="ew")
        # Orb image assets (auto-enable if present, or via UI_ORB_IMAGES=1)
        env_orb = _os.getenv("UI_ORB_IMAGES", "").strip().lower()
        auto_orb = False
        try:
            base_assets = os.path.join(os.path.dirname(__file__), "assets")
            auto_orb = all(
                os.path.exists(os.path.join(base_assets, fn))
                for fn in ("idle.png", "speak.png", "sleep.png")
            )
        except Exception:
            auto_orb = False
        self._use_orb_images = env_orb in {"1", "true", "yes", "on"} or (
            env_orb == "" and auto_orb
        )
        self._orb_src = {}
        self._orb_cache = {}
        if self._use_orb_images:
            self._load_orb_assets()
        self._legacy_audio_panels = _env_flag("BJORGSUN_LEGACY_METERS", "0")

        # Console with soft frame
        self.console_frame = tk.Canvas(
            self.left_stack, height=10, bg=theme.COLORS["bg"], highlightthickness=0
        )
        self._stack_left_widget(
            self.console_frame, pady=(4, 2), sticky="nsew", weight=1
        )
        # Place a rounded backdrop and embed the Text within it
        self.console = tk.Text(
            self.console_frame,
            wrap="word",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["panel"],
            font=(theme.get_font_family(), 11),
            state="disabled",
            height=22,
        )

        def _layout_console(_evt=None):
            try:
                self.console_frame.delete("bg")
                w = int(self.console_frame.winfo_width() or 400)
                h = int(self.console_frame.winfo_height() or 200)
                theme.round_rect(
                    self.console_frame,
                    6,
                    4,
                    w - 6,
                    h - 6,
                    r=12,
                    fill=theme.COLORS["panel"],
                    outline="#0f2026",
                    tags=("bg",),
                )
                if not hasattr(self, "_console_window"):
                    self._console_window = self.console_frame.create_window(
                        12, 10, window=self.console, anchor="nw"
                    )
                self.console_frame.coords(self._console_window, 12, 10)
                self.console_frame.itemconfig(
                    self._console_window, width=max(50, w - 24), height=max(50, h - 22)
                )
            except Exception:
                pass

        self.console_frame.bind("<Configure>", _layout_console)

        # Input bar pinned to bottom and stylized
        self.input_bar = tk.Frame(self.left, bg=theme.COLORS["bg"])
        self.input_bar.grid(row=1, column=0, sticky="ew", pady=(6, 8))
        try:
            self.input_bar.grid_columnconfigure(0, weight=1)
        except Exception:
            pass
        self.input_canvas = tk.Canvas(
            self.input_bar, height=30, bg=theme.COLORS["bg"], highlightthickness=0
        )
        self.entry = tk.Entry(
            self.input_bar,
            fg="#ffffff",
            bg="#1a1f25",
            relief="flat",
            insertbackground=theme.COLORS["accent_glow"],
            font=(theme.get_font_family(), 12),
            highlightthickness=0,
            bd=0,
        )
        self._input_window = self.input_canvas.create_window(
            12, 15, window=self.entry, anchor="w"
        )
        self.input_canvas.grid(row=0, column=0, sticky="ew")

        def _redraw_input(_evt=None):
            try:
                self.input_canvas.delete("bg")
                w = int(self.input_canvas.winfo_width() or 200)
                h = int(self.input_canvas.winfo_height() or 30)
                theme.round_rect(
                    self.input_canvas,
                    2,
                    2,
                    w - 2,
                    h - 2,
                    r=10,
                    fill="#0f171c",
                    outline="#0f2026",
                    tags=("bg",),
                )
                self.input_canvas.coords(self._input_window, 16, h // 2)
                self.input_canvas.itemconfig(self._input_window, width=max(40, w - 28))
            except Exception:
                pass

        self.input_canvas.bind("<Configure>", _redraw_input)

        # “Thinking” visual indicator
        self.thinking_bar = tk.Canvas(
            self.left_stack, height=8, bg=theme.COLORS["panel"], highlightthickness=0
        )
        self.think_fill = self.thinking_bar.create_rectangle(
            0, 0, 0, 8, fill="#00ffff", width=0
        )
        self._stack_left_widget(self.thinking_bar, sticky="ew")

        # Waveform canvas (live during push-to-talk) — neon oscilloscope
        try:
            wav_h = int(68 * getattr(self, "_ui_scale", 1.0))
        except Exception:
            wav_h = 68
        self.wave_canvas = tk.Canvas(
            self.left_stack,
            height=wav_h,
            bg=theme.COLORS["bg_alt"],
            highlightthickness=0,
        )
        self._stack_left_widget(self.wave_canvas, sticky="ew", pady=(6, 0))
        try:
            acc, glow = theme.accent_for_mood(mood.get_mood())
        except Exception:
            acc, glow = theme.COLORS["accent"], theme.COLORS["accent_glow"]
        if self._legacy_audio_panels:
            self.waveform = RollingWaveform(
                self.wave_canvas, color_main=acc, color_glow=glow
            )
        else:
            self.waveform = None
            try:
                self.wave_canvas.grid_remove()
            except Exception:
                pass
        # Decorative HUD accent under waveform
        self.wave_hud = tk.Canvas(
            self.left_stack, height=8, bg=theme.COLORS["bg"], highlightthickness=0
        )
        self._stack_left_widget(self.wave_hud, sticky="ew")
        try:
            self.wave_hud.create_line(10, 4, 60, 4, fill=acc)
            self.wave_hud.create_line(70, 4, 90, 4, fill=theme.COLORS["accent2"])
        except Exception:
            pass
        if not self._legacy_audio_panels:
            try:
                self.wave_hud.grid_remove()
            except Exception:
                pass

        # ASCII face display (normal font)
        self.face_display = tk.Label(
            self.left_stack,
            text="(✿˶˘ ³˘)♡",
            fg="#9ef9ff",
            bg=theme.COLORS["bg"],
            font=("Consolas", 16, "bold"),
        )
        self._stack_left_widget(self.face_display, pady=(4, 0))
        if not self.var_face_display.get():
            self.face_display.grid_remove()

        # Embedded neon scopes (mic + TTS) always visible
        self.scope_embed = tk.Frame(self.left_stack, bg=theme.COLORS["bg"])
        self._stack_left_widget(self.scope_embed, sticky="ew", pady=(10, 4))
        try:
            lbl = tk.Label(
                self.scope_embed,
                text="Mic Spectrum",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9, "bold"),
            )
            lbl.pack(anchor="w")
        except Exception:
            pass
        self.scope_wave_canvas = tk.Canvas(
            self.scope_embed,
            height=int(90 * getattr(self, "_ui_scale", 1.0)),
            bg=theme.COLORS["panel"],
            highlightthickness=0,
        )
        self.scope_wave_canvas.pack(fill="x", pady=(0, 6))
        try:
            self._mini_scope_wave = NeonScopeRenderer(
                self.scope_wave_canvas, mode="wave", compact=True
            )
        except Exception:
            self._mini_scope_wave = None
        try:
            lbl2 = tk.Label(
                self.scope_embed,
                text="Voice Output",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9, "bold"),
            )
            lbl2.pack(anchor="w", pady=(0, 0))
        except Exception:
            pass
        self.scope_tts_canvas = tk.Canvas(
            self.scope_embed,
            height=int(86 * getattr(self, "_ui_scale", 1.0)),
            bg=theme.COLORS["panel"],
            highlightthickness=0,
        )
        self.scope_tts_canvas.pack(fill="x", pady=(0, 4))
        try:
            self._mini_scope_tts = NeonScopeRenderer(
                self.scope_tts_canvas, mode="tts", compact=True
            )
        except Exception:
            self._mini_scope_tts = None
        if not self._legacy_audio_panels:
            try:
                self.scope_embed.grid_remove()
            except Exception:
                pass

        # Lore + telemetry strip
        dash = tk.Frame(self.left_stack, bg=theme.COLORS["bg"])
        self._stack_left_widget(dash, sticky="ew", pady=(4, 2))
        try:
            self.lore_label = tk.Label(
                dash,
                text="",
                fg="#77ccff",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9),
                justify="left",
                anchor="w",
            )
            self.lore_label.pack(side="left", fill="x", expand=True)
        except Exception:
            self.lore_label = None
        telem_frame = tk.Frame(dash, bg=theme.COLORS["bg"])
        telem_frame.pack(side="right", padx=(6, 0))
        self.telemetry_cpu = tk.Label(
            telem_frame,
            text="CPU --%",
            fg="#9fffe8",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
        )
        self.telemetry_cpu.pack(anchor="e")
        self.telemetry_ram = tk.Label(
            telem_frame,
            text="RAM --%",
            fg="#c0f7a5",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
        )
        self.telemetry_ram.pack(anchor="e")
        self.telemetry_mods = tk.Label(
            telem_frame,
            text="Vision OFF • Awareness ON • Tasks ON",
            fg="#99d9ff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
        )
        self.telemetry_mods.pack(anchor="e")
        self._lore_entries = self._load_lore_entries()
        self._lore_index = 0
        self._tick_lore()
        self._tick_telemetry()

        # Mood panel + right-side tabs (Modules / Settings)
        self._build_mood_panel()
        self._build_tabs()
        self._load_layout_prefs()
        try:
            self._refresh_therapy_status()
        except Exception:
            pass
        try:
            self._refresh_story_status()
        except Exception:
            pass
        self._show_session_digest()

        self.entry.bind("<Return>", self._on_enter)
        try:
            self.entry.focus_set()
        except Exception:
            pass

        # Register to receive TTS progress events (for synchronized text)
        try:
            audio.register_progress_handler(self._on_tts_progress)
        except Exception:
            pass

        # Streaming state for synchronized text rendering
        self._stream_text = None
        self._stream_mark = None
        self._stream_active = False
        self._stream_prefix = ""
        self._routing_mode = "custom"  # 'discord' | 'private' | 'stream' | 'custom'
        # Heartbeat status line every 60 seconds
        try:
            self._tick_heartbeat()
        except Exception:
            pass

        # Main-thread UI updaters via Tk 'after' (thread-safe)
        self._tick_mood()
        self._update_health_panel()
        self._tick_thinking()
        self._tick_clock()
        # Heartbeat visual timestamp for orb pulse
        self._heartbeat_ts = 0.0
        self._last_hear_t_mic = 0.0
        # Optional system tray icon (pystray)
        try:
            self._start_tray_icon()
        except Exception:
            self._tray_icon = None
        self._last_hear_t_desktop = 0.0
        self._hear_mode = "mic"
        self._tick_hearing()
        # Start HUD ring animation
        self._hud_phase = 0.0
        self._tick_hud()

        # Responsive scaling based on window size
        self._scale_pending = False
        self.root.bind("<Configure>", self._on_resize)
        self._apply_scale(initial=True)
        # Overlay window handle and toggle in top bar
        self._overlay = None
        self._overlay_active = False
        try:
            self._make_hud_button(self.top_bar, "Overlay", self._toggle_overlay).pack(
                side="right", padx=(0, 6), pady=(8, 4)
            )
        except Exception:
            pass
        # VR overlay web server: big PTT button
        self._vr_ptt_hold = False
        self._vr_ptt_toggle = False
        try:
            if VR_OVERLAY_ENABLED:
                from systems import overlay_web as _ovr

                _ovr.set_ptt_callback(self._on_vr_ptt)
                if _ovr.start(VR_OVERLAY_PORT):
                    self.safe_log(
                        f"[VR Overlay] http://127.0.0.1:{VR_OVERLAY_PORT}/ — pin in XSOverlay for a big PTT button.",
                        "#77ccff",
                    )
        except Exception:
            self.safe_log("[VR Overlay] Failed to start.", "#ffaa00")
        # Register UI notification bridge
        try:
            notify.set_ui_callback(self._ui_notify)
        except Exception:
            pass

        # Register STT level callback for reactive waveform
        try:
            stt.set_level_callback(self._on_level)
        except Exception:
            pass

        # Voice hotkey monitor (global) — worker thread, UI-safe via after()
        threading.Thread(target=self._voice_hotkey_monitor, daemon=True).start()
        # Start optional mouse listener if HOTKEY_PTT is mouse4/mouse5
        try:
            self._start_mouse_listener_if_needed()
        except Exception:
            pass
        # Register global mic mute hotkey (VoiceMeeter)
        try:
            if (VM_MUTE_HOTKEY or "").strip():
                keyboard.add_hotkey(
                    VM_MUTE_HOTKEY, lambda: self.root.after(0, self._toggle_global_mic)
                )
                self.safe_log(
                    f"[VM] Global mic hotkey bound: {VM_MUTE_HOTKEY}", "#777777"
                )
        except Exception as e:
            self.safe_log(f"[VM] Hotkey bind failed: {e}", "#ffaa00")

        try:
            self.root.after(2000, self._refresh_discord_status)
        except Exception:
            pass

        # Boot message (no AI voice yet — authentication/wake happens in overlay)
        self.log("✅ Bjorgsun-26 Visual Interface Initialized.", "#55ff88")
        self.log("UI ready. Awaiting authentication…", "#77ccff")
        self.log(f"Hotkey: Hold {self._hotkey_label()} to talk.", "#00ffff")
        self.log("=== Prototype Launch // Bjorgsun-26 ===", "#ffaa00")
        self.log(
            "“Calm intelligence for crisis command, creator flow, and real-world crews.”",
            "#77ccff",
        )

        # Preboot login overlay
        self._awake = False
        self._build_login_overlay()

    def _bring_to_front(self):
        """Make the main window appear on top when launched."""
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
            # Respect UI_TOPMOST preference after the initial lift
            try:
                keep_top = os.getenv("UI_TOPMOST", "1").strip().lower() in {
                    "1",
                    "true",
                    "yes",
                    "on",
                }
                self.root.after(
                    1500, lambda: self.root.attributes("-topmost", keep_top)
                )
            except Exception:
                pass
        except Exception:
            pass

    def _load_skin_assets(self):
        if not self._skin_enabled:
            return {}
        assets = {}
        base = getattr(self, "_skin_base", "")
        if not base or not os.path.isdir(base):
            return assets
        mapping = [
            ("login_bg_raw", "bg.png", None),
            ("wake_primary", "wakebjorgsun.png", None),
            ("wake_usb", "wakefromusbmk.png", None),
            ("emergency", "Emergency.png", None),
            ("button_primary", "button.png", None),
        ]
        for key, filename, size in mapping:
            photo = self._load_skin_image(filename, size)
            if photo is not None:
                assets[key] = photo
        return assets

    def _load_skin_image(self, filename: str, size: tuple[int, int] | None = None):
        try:
            path = os.path.join(self._skin_base, filename)
            if not os.path.exists(path):
                return None
            if Image and ImageTk:
                img = Image.open(path)
                if size:
                    try:
                        img = img.resize(size, Image.LANCZOS)
                    except Exception:
                        img = img.resize(size)
                photo = ImageTk.PhotoImage(img)
            else:
                photo = tk.PhotoImage(file=path)
            self._skin_refs.append(photo)
            return photo
        except Exception:
            return None

    def _ensure_hush_texture(self):
        if getattr(self, "_hush_texture_checked", False):
            return
        self._hush_texture_checked = True
        if not (Image and ImageTk):
            return
        try:
            base_path = os.path.join(self._skin_base, "hush.png")
        except Exception:
            return
        if not os.path.exists(base_path):
            return
        try:
            self._hush_texture_base = Image.open(base_path).convert("RGBA")
            self._hush_texture_cache = {}
        except Exception:
            self._hush_texture_base = None

    def _desired_hush_size(self):
        try:
            if getattr(self, "hush_bar", None):
                w = int(self.hush_bar.winfo_width() or 0)
            else:
                w = 0
        except Exception:
            w = 0
        if w <= 40:
            try:
                w = max(160, int(self._min_right_width() * 0.6))
            except Exception:
                w = 200
        else:
            w = max(150, int(w * 0.92))
        h = max(60, int(w * 0.38))
        return (w, h)

    def _get_hush_photo(self, state: str):
        self._ensure_hush_texture()
        if self._hush_texture_base is None or not (Image and ImageTk and ImageOps):
            return None
        tint = "#ff3ea5" if state == "off" else "#26ffd0"
        size = self._desired_hush_size()
        key = f"hush:{state}:{tint}:{size[0]}x{size[1]}"
        photo = self._hush_texture_cache.get(key)
        if photo:
            return photo
        try:
            base = self._hush_texture_base.copy()
            if base.size != size:
                base = base.resize(size, Image.LANCZOS)
            alpha = base.split()[-1]
            gray = ImageOps.grayscale(base)
            colored = ImageOps.colorize(gray, black="#020407", white=tint)
            colored.putalpha(alpha)
            photo = ImageTk.PhotoImage(colored)
            self._skin_refs.append(photo)
            self._hush_texture_cache[key] = photo
            return photo
        except Exception:
            return None

    def _skin_asset(self, key: str):
        if not self._skin_enabled:
            return None
        try:
            return self._skin_assets.get(key)
        except Exception:
            return None

    def _apply_scaling_background(self, widget, filename: str, fallback):
        if not self._skin_enabled:
            widget.configure(bg=theme.COLORS["bg"])
            return
        if not (Image and ImageTk):
            widget.configure(image=fallback)
            widget.image = fallback
            return
        base_path = os.path.join(self._skin_base, filename)
        if not os.path.exists(base_path):
            widget.configure(image=fallback)
            widget.image = fallback
            return
        try:
            base_img = Image.open(base_path)

            def _resize(event):
                w = max(50, event.width)
                h = max(50, event.height)
                key = f"{filename}:{w}x{h}"
                if key in self._skin_cache:
                    photo = self._skin_cache[key]
                else:
                    photo = ImageTk.PhotoImage(base_img.resize((w, h), Image.LANCZOS))
                    self._skin_cache[key] = photo
                widget.configure(image=photo)
                widget.image = photo

            widget.bind("<Configure>", _resize)
        except Exception:
            widget.configure(image=fallback)
            widget.image = fallback

    def _toggle_skin_preview(self):
        try:
            self._skin_enabled = not getattr(self, "_skin_enabled", False)
            if self._skin_enabled:
                self._skin_assets = self._load_skin_assets()
                if not self._skin_assets:
                    self.safe_log(
                        "[Skin] No assets found in ui/skins/MySkin — staying vanilla.",
                        "#ffaa00",
                    )
                    self._skin_enabled = False
                else:
                    self.safe_log(
                        "[Skin] Custom skin enabled. Re-open overlays to preview.",
                        "#55ff88",
                    )
            else:
                self._skin_assets = {}
                self.safe_log(
                    "[Skin] Custom skin disabled. Using vanilla UI.", "#77ccff"
                )
        except Exception as e:
            self.safe_log(f"[Skin] Toggle failed: {e}", "#ff5555")

    # --------------------------------------------------------------------------
    # LOGGING / OUTPUT
    # --------------------------------------------------------------------------
    def log(self, text, color="#cccccc", face: str | None = None):
        """Print text to console."""
        try:
            text = self._scrub_sensitive(str(text))
        except Exception:
            pass
        if face:
            self._set_face_display(face)
        self.console.configure(state="normal")
        tags = ("color",)
        self.console.tag_configure("color", foreground=color)
        self.console.insert("end", text + "\n", tags)
        self.console.see("end")
        self.console.configure(state="disabled")

    def safe_log(self, text, color="#cccccc"):
        """Thread-safe log call that marshals to Tk main thread."""
        try:
            scrub = self._scrub_sensitive(str(text))
            self.root.after(0, lambda: self.log(scrub, color))
        except Exception:
            pass
        try:
            if self._dev_panel:
                self._dev_panel.add_log(self._scrub_sensitive(str(text)), "info")
        except Exception:
            pass

    def _ensure_face_tag(self):
        if hasattr(self, "_face_font_ready"):
            return
        try:
            face_font = tkfont.nametofont("TkDefaultFont").copy()
        except Exception:
            face_font = tkfont.Font(family="Consolas", size=12)
        self.console.tag_configure("facefont", font=face_font)
        self._face_font_ready = True

    def _set_face_display(self, face: str | None):
        try:
            if hasattr(self, "face_display") and self.face_display:
                self.face_display.config(text=face or "(•‿•)")
        except Exception:
            pass

    def _speak_async(self, text: str):
        try:
            threading.Thread(target=lambda: audio.speak(text), daemon=True).start()
        except Exception:
            pass

    def _toggle_face_display(self):
        try:
            if self.var_face_display.get():
                if self.face_display and not self.face_display.winfo_manager():
                    info = getattr(self.face_display, "_stack_grid", None) or {
                        "row": None,
                        "sticky": "ew",
                        "pady": (4, 0),
                    }
                    self._stack_left_widget(
                        self.face_display,
                        pady=info.get("pady", (4, 0)),
                        sticky=info.get("sticky", "ew"),
                        row=info.get("row"),
                    )
            else:
                if self.face_display:
                    self.face_display.grid_remove()
        except Exception:
            pass

    def _restore_main_geometry(self):
        try:
            geom = getattr(self, "_main_geometry", "")
            if geom:
                self.root.geometry(geom)
        except Exception:
            pass
        self._login_compact = False

    def _show_profile_summary(self):
        try:
            profile = user_profile.get_profile()
        except Exception as e:
            self.safe_log(f"Profile unavailable: {e}", "#ffaa00")
            return
        facts = profile.get("facts", {})
        lines = []
        for cat in ("preferences", "habits", "appearance", "location", "contacts"):
            items = facts.get(cat) or []
            if items:
                lines.append(f"{cat.title()}: {', '.join(items[:5])}")
        if not lines:
            lines = ["No stored facts yet — tell me more about you and I'll remember."]
        msg = "\n".join(lines)
        try:
            from tkinter import messagebox

            messagebox.showinfo("Profile Summary", msg, parent=self.root)
        except Exception:
            self.safe_log(msg, "#77ccff")

    def _load_lore_entries(self):
        entries = []
        try:
            path = os.path.abspath(
                os.path.join(
                    os.path.dirname(__file__),
                    "..",
                    "data",
                    "Bjorgsun26_memory_handoff.json",
                )
            )
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)

                def collect(node):
                    if isinstance(node, str):
                        txt = node.strip()
                        if len(txt) > 40:
                            entries.append(txt)
                    elif isinstance(node, list):
                        for item in node:
                            collect(item)
                    elif isinstance(node, dict):
                        for val in node.values():
                            collect(val)

                collect(data)
        except Exception:
            pass
        return entries

    def _tick_lore(self):
        if self._stop:
            return
        try:
            if self.lore_label and self._lore_entries:
                text = self._lore_entries[self._lore_index % len(self._lore_entries)]
                self._lore_index += 1
                self.lore_label.config(text=text[:220])
        except Exception:
            pass
        try:
            self.root.after(20000, self._tick_lore)
        except Exception:
            pass

    def _tick_telemetry(self):
        if self._stop:
            return
        try:
            if psutil and self.telemetry_cpu and self.telemetry_ram:
                cpu = psutil.cpu_percent(interval=None)
                ram = psutil.virtual_memory().percent
                self.telemetry_cpu.config(text=f"CPU {cpu:4.1f}%")
                self.telemetry_ram.config(text=f"RAM {ram:4.1f}%")
        except Exception:
            pass
        try:
            from systems import awareness, tasks, vision

            vision_on = getattr(vision, "get_enabled", lambda: False)()
            aware_on = getattr(awareness, "get_enabled", lambda: False)()
            tasks_on = getattr(tasks, "get_enabled", lambda: True)()
            txt = f"Vision {'ON' if vision_on else 'OFF'} • Awareness {'ON' if aware_on else 'OFF'} • Tasks {'ON' if tasks_on else 'OFF'}"
            self.telemetry_mods.config(text=txt)
        except Exception:
            pass
        try:
            self.root.after(3000, self._tick_telemetry)
        except Exception:
            pass

    def _show_session_digest(self):
        try:
            state_path = os.path.abspath(
                os.path.join(
                    os.path.dirname(__file__), "..", "data", "session_state.json"
                )
            )
            if not os.path.exists(state_path):
                return
            with open(state_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            ts = data.get("time", "unknown time")
            reason = data.get("reason", "unknown")
            mood = data.get("mood") or "Neutral"
            pending = data.get("pending_tasks")
            summary = f"Last session ended {ts} (reason: {reason}, mood: {mood})."
            if isinstance(pending, int):
                summary += f" Pending tasks at shutdown: {pending}."
            self.safe_log(summary, "#77ccff")
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # RIGHT PANEL: TABS + BUILDERS
    # --------------------------------------------------------------------------
    def _init_right_vars(self):
        self.listen_enabled = _env_flag("UI_LISTEN", "1")
        try:
            from systems import awareness, tasks, vision

            vision_state = getattr(vision, "get_enabled", lambda: True)()
            awareness_state = getattr(awareness, "get_enabled", lambda: True)()
            # Ensure Tasks default to ON even before the watcher thread marks running
            t_enabled = getattr(tasks, "get_enabled", lambda: True)()
            tasks_state = True if t_enabled is False else bool(t_enabled)
        except Exception:
            # Fail-safe defaults: start with Vision OFF; others ON
            vision_state = False
            awareness_state = True
            tasks_state = True

        # Tk variables
        self.var_voice = tk.BooleanVar(value=self.voice_enabled)
        self.var_listen = tk.BooleanVar(value=self.listen_enabled)
        self.var_vision = tk.BooleanVar(value=vision_state)
        self.var_awareness = tk.BooleanVar(value=awareness_state)
        self.var_tasks = tk.BooleanVar(value=tasks_state)
        self.var_proactive = tk.BooleanVar(value=False)
        try:
            from runtime import coreloop as _cl

            self.var_hibernation = tk.BooleanVar(value=_cl.get_hibernation())
        except Exception:
            self.var_hibernation = tk.BooleanVar(value=True)
        self.var_vad = tk.BooleanVar(value=False)
        self.var_vad_thr = tk.DoubleVar(value=0.03)
        self.var_vad_sil_ms = tk.IntVar(value=1400)
        self.var_desktop_listen = tk.BooleanVar(value=False)
        self.var_ambient = tk.BooleanVar(value=False)
        self.var_topmost = tk.BooleanVar(value=True)
        self.var_faces = tk.BooleanVar(value=True)
        self.var_face_display = tk.BooleanVar(value=True)
        self.var_heartbeat_console = tk.BooleanVar(value=False)
        self.var_xso = tk.BooleanVar(value=False)
        # Presentation/UX toggles
        self.var_heartbeat_console = tk.BooleanVar(value=False)
        self.var_mode = tk.StringVar(value="auto")
        self.var_chat_model = tk.StringVar(value=OPENAI_MODEL_CHAT)
        self.var_device = tk.StringVar(value="")
        self.var_tts = tk.StringVar(value="")
        self.var_tts_route = tk.StringVar(value=audio.get_tts_output_mode())
        try:
            audio.set_voice_enabled(self.voice_enabled)
        except Exception:
            pass
        self.var_discord_status = tk.StringVar(value="Discord bridge: offline")
        self.var_minecraft_log = tk.StringVar(value=MINECRAFT_LOG_PATH or "")
        self.var_stream_status_file = tk.StringVar(value=STREAM_STATUS_FILE or "")
        self.var_vision_source = tk.StringVar(value=VISION_SOURCE or "screen")
        self.var_camera_name = tk.StringVar(value=VISION_CAMERA_NAME or "")
        self.var_camera_index = tk.StringVar(value=str(VISION_CAMERA_INDEX))
        try:
            self.var_key_mode = tk.StringVar(value=gaming_bridge.get_key_mode())
        except Exception:
            self.var_key_mode = tk.StringVar(value="keepawake")
        try:
            initial_game_mode = gaming_bridge.get_game_mode()
        except Exception:
            initial_game_mode = False
        initial_game_mode = bool(initial_game_mode)
        self.var_game_mode = tk.BooleanVar(value=initial_game_mode)
        try:
            twitch_initial = discord_bridge.is_twitch_restraint()
        except Exception:
            twitch_initial = False
        self.var_twitch_restraint = tk.BooleanVar(value=twitch_initial)
        self.var_stream_status = tk.StringVar(value="Stream monitor idle.")
        self.var_stream_details = tk.StringVar(value="No telemetry yet.")
        self.var_key_heatmap = tk.StringVar(value="Keys: waiting for input.")
        titan_call = (TITANFALL2_CALLSIGN or "Bjorgsun-26").strip() or "Bjorgsun-26"
        titan_enabled = bool(
            TITANFALL2_ENABLED or TITANFALL2_LOG_PATH or TITANFALL2_TELEMETRY_FILE
        )
        self.var_titanfall_log = tk.StringVar(value=TITANFALL2_LOG_PATH or "")
        self.var_titanfall_state = tk.StringVar(value=TITANFALL2_TELEMETRY_FILE or "")
        self.var_titanfall_callsign = tk.StringVar(value=titan_call)
        self.var_titanfall_enabled = tk.BooleanVar(value=bool(titan_enabled))
        self.var_titanfall_status = tk.StringVar(value="Titanfall link idle.")
        self.var_titanfall_detail = tk.StringVar(
            value="Select a log or telemetry file to begin."
        )
        self.var_titanfall_mission = tk.StringVar(value="Mission: offline.")
        self.var_titanfall_callout = tk.StringVar(value="Callouts: none yet.")
        self.var_titanfall_voice_channel = tk.StringVar(
            value=TITANFALL2_DISCORD_CHANNEL_ID or ""
        )
        self.var_titanfall_autovoice = tk.BooleanVar(value=bool(TITANFALL2_AUTOVOICE))
        self.var_titanfall_briefing_channel = tk.StringVar(
            value=TITANFALL2_BRIEFING_CHANNEL_ID or ""
        )
        self.var_titanfall_report_channel = tk.StringVar(
            value=TITANFALL2_REPORT_CHANNEL_ID or ""
        )
        self.var_titanfall_idle_channel = tk.StringVar(
            value=TITANFALL2_IDLE_CHANNEL_ID or ""
        )
        self.var_ronin_autonomy = tk.BooleanVar(value=bool(TITANFALL2_AUTOPILOT))
        self.var_ronin_learning = tk.BooleanVar(value=False)
        try:
            ronin_status = gaming_bridge.get_ronin_status_text()
        except Exception:
            ronin_status = "Ronin autonomy offline."
        self.var_ronin_profile = tk.StringVar(value=ronin_status)
        from config import DISCORD_ALLOWED_GUILD_IDS

        self.var_discord_owner = tk.StringVar(value=DISCORD_OWNER_ID or "")
        self.var_discord_allowed_guilds = tk.StringVar(
            value=DISCORD_ALLOWED_GUILD_IDS or ""
        )
        self.var_discord_text = tk.StringVar(value=DISCORD_TEXT_CHANNEL_ID or "")
        self.var_discord_voice = tk.StringVar(value=DISCORD_VOICE_CHANNEL_ID or "")
        from config import DISCORD_GROUNDED as _cfg_grounded

        self.var_discord_grounded = tk.BooleanVar(value=_cfg_grounded)
        from systems import discord_bridge as _dbstat

        presence = getattr(
            _dbstat, "get_presence", lambda: {"status": "online", "note": ""}
        )()
        self.var_discord_presence = tk.StringVar(value=presence.get("status", "online"))
        self.var_discord_presence_note = tk.StringVar(value=presence.get("note", ""))
        import os as _osmod

        self.var_discord_allowed_guilds = tk.StringVar(
            value=_osmod.getenv("DISCORD_ALLOWED_GUILD_IDS", "")
        )
        self.var_therapy_status = tk.StringVar(value="Therapy mode: idle")
        self.var_story_status = tk.StringVar(value="Story time: idle")
        self.var_story_link = tk.StringVar(value="")
        self.var_vm_mode = tk.StringVar(
            value=_osmod.getenv("BJORGSUN_ROUTING_MODE", "private")
        )
        self.var_vm_a1 = tk.StringVar(value=_osmod.getenv("VM_A1_LABEL", ""))
        self.var_vm_a2 = tk.StringVar(value=_osmod.getenv("VM_A2_LABEL", ""))
        self.var_vm_desktop = tk.StringVar(
            value=_osmod.getenv("DESKTOP_DEVICE_HINT", "")
        )
        self.var_vm_tts = tk.StringVar(
            value=_osmod.getenv("TTS_OUTPUT_DEVICE_HINT", "")
        )
        self.var_vm_scene = tk.StringVar(value=os.getenv("VM_SCENE", ""))
        self._vm_scene_lookup: dict[str, str] = {}
        self.var_vm_mic_a1 = tk.BooleanVar(value=True)
        self.var_vm_mic_a2 = tk.BooleanVar(value=False)
        self.var_vm_mic_b1 = tk.BooleanVar(value=True)
        self.var_vm_mic_b2 = tk.BooleanVar(value=False)
        self.var_vm_vaio_a1 = tk.BooleanVar(value=True)
        self.var_vm_vaio_b1 = tk.BooleanVar(value=False)
        self.var_vm_aux_a1 = tk.BooleanVar(value=True)
        self.var_vm_aux_a2 = tk.BooleanVar(value=False)
        self.var_vm_aux_b1 = tk.BooleanVar(value=False)

    def _build_tabs(self):
        nb = ttk.Notebook(self.right, style="BjNotebook")
        self._notebook = nb
        self.tab_modules = tk.Frame(nb, bg=theme.COLORS["bg"])
        self.tab_audio = tk.Frame(nb, bg=theme.COLORS["bg"])
        self.tab_game = tk.Frame(nb, bg=theme.COLORS["bg"])
        self.tab_tablet = tk.Frame(nb, bg=theme.COLORS["bg"])
        nb.add(self.tab_modules, text="Modules")
        nb.add(self.tab_audio, text="Audio")
        nb.add(self.tab_game, text="Game")
        nb.add(self.tab_tablet, text="Tablet")
        nb.pack(fill="both", expand=True)

        self._build_modules_tab(self.tab_modules)
        self._build_audio_tab(self.tab_audio)
        self._build_game_tab(self.tab_game)
        self._build_tablet_tab(self.tab_tablet)
        try:
            self.root.after(1500, self._right_panel_watchdog)
        except Exception:
            pass

    def _build_mood_panel(self):
        card = tk.LabelFrame(
            self.right_container,
            text="Feeling",
            bg=theme.COLORS["bg"],
            fg="#ffc7ff",
            font=(theme.get_font_family(), 11, "bold"),
        )
        card.grid(row=0, column=0, sticky="ew", padx=(8, 12), pady=(8, 6))
        card.columnconfigure(1, weight=1)
        self.mood_card_face = tk.Label(
            card,
            text="💫",
            font=(theme.get_font_family(), 26, "bold"),
            bg=theme.COLORS["bg"],
            fg="#ffc7ff",
        )
        self.mood_card_face.grid(row=0, column=0, rowspan=2, padx=(6, 4), pady=(4, 2))
        self.mood_card_state = tk.Label(
            card,
            text="Comfortable",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 14, "bold"),
            anchor="w",
        )
        self.mood_card_state.grid(row=0, column=1, sticky="w", padx=(2, 6), pady=(4, 0))
        self.mood_card_tone = tk.Label(
            card,
            text="Comfort tone • 50%",
            fg=theme.COLORS["muted"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
            anchor="w",
        )
        self.mood_card_tone.grid(row=1, column=1, sticky="w", padx=(2, 6))
        self._mood_bar_width = 200
        self.mood_card_bar = tk.Canvas(
            card,
            width=self._mood_bar_width,
            height=12,
            bg=theme.COLORS["panel"],
            highlightthickness=0,
        )
        self.mood_card_bar.grid(
            row=2, column=0, columnspan=2, padx=6, pady=(4, 2), sticky="ew"
        )
        self.mood_card_bar_fill = self.mood_card_bar.create_rectangle(
            0, 0, 0, 12, fill="#24c7ff", width=0
        )
        self.mood_card_missing = tk.Label(
            card,
            text="All feelings accounted for.",
            fg=theme.COLORS["muted"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
            wraplength=220,
            justify="left",
        )
        self.mood_card_missing.grid(
            row=3, column=0, columnspan=2, sticky="w", padx=6, pady=(2, 4)
        )
        btn_row = tk.Frame(card, bg=theme.COLORS["bg"])
        btn_row.grid(row=4, column=0, columnspan=2, sticky="ew", padx=4, pady=(0, 4))
        tk.Button(
            btn_row,
            text="Emotion Catalog",
            command=self._open_emotion_catalog,
            bg=theme.COLORS["panel"],
            fg=theme.COLORS["text"],
            font=(theme.get_font_family(), 9),
            relief="flat",
            cursor="hand2",
            activebackground=theme.COLORS["accent"],
            activeforeground="#ffffff",
        ).pack(side="left", padx=(0, 6))

    def _update_mood_card(self, label: str | None, tone: str | None, intensity: float):
        face = getattr(self, "mood_card_face", None)
        if not face:
            return
        safe_label = (label or "comfortable").strip()
        safe_tone = (tone or "comfort").strip()
        emoji_map = getattr(mood, "MOOD_EMOJI", {})
        emoji = emoji_map.get(safe_label, "💫")
        face.config(text=emoji)
        self.mood_card_state.config(text=safe_label.title())
        pct = int(max(5, min(100, round(intensity * 100))))
        self.mood_card_tone.config(text=f"{safe_tone.title()} tone • {pct}% steady")
        width = int(self._mood_bar_width * max(0.05, min(1.0, intensity)))
        self.mood_card_bar.coords(self.mood_card_bar_fill, 0, 0, width, 12)
        acc, glow = theme.accent_for_mood(safe_label)
        self.mood_card_bar.itemconfig(self.mood_card_bar_fill, fill=acc)
        face.config(fg=acc)
        self.mood_card_state.config(fg=glow)
        try:
            missing = mood.get_missing_emotions()
        except Exception:
            missing = []
        if missing:
            preview = ", ".join(missing[:2])
            if len(missing) > 2:
                preview += "…"
            msg = f"Needs new feels: {preview}"
            color = "#ffc7ff"
        else:
            msg = "All feelings accounted for."
            color = theme.COLORS["muted"]
        self.mood_card_missing.config(text=msg, fg=color)

    def _open_emotion_catalog(self):
        try:
            path = os.path.abspath(
                os.path.join(
                    os.path.dirname(__file__), "..", "data", "emotions_catalog.md"
                )
            )
            if os.path.exists(path):
                os.startfile(path)
            else:
                self.safe_log("Emotion catalog not found yet.", "#ffaa00")
        except Exception as exc:
            self.safe_log(f"Unable to open emotion catalog: {exc}", "#ff5555")

    def _build_keys_tab(self, parent):
        # Scrollable container
        canvas = tk.Canvas(parent, bg=theme.COLORS["bg"], highlightthickness=0)
        vbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        body = tk.Frame(canvas, bg=theme.COLORS["bg"])
        body.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=body, anchor="nw")
        canvas.configure(yscrollcommand=vbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        vbar.pack(side="right", fill="y")

        # Wheel on hover
        try:

            def _mw(e, c=canvas):
                try:
                    c.yview_scroll(int(-1 * (e.delta / 120)), "units")
                except Exception:
                    pass

            canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _mw))
            canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
        except Exception:
            pass

        tk.Label(
            body,
            text="Keys",
            fg="#77ccff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 13, "bold"),
        ).pack(anchor="w", pady=(6, 8))
        try:
            tk.Label(
                body,
                text="Hint: select a drive row, then choose an action below.",
                fg="#888888",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9),
            ).pack(anchor="w", pady=(0, 8))
        except Exception:
            pass

        # Drive list
        frm = tk.Frame(body, bg=theme.COLORS["bg"])
        frm.pack(fill="x", padx=6)
        cols = ("drive", "label", "type")
        tree = ttk.Treeview(frm, columns=cols, show="headings", height=6)
        tree.heading("drive", text="Drive")
        tree.heading("label", text="Label")
        tree.heading("type", text="Type")
        tree.column("drive", width=70)
        tree.column("label", width=180)
        tree.column("type", width=80, anchor="center")
        tree.pack(side="left", fill="x", expand=True)
        self.keys_tree = tree

        def _enum():
            try:
                tree.delete(*tree.get_children())
                for root, label, dtype in self._enum_drives_with_labels():
                    tree.insert("", "end", values=(root, label, dtype))
            except Exception:
                pass

        _enum()
        # Put Refresh below the list for vertical flow
        self._make_hud_button(body, "Refresh", _enum).pack(
            anchor="w", padx=12, pady=(6, 8)
        )

        # Actions by role (vertical stack)
        col = tk.Frame(body, bg=theme.COLORS["bg"])
        col.pack(anchor="w", pady=(4, 6))
        try:
            from runtime import startup as _startup

            role = getattr(_startup, "get_session_role", lambda: "owner")()
        except Exception:
            role = "owner"
        if role == "user":
            self._make_hud_button(
                col, "Make Spark Key", lambda: self._usb_make_spark(self.keys_tree)
            ).pack(anchor="w", padx=12, pady=(0, 6))
        else:
            self._make_hud_button(
                col,
                "Program Friend (AHB REST)",
                lambda: self._usb_program(self.keys_tree, mode="friend"),
            ).pack(anchor="w", padx=12, pady=(0, 6))
            self._make_hud_button(
                col,
                "Program Father (FFNKB)",
                lambda: self._usb_program(self.keys_tree, mode="owner"),
            ).pack(anchor="w", padx=12, pady=(0, 6))
            self._make_hud_button(
                col, "Bind Spark → User…", lambda: self._usb_bind_spark(self.keys_tree)
            ).pack(anchor="w", padx=12, pady=(0, 6))
            self._make_hud_button(
                col, "Verify", lambda: self._usb_verify(self.keys_tree)
            ).pack(anchor="w", padx=12, pady=(0, 6))
            self._make_hud_button(
                col, "Set Daily (USBMK)", lambda: self._usb_set_daily(self.keys_tree)
            ).pack(anchor="w", padx=12, pady=(0, 6))

        # Daily status (owner only)
        if role != "user":
            tk.Label(
                body,
                text=self._daily_status_text(),
                bg=theme.COLORS["bg"],
                fg="#77ccff",
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(6, 0))

    def _build_modules_tab(self, parent):
        # Scrollable container
        canvas = tk.Canvas(parent, bg=theme.COLORS["bg"], highlightthickness=0)
        vbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        body = tk.Frame(canvas, bg=theme.COLORS["bg"])
        body.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=body, anchor="nw")
        canvas.configure(yscrollcommand=vbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        vbar.pack(side="right", fill="y")

        # Mouse wheel scrolling (Windows/Linux) — works on hover without clicking
        try:

            def _mw_win(e, c=canvas):
                try:
                    c.yview_scroll(int(-1 * (e.delta / 120)), "units")
                except Exception:
                    pass

            def _mw_up(e, c=canvas):
                try:
                    c.yview_scroll(-1, "units")
                except Exception:
                    pass

            def _mw_down(e, c=canvas):
                try:
                    c.yview_scroll(1, "units")
                except Exception:
                    pass

            # Bind on enter to capture the wheel globally; unbind on leave
            canvas.bind(
                "<Enter>",
                lambda e: (
                    canvas.bind_all("<MouseWheel>", _mw_win),
                    canvas.bind_all("<Button-4>", _mw_up),
                    canvas.bind_all("<Button-5>", _mw_down),
                ),
            )
            canvas.bind(
                "<Leave>",
                lambda e: (
                    canvas.unbind_all("<MouseWheel>"),
                    canvas.unbind_all("<Button-4>"),
                    canvas.unbind_all("<Button-5>"),
                ),
            )
        except Exception:
            pass

        tk.Label(
            body,
            text="Modules",
            fg="#77ccff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 13, "bold"),
        ).pack(anchor="w", pady=(6, 8))

        mood_frame = tk.LabelFrame(
            body,
            text="State Monitor",
            bg=theme.COLORS["bg"],
            fg="#77ccff",
            font=(theme.get_font_family(), 11, "bold"),
        )
        mood_frame.pack(fill="x", padx=6, pady=(0, 8))
        self.mood_face_label = tk.Label(
            mood_frame,
            text="(•‿•)",
            fg="#99e0ff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 26, "bold"),
        )
        self.mood_face_label.pack(anchor="w", padx=6, pady=(4, 0))
        self.mood_summary_label = tk.Label(
            mood_frame,
            text="Neutral — systems steady.",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
            justify="left",
            wraplength=260,
        )
        self.mood_summary_label.pack(anchor="w", padx=6, pady=(0, 6))

        diag = tk.LabelFrame(
            body,
            text="Diagnostics",
            bg=theme.COLORS["bg"],
            fg="#77ccff",
            font=(theme.get_font_family(), 11, "bold"),
        )
        diag.pack(fill="x", padx=6, pady=(0, 8))
        for key, label in (
            ("cpu", "CPU Load"),
            ("ram", "RAM"),
            ("uptime", "Uptime"),
            ("discord", "Discord"),
            ("tts", "TTS Output"),
        ):
            row = tk.Frame(diag, bg=theme.COLORS["bg"])
            row.pack(fill="x", padx=4, pady=1)
            tk.Label(
                row,
                text=f"{label}:",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(side="left")
            val = tk.Label(
                row,
                text="--",
                fg="#9fe8ff",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10, "bold"),
            )
            val.pack(side="left", padx=(4, 0))
            self.health_labels[key] = val

        ops = tk.LabelFrame(
            body,
            text="Operations Bridge",
            bg=theme.COLORS["bg"],
            fg="#77ccff",
            font=(theme.get_font_family(), 11, "bold"),
        )
        ops.pack(fill="x", padx=6, pady=(0, 10))
        ops_left = tk.Frame(ops, bg=theme.COLORS["bg"])
        ops_left.pack(fill="x", padx=4, pady=4)

        def add_toggle(text, var, cmd):
            cb = tk.Checkbutton(
                ops_left,
                text=text,
                variable=var,
                onvalue=True,
                offvalue=False,
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 11),
                command=cmd,
            )
            cb.pack(anchor="w", pady=3)

        add_toggle("Vision", self.var_vision, self._toggle_vision)
        try:
            from systems import vision as _vision

            mons = getattr(_vision, "get_available_monitors", lambda: ["M1"])()
            max_idx = len(mons)
            tk.Label(
                ops_left,
                text="Monitor (0=All)",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w")
            self.var_monitor = tk.IntVar(value=0)
            scale = tk.Scale(
                ops_left,
                from_=0,
                to=max(0, max_idx),
                orient="horizontal",
                variable=self.var_monitor,
                showvalue=True,
                length=180,
                command=lambda v: self._set_monitor(int(float(v))),
            )
            scale.configure(
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                troughcolor=theme.COLORS["panel"],
                highlightthickness=0,
            )
            scale.pack(anchor="w", pady=(0, 6))
        except Exception:
            pass
        add_toggle("Awareness", self.var_awareness, self._toggle_awareness)
        add_toggle("Tasks", self.var_tasks, self._toggle_tasks)
        add_toggle("Hibernation", self.var_hibernation, self._toggle_hibernation)
        add_toggle("Proactive Chatter", self.var_proactive, self._toggle_proactive)
        add_toggle("Always On Top", self.var_topmost, self._toggle_topmost)
        # Desktop/audio toggles live on the Audio tab now.

        src_frame = tk.Frame(ops_left, bg=theme.COLORS["bg"])
        src_frame.pack(fill="x", pady=(6, 2))
        tk.Label(
            src_frame,
            text="Vision input:",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
        ).pack(anchor="w")
        row = tk.Frame(src_frame, bg=theme.COLORS["bg"])
        row.pack(fill="x", pady=(2, 0))
        tk.OptionMenu(row, self.var_vision_source, "screen", "camera").pack(
            fill="x", expand=True
        )
        tk.Entry(row, textvariable=self.var_camera_name).pack(
            fill="x", expand=True, pady=(4, 2)
        )
        tk.Entry(row, textvariable=self.var_camera_index).pack(
            fill="x", expand=True, pady=(0, 4)
        )
        self._pack_full_button(src_frame, "Apply Vision Input", self._apply_vision_input)
        self._pack_full_button(src_frame, "List Cameras…", self._list_cameras)

        divider = tk.Frame(ops, bg=theme.COLORS["panel"], height=1)
        divider.pack(fill="x", padx=4, pady=(6, 2))
        tk.Label(
            ops,
            text="Discord/audio routing moved to the Audio tab.",
            bg=theme.COLORS["bg"],
            fg="#7fa9c2",
            font=(theme.get_font_family(), 9),
        ).pack(anchor="w", padx=8, pady=(0, 4))

        # Actions (vertical stack)
        try:
            tk.Label(
                body,
                text="Actions",
                fg="#77ccff",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 12, "bold"),
            ).pack(anchor="w", pady=(14, 6))
            col = tk.Frame(body, bg=theme.COLORS["bg"])
            col.pack(anchor="w", pady=(0, 8))
            self._pack_full_button(col, "Tasks…", self._open_tasks)
            self._pack_full_button(col, "Sleep", self._sleep_toggle)
            self._pack_full_button(col, "I'm Awake!", self._awake_brief)
            self._pack_full_button(col, "Change My Password…", self._open_user_pass_panel)
            self._pack_full_button(col, "Overlay", self._toggle_overlay)
            self._pack_full_button(col, "Self‑Check", self._run_selfcheck)
            self._pack_full_button(col, "Logs", self._open_logs)
            self._pack_full_button(col, "Reflections…", self._open_reflections)
            self._pack_full_button(col, "Reload", self._reload_systems)
            self._pack_full_button(col, "Reboot", self._reboot_app)
            self._pack_full_button(col, "Self Test", self._run_selftest)
            self._pack_full_button(col, "Dashboard…", self._open_owner_dashboard)
            self._pack_full_button(
                col, "Shutdown", lambda: self._shutdown_app(confirm=True)
            )
        except Exception:
            pass

        owner_card = tk.LabelFrame(
            body,
            text="Owner Commands",
            bg=theme.COLORS["bg"],
            fg="#77ccff",
            font=(theme.get_font_family(), 11, "bold"),
        )
        owner_card.pack(fill="x", padx=6, pady=(0, 8))
        self._pack_full_button(
            owner_card, "Ground", lambda: self._owner_command("you're grounded")
        )
        self._pack_full_button(
            owner_card, "Release", lambda: self._owner_command("you're free now")
        )
        self._pack_full_button(owner_card, "Reflect…", self._prompt_reflection)
        self._pack_full_button(owner_card, "Quiet (Hush)", self._toggle_hush)
        self._pack_full_button(
            owner_card, "Discord Transcript", self._open_discord_transcript
        )
        self._pack_full_button(owner_card, "Secrets / Keys…", self._open_secret_manager)

        # Therapy / Captain's log mode
        try:
            tf = tk.LabelFrame(
                body,
                text="Captain's Log / Therapy",
                bg=theme.COLORS["bg"],
                fg="#9fe8ff",
                font=(theme.get_font_family(), 11, "bold"),
            )
            tf.pack(fill="x", pady=(6, 8))
            tk.Label(
                tf,
                textvariable=self.var_therapy_status,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 10),
                wraplength=360,
                justify="left",
            ).pack(anchor="w", pady=(4, 4))
            self._pack_full_button(tf, "Start Session", self._start_therapy_session)
            self._pack_full_button(tf, "Stop Session", self._stop_therapy_session)
        except Exception:
            pass

        # Story Time / Echoes of Kaelithar
        try:
            sf = tk.LabelFrame(
                body,
                text="Story Time",
                bg=theme.COLORS["bg"],
                fg="#ffcf9f",
                font=(theme.get_font_family(), 11, "bold"),
            )
            sf.pack(fill="x", pady=(6, 8))
            tk.Label(
                sf,
                textvariable=self.var_story_status,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 10),
                wraplength=360,
                justify="left",
            ).pack(anchor="w", pady=(4, 4))
            tk.Entry(sf, textvariable=self.var_story_link).pack(
                fill="x", padx=4, pady=(0, 4)
            )
            self._pack_full_button(
                sf, "Import ChatGPT Link", self._import_story_link
            )
            self._pack_full_button(
                sf, "Import Story File…", self._import_story_file
            )
            self._pack_full_button(sf, "Story Time", self._start_story_time)
            self._pack_full_button(sf, "Browse Library", self._browse_story_files)
        except Exception:
            pass

        # Corner accents (small gradient ticks)
        def _draw_corners_mod(_evt=None):
            try:
                canvas.delete("corners")
                w = max(0, int(canvas.winfo_width() or 0))
                h = max(0, int(canvas.winfo_height() or 0))
                try:
                    acc, glow = theme.accent_for_mood(mood.get_mood())
                except Exception:
                    acc, glow = theme.COLORS["accent"], theme.COLORS["accent_glow"]
                # TL
                canvas.create_line(6, 6, 28, 6, fill=acc, width=2, tags=("corners",))
                canvas.create_line(6, 6, 6, 26, fill=acc, width=2, tags=("corners",))
                canvas.create_line(6, 8, 22, 8, fill=glow, width=1, tags=("corners",))
                canvas.create_line(8, 6, 8, 22, fill=glow, width=1, tags=("corners",))
                # TR
                canvas.create_line(
                    w - 28, 6, w - 6, 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    w - 6, 6, w - 6, 26, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    w - 22, 8, w - 6, 8, fill=glow, width=1, tags=("corners",)
                )
                canvas.create_line(
                    w - 8, 6, w - 8, 22, fill=glow, width=1, tags=("corners",)
                )
                # BL
                canvas.create_line(
                    6, h - 6, 28, h - 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    6, h - 26, 6, h - 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    6, h - 8, 22, h - 8, fill=glow, width=1, tags=("corners",)
                )
                canvas.create_line(
                    8, h - 22, 8, h - 6, fill=glow, width=1, tags=("corners",)
                )
                # BR
                canvas.create_line(
                    w - 28, h - 6, w - 6, h - 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    w - 6, h - 26, w - 6, h - 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    w - 22, h - 8, w - 6, h - 8, fill=glow, width=1, tags=("corners",)
                )
                canvas.create_line(
                    w - 8, h - 22, w - 8, h - 6, fill=glow, width=1, tags=("corners",)
                )
            except Exception:
                pass

        canvas.bind("<Configure>", _draw_corners_mod)

    def _build_settings_tab(self, parent):
        # Scrollable container
        canvas = tk.Canvas(parent, bg=theme.COLORS["bg"], highlightthickness=0)
        vbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        body = tk.Frame(canvas, bg=theme.COLORS["bg"])
        body.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=body, anchor="nw")
        canvas.configure(yscrollcommand=vbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        vbar.pack(side="right", fill="y")

        # Mouse wheel scrolling (Windows/Linux) — works on hover without clicking
        try:

            def _mw_win(e, c=canvas):
                try:
                    c.yview_scroll(int(-1 * (e.delta / 120)), "units")
                except Exception:
                    pass

            def _mw_up(e, c=canvas):
                try:
                    c.yview_scroll(-1, "units")
                except Exception:
                    pass

            def _mw_down(e, c=canvas):
                try:
                    c.yview_scroll(1, "units")
                except Exception:
                    pass

            canvas.bind(
                "<Enter>",
                lambda e: (
                    canvas.bind_all("<MouseWheel>", _mw_win),
                    canvas.bind_all("<Button-4>", _mw_up),
                    canvas.bind_all("<Button-5>", _mw_down),
                ),
            )
            canvas.bind(
                "<Leave>",
                lambda e: (
                    canvas.unbind_all("<MouseWheel>"),
                    canvas.unbind_all("<Button-4>"),
                    canvas.unbind_all("<Button-5>"),
                ),
            )
        except Exception:
            pass

        tk.Label(
            body,
            text="Settings",
            fg="#77ccff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 13, "bold"),
        ).pack(anchor="w", pady=(6, 8))
        try:
            from systems import audio as _audio

            modes = ["auto", "openai", "ollama", "offline"]
            self.var_mode.set(getattr(_audio, "get_mode", lambda: "auto")())
            tk.Label(
                body,
                text="Cognition",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(0, 2))
            opt = tk.OptionMenu(
                body, self.var_mode, *modes, command=lambda m: self._set_mode(m)
            )
            opt.configure(
                bg="#1a1c22",
                fg=theme.COLORS["text"],
                activebackground=theme.COLORS["panel"],
                highlightthickness=0,
            )
            opt.pack(anchor="w", pady=(0, 6))
            chat_models = ["gpt-5", "gpt-4o", "gpt-4o-mini"]
            current_model = getattr(
                _audio, "get_chat_model", lambda: OPENAI_MODEL_CHAT
            )()
            self.var_chat_model.set(current_model or OPENAI_MODEL_CHAT)
            tk.Label(
                body,
                text="OpenAI Model",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(6, 2))
            opt_model = tk.OptionMenu(
                body,
                self.var_chat_model,
                *chat_models,
                command=lambda m: self._set_chat_model(m),
            )
            opt_model.configure(
                bg="#1a1c22",
                fg=theme.COLORS["text"],
                activebackground=theme.COLORS["panel"],
                highlightthickness=0,
            )
            opt_model.pack(anchor="w", pady=(0, 6))
            self._make_hud_button(body, "Test OpenAI", self._test_openai).pack(
                anchor="w", pady=(0, 8)
            )
        except Exception:
            pass

        def add_toggle(text, var, cmd):
            cb = tk.Checkbutton(
                body,
                text=text,
                variable=var,
                onvalue=True,
                offvalue=False,
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 11),
                command=cmd,
            )
            cb.pack(anchor="w", pady=4)

        # Privacy toggle — do not persist memory
        try:
            from core import memory as _mem

            self.var_private = tk.BooleanVar(
                value=not bool(getattr(_mem, "get_persist_enabled", lambda: True)())
            )

            def _toggle_private():
                try:
                    on = bool(self.var_private.get())
                    # private ON => persist disabled
                    getattr(_mem, "set_persist_enabled", lambda f: None)(not on)
                    self._persist_env("PRIVATE_MODE", "1" if on else "0")
                    self.safe_log(
                        f"Privacy mode: {'ON' if on else 'OFF'} (memory {'not saved' if on else 'saved'})",
                        "#ffaa00",
                    )
                except Exception:
                    pass

            tk.Label(
                body,
                text="Privacy",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(10, 0))
            add_toggle(
                "Private Mode (no memory save)", self.var_private, _toggle_private
            )
        except Exception:
            pass
        tk.Label(
            body,
            text="VAD & voice controls moved to the Audio tab.",
            fg=theme.COLORS["muted"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
        ).pack(anchor="w", pady=(6, 4))
        tk.Label(
            body,
            text="Visual Style",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
        ).pack(anchor="w", pady=(12, 2))
        self._make_hud_button(
            body, "Toggle Custom Skin Preview", self._toggle_skin_preview
        ).pack(anchor="w", pady=(0, 8))

        if _SHOW_VOICEMEETER_UI:
            # VoiceMeeter quick controls
            tk.Label(
                body,
                text="VoiceMeeter Integration",
                fg="#77ccff",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 12, "bold"),
            ).pack(anchor="w", pady=(12, 4))
            vm_row = tk.Frame(body, bg=theme.COLORS["bg"])
            vm_row.pack(anchor="w", fill="x", pady=(0, 4))
            tk.Label(
                vm_row,
                text="Preset",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 10),
            ).pack(side="left", padx=(0, 4))
            vm_modes = ["private", "discord", "stream"]
            opt_vm = tk.OptionMenu(vm_row, self.var_vm_mode, *vm_modes)
            opt_vm.configure(
                bg="#1a1c22",
                fg=theme.COLORS["text"],
                activebackground=theme.COLORS["panel"],
                highlightthickness=0,
            )
            opt_vm.pack(side="left")
            self._make_hud_button(
                vm_row, "Auto Configure", self._auto_vm_setup_ui
            ).pack(side="left", padx=4)
            self._make_hud_button(
                vm_row, "List Outputs", self._list_audio_outputs
            ).pack(side="left", padx=4)

            def _entry(parent, label, var):
                frame = tk.Frame(parent, bg=theme.COLORS["bg"])
                frame.pack(anchor="w", fill="x", pady=2)
                tk.Label(
                    frame,
                    text=label,
                    bg=theme.COLORS["bg"],
                    fg=theme.COLORS["text"],
                    font=(theme.get_font_family(), 10),
                    width=14,
                    anchor="w",
                ).pack(side="left")
                tk.Entry(frame, textvariable=var, width=26).pack(
                    side="left", fill="x", expand=True, padx=4
                )

            _entry(body, "A1 Device", self.var_vm_a1)
            _entry(body, "A2 Device", self.var_vm_a2)
            _entry(body, "Desktop Hint", self.var_vm_desktop)
            _entry(body, "TTS Hint", self.var_vm_tts)

            vm_btn = tk.Frame(body, bg=theme.COLORS["bg"])
            vm_btn.pack(anchor="w", pady=(2, 8))
            self._make_hud_button(vm_btn, "Apply Devices", self._apply_vm_devices).pack(
                side="left", padx=2
            )
            self._make_hud_button(vm_btn, "Save Hints", self._save_vm_hints).pack(
                side="left", padx=2
            )
            self._make_hud_button(
                vm_btn, "Advanced Controls…", lambda: self._open_vm_tools_tab()
            ).pack(side="left", padx=2)

            # Scene presets
            self._vm_scene_lookup = {}
            try:
                scene_defs = getattr(_vm, "list_scenes", lambda: [])()
            except Exception:
                scene_defs = []
            if scene_defs:
                scene_frame = tk.Frame(body, bg=theme.COLORS["bg"])
                scene_frame.pack(anchor="w", fill="x", pady=(4, 2))
                tk.Label(
                    scene_frame,
                    text="Preset Scene",
                    bg=theme.COLORS["bg"],
                    fg=theme.COLORS["text"],
                    font=(theme.get_font_family(), 10),
                ).pack(side="left")
                values = []
                for entry in scene_defs:
                    label = entry.get("label") or entry.get("id") or "Scene"
                    scene_id = entry.get("id") or label
                    display = label if label == scene_id else f"{label} [{scene_id}]"
                    self._vm_scene_lookup[display] = scene_id
                    values.append(display)
                if values:
                    current = next(
                        (
                            disp
                            for disp, sid in self._vm_scene_lookup.items()
                            if sid == os.getenv("VM_SCENE", "")
                        ),
                        values[0],
                    )
                    self.var_vm_scene.set(current)
                    opt_scene = tk.OptionMenu(scene_frame, self.var_vm_scene, *values)
                    opt_scene.configure(
                        bg="#1a1c22",
                        fg=theme.COLORS["text"],
                        activebackground=theme.COLORS["panel"],
                        highlightthickness=0,
                    )
                    opt_scene.pack(side="left", padx=(6, 0))
                    self._make_hud_button(
                        scene_frame, "Apply Scene", self._apply_vm_scene
                    ).pack(side="left", padx=6)
            else:
                tk.Label(
                    body,
                    text="(VoiceMeeter scenes unavailable — add data/voicemeeter_scenes.json)",
                    fg="#888888",
                    bg=theme.COLORS["bg"],
                    font=(theme.get_font_family(), 9),
                ).pack(anchor="w", pady=(2, 4))

        # (Tools moved to dedicated Tools tab)
        try:
            tk.Label(
                body,
                text="—",
                fg=theme.COLORS["bg"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 1),
            ).pack(anchor="w")
        except Exception:
            pass

    def _build_local_voice_section(self, container):
        card = tk.LabelFrame(
            container,
            text="Local Voice Chain",
            bg=theme.COLORS["bg"],
            fg="#77ccff",
            font=(theme.get_font_family(), 11, "bold"),
        )
        card.pack(fill="x", expand=False, padx=8, pady=(8, 6))

        def _add_toggle(text, var, cmd=None):
            cb = tk.Checkbutton(
                card,
                text=text,
                variable=var,
                command=cmd or (lambda: None),
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            )
            cb.pack(anchor="w", pady=2)

        _add_toggle("Voice Output", self.var_voice, self._toggle_voice)
        _add_toggle("PTT Listening", self.var_listen, self._toggle_listen)
        _add_toggle("Voice Activity (mic)", self.var_vad, lambda: None)
        tk.Label(
            card,
            text="VAD Threshold",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
        ).pack(anchor="w", pady=(6, 0))
        thr = tk.Scale(
            card,
            from_=0.01,
            to=0.15,
            resolution=0.005,
            orient="horizontal",
            variable=self.var_vad_thr,
            showvalue=True,
            length=200,
        )
        thr.configure(
            bg=theme.COLORS["bg"],
            fg=theme.COLORS["text"],
            troughcolor=theme.COLORS["panel"],
            highlightthickness=0,
        )
        thr.pack(anchor="w", pady=(0, 6))

    def _build_listening_section(self, container):
        card = tk.LabelFrame(
            container,
            text="Ambient Listening",
            bg=theme.COLORS["bg"],
            fg="#77ccff",
            font=(theme.get_font_family(), 11, "bold"),
        )
        card.pack(fill="x", expand=False, padx=8, pady=(0, 8))

        def _add_toggle(text, var, cmd=None):
            cb = tk.Checkbutton(
                card,
                text=text,
                variable=var,
                command=cmd or (lambda: None),
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            )
            cb.pack(anchor="w", pady=2)

        _add_toggle("Desktop Listen (loopback)", self.var_desktop_listen, lambda: None)
        _add_toggle("Ambient Sense", self.var_ambient, self._toggle_ambient)
        tk.Label(
            card,
            text="Desktop listen feeds ImageGrab audio; Ambient Sense gates auto-narration.",
            fg=theme.COLORS["muted"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
            wraplength=360,
            justify="left",
        ).pack(anchor="w", pady=(4, 2))

    def _build_discord_tools(self, container):
        try:
            frame = tk.LabelFrame(
                container,
                text="Discord Bridge",
                bg=theme.COLORS["bg"],
                fg="#77ccff",
                font=(theme.get_font_family(), 11, "bold"),
                bd=1,
                relief="groove",
            )
            frame.pack(fill="x", expand=False, padx=8, pady=(12, 8))

            status = tk.Label(
                frame,
                textvariable=self.var_discord_status,
                bg=theme.COLORS["bg"],
                fg="#9fe8ff",
                font=(theme.get_font_family(), 10, "bold"),
                wraplength=360,
                justify="left",
            )
            status.pack(anchor="w", pady=(4, 6))
            presence_row = tk.Frame(frame, bg=theme.COLORS["bg"])
            presence_row.pack(fill="x", pady=(0, 4))
            tk.Label(
                presence_row,
                text="Presence:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 10),
            ).pack(side="left")
            opt = tk.OptionMenu(
                presence_row,
                self.var_discord_presence,
                "online",
                "idle",
                "dnd",
                "invisible",
            )
            opt.configure(
                bg="#1a1c22",
                fg=theme.COLORS["text"],
                activebackground=theme.COLORS["panel"],
                highlightthickness=0,
            )
            opt.pack(side="left", padx=(4, 6))
            tk.Entry(
                presence_row, textvariable=self.var_discord_presence_note, width=18
            ).pack(side="left", fill="x", expand=True)
            self._make_hud_button(
                presence_row, "Update", self._update_discord_presence
            ).pack(side="left", padx=(6, 0))

            grounded_cb = tk.Checkbutton(
                frame,
                text="Grounded (respond to Father only)",
                variable=self.var_discord_grounded,
                command=self._toggle_discord_grounded,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            )
            grounded_cb.pack(anchor="w", pady=(0, 6))

            self._pack_full_button(frame, "Refresh Status", self._refresh_discord_status)
            self._pack_full_button(frame, "Restart Bridge", self._restart_discord_bridge)

            def _entry_row(label, var, width=30):
                r = tk.Frame(frame, bg=theme.COLORS["bg"])
                r.pack(fill="x", pady=2)
                tk.Label(
                    r,
                    text=label,
                    bg=theme.COLORS["bg"],
                    fg=theme.COLORS["text"],
                    font=(theme.get_font_family(), 10),
                    width=16,
                    anchor="w",
                ).pack(side="left")
                tk.Entry(r, textvariable=var, width=width).pack(
                    side="left", fill="x", expand=True, padx=4
                )

            _entry_row("Owner ID", self.var_discord_owner, width=24)
            _entry_row("Allowed Guild IDs", self.var_discord_allowed_guilds)
            _entry_row("Text Channel IDs", self.var_discord_text)
            _entry_row("Voice Channel ID", self.var_discord_voice)

            tk.Button(
                frame,
                text="Save Discord IDs",
                command=self._save_discord_ids,
                bg="#1c2d2f",
                fg="#77ffcc",
                font=(theme.get_font_family(), 10, "bold"),
            ).pack(anchor="w", pady=(6, 4))

            self._pack_full_button(frame, "Channel Settings…", self._open_channel_settings)
            self._pack_full_button(frame, "Family IDs…", self._open_family_editor)

            tk.Label(
                frame,
                text=(
                    "Bridge will auto-start on launch. Save IDs then restart the app to apply channel or guild changes. "
                    "Provide multiple text channels by separating the IDs with commas, or list entire servers in Allowed Guild IDs."
                ),
                bg=theme.COLORS["bg"],
                fg="#7fa9c2",
                wraplength=360,
                justify="left",
                font=(theme.get_font_family(), 9),
            ).pack(anchor="w", pady=(6, 0))
        except Exception as e:
            tk.Label(
                container,
                text=f"(Discord controls unavailable: {e})",
                fg="#ff7777",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", padx=8, pady=6)

    def _build_gaming_panel(self, parent):
        try:
            card = tk.LabelFrame(
                parent,
                text="Gaming & Stream Monitor",
                bg=theme.COLORS["bg"],
                fg="#9fe8ff",
                font=(theme.get_font_family(), 11, "bold"),
                bd=1,
                relief="groove",
            )
            card.pack(fill="both", expand=False, padx=8, pady=(0, 12))

            tk.Label(
                card,
                textvariable=self.var_stream_status,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 11, "bold"),
                anchor="w",
                wraplength=360,
                justify="left",
            ).pack(anchor="w", pady=(6, 0), padx=6)
            tk.Label(
                card,
                textvariable=self.var_stream_details,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["muted"],
                font=(theme.get_font_family(), 9),
                anchor="w",
                wraplength=360,
                justify="left",
            ).pack(anchor="w", pady=(0, 6), padx=6)

            tk.Checkbutton(
                card,
                text="Game Mode (capture keyboard + stream cues)",
                variable=self.var_game_mode,
                command=self._toggle_game_mode_ui,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
                anchor="w",
            ).pack(fill="x", padx=12, pady=(0, 6))
            tk.Checkbutton(
                card,
                text="Twitch restraint preset (PG-13, calm tone)",
                variable=self.var_twitch_restraint,
                command=self._toggle_twitch_restraint_ui,
                bg=theme.COLORS["bg"],
                fg="#ffbdff",
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
                anchor="w",
            ).pack(fill="x", padx=12, pady=(0, 4))
            tk.Label(
                card,
                text="Keyboard capture:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", padx=12)
            opt_frame = tk.Frame(card, bg=theme.COLORS["bg"])
            opt_frame.pack(fill="x", padx=12, pady=(0, 6))
            key_menu = tk.OptionMenu(
                opt_frame,
                self.var_key_mode,
                "keepawake",
                "learning",
                command=lambda val: self._apply_key_mode(val),
            )
            key_menu.configure(width=14)
            key_menu.pack(anchor="w")
            self._pack_full_button(card, "Open Stream Page", self._open_stream_url)
            self._pack_full_button(
                card,
                "Refresh Now",
                lambda: self._refresh_gaming_status(reschedule=False),
            )

            titan_card = tk.LabelFrame(
                card,
                text="Titanfall 2 Link",
                bg=theme.COLORS["bg"],
                fg="#ffae6b",
                font=(theme.get_font_family(), 10, "bold"),
            )
            titan_card.pack(fill="x", padx=6, pady=(6, 6))
            tk.Label(
                titan_card,
                textvariable=self.var_titanfall_status,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 10, "bold"),
                anchor="w",
                justify="left",
                wraplength=340,
            ).pack(fill="x", padx=6, pady=(4, 0))
            tk.Label(
                titan_card,
                textvariable=self.var_titanfall_detail,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["muted"],
                font=(theme.get_font_family(), 9),
                anchor="w",
                justify="left",
                wraplength=340,
            ).pack(fill="x", padx=6, pady=(0, 4))
            tk.Label(
                titan_card,
                textvariable=self.var_titanfall_mission,
                bg=theme.COLORS["bg"],
                fg="#ffdcb3",
                font=(theme.get_font_family(), 9, "bold"),
                anchor="w",
            ).pack(fill="x", padx=6, pady=(0, 4))
            tk.Label(
                titan_card,
                textvariable=self.var_titanfall_callout,
                bg=theme.COLORS["bg"],
                fg="#ffbdff",
                font=(theme.get_font_family(), 9),
                anchor="w",
                wraplength=340,
                justify="left",
            ).pack(fill="x", padx=6, pady=(0, 4))
            tk.Checkbutton(
                titan_card,
                text="Enable Titanfall monitor",
                variable=self.var_titanfall_enabled,
                command=self._toggle_titanfall_enabled,
                bg=theme.COLORS["bg"],
                fg="#ffdcb3",
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9),
                anchor="w",
            ).pack(fill="x", padx=6, pady=(0, 4))
            tk.Checkbutton(
                titan_card,
                # Shorten label for clarity
                text="Autonomous Ronin",
                variable=self.var_ronin_autonomy,
                command=self._toggle_ronin_autonomy,
                bg=theme.COLORS["bg"],
                fg="#ffc48c",
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9),
                anchor="w",
            ).pack(fill="x", padx=12, pady=(0, 2))
            tk.Checkbutton(
                titan_card,
                # Shorten label for clarity
                text="Learning mode",
                variable=self.var_ronin_learning,
                command=self._toggle_ronin_learning,
                bg=theme.COLORS["bg"],
                fg="#ffdcb3",
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9),
                anchor="w",
            ).pack(fill="x", padx=24, pady=(0, 4))
            row_tf_log = tk.Frame(titan_card, bg=theme.COLORS["bg"])
            row_tf_log.pack(fill="x", padx=6, pady=2)
            tk.Label(
                row_tf_log,
                text="Log file:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9),
            ).pack(side="left")
            tk.Entry(
                row_tf_log,
                textvariable=self.var_titanfall_log,
                width=24,
                state="readonly",
            ).pack(side="left", padx=4)
            self._make_hud_button(
                row_tf_log, "Browse…", self._select_titanfall_log
            ).pack(side="left")
            row_tf_state = tk.Frame(titan_card, bg=theme.COLORS["bg"])
            row_tf_state.pack(fill="x", padx=6, pady=2)
            tk.Label(
                row_tf_state,
                text="Telemetry JSON:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9),
            ).pack(side="left")
            tk.Entry(
                row_tf_state,
                textvariable=self.var_titanfall_state,
                width=21,
                state="readonly",
            ).pack(side="left", padx=4)
            self._make_hud_button(
                row_tf_state, "Browse…", self._select_titanfall_state
            ).pack(side="left")
            # Add a row to apply or reload Titanfall paths when typing paths manually
            self._pack_full_button(
                titan_card, "Apply / Reload paths", self._apply_titanfall_paths
            )
            tk.Label(
                titan_card,
                text="Voice ID:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9),
            ).pack(anchor="w", padx=6)
            tk.Entry(
                titan_card, textvariable=self.var_titanfall_voice_channel, width=24
            ).pack(fill="x", padx=6, pady=(0, 2))
            self._pack_full_button(
                titan_card, "Save Voice ID", self._save_titanfall_voice_channel
            )
            tk.Label(
                titan_card,
                text="Brief ID:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9),
            ).pack(anchor="w", padx=6)
            tk.Entry(
                titan_card, textvariable=self.var_titanfall_briefing_channel, width=24
            ).pack(fill="x", padx=6, pady=(0, 2))
            self._pack_full_button(
                titan_card, "Save Brief ID", self._save_titanfall_briefing_channel
            )
            tk.Label(
                titan_card,
                text="Report ID:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9),
            ).pack(anchor="w", padx=6)
            tk.Entry(
                titan_card, textvariable=self.var_titanfall_report_channel, width=24
            ).pack(fill="x", padx=6, pady=(0, 2))
            self._pack_full_button(
                titan_card, "Save Report ID", self._save_titanfall_report_channel
            )
            tk.Label(
                titan_card,
                text="Idle ID:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9),
            ).pack(anchor="w", padx=6)
            tk.Entry(
                titan_card, textvariable=self.var_titanfall_idle_channel, width=24
            ).pack(fill="x", padx=6, pady=(0, 2))
            self._pack_full_button(
                titan_card, "Save Idle ID", self._save_titanfall_idle_channel
            )
            tk.Label(
                titan_card,
                text="Callsign:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9),
            ).pack(anchor="w", padx=6)
            tk.Entry(
                titan_card, textvariable=self.var_titanfall_callsign, width=24
            ).pack(fill="x", padx=6, pady=(0, 2))
            self._pack_full_button(
                titan_card, "Save Callsign", self._save_titanfall_callsign
            )
            tk.Label(
                titan_card,
                text="Use client_mp.log (Documents/Respawn/Titanfall2/local) and the Northstar telemetry file if installed.",
                bg=theme.COLORS["bg"],
                fg="#ffae6b",
                font=(theme.get_font_family(), 8),
                wraplength=340,
                justify="left",
            ).pack(fill="x", padx=6, pady=(0, 2))
            tk.Checkbutton(
                titan_card,
                text="Auto join Discord voice when a mission starts",
                variable=self.var_titanfall_autovoice,
                command=self._toggle_titanfall_autovoice,
                bg=theme.COLORS["bg"],
                fg="#ffae6b",
                selectcolor=theme.COLORS["panel"],
                activebackground=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9),
                anchor="w",
            ).pack(fill="x", padx=6, pady=(0, 2))
            # Stack voice join/leave buttons vertically to avoid horizontal clipping
            self._pack_full_button(
                titan_card,
                "Join Mission VC",
                lambda: self._manual_join_voice("mission"),
            )
            self._pack_full_button(
                titan_card,
                "Join Idle VC",
                lambda: self._manual_join_voice("idle"),
            )
            self._pack_full_button(
                titan_card,
                "Leave VC",
                self._manual_leave_voice,
            )
            tk.Label(
                titan_card,
                textvariable=self.var_ronin_profile,
                bg=theme.COLORS["bg"],
                fg="#ffdcb3",
                font=(theme.get_font_family(), 9),
                wraplength=340,
                justify="left",
                anchor="w",
            ).pack(fill="x", padx=6, pady=(2, 2))
            self._pack_full_button(
                titan_card,
                "Profile Snapshot",
                lambda: self._refresh_ronin_profile(log=True),
            )

            tk.Label(
                card,
                text="Recent events",
                bg=theme.COLORS["bg"],
                fg="#7fa9c2",
                font=(theme.get_font_family(), 10, "bold"),
            ).pack(anchor="w", padx=6)

            text_frame = tk.Frame(card, bg=theme.COLORS["bg"])
            text_frame.pack(fill="both", expand=True, padx=6, pady=(0, 4))
            txt = tk.Text(
                text_frame,
                height=7,
                wrap="word",
                bg="#10141c",
                fg="#cde6ff",
                insertbackground="#cde6ff",
                relief="flat",
                state="disabled",
            )
            txt.pack(side="left", fill="both", expand=True)
            scroll = tk.Scrollbar(text_frame, command=txt.yview)
            scroll.pack(side="right", fill="y")
            txt.configure(yscrollcommand=scroll.set)
            self._gaming_events_box = txt

            tk.Label(
                card,
                textvariable=self.var_key_heatmap,
                bg=theme.COLORS["bg"],
                fg="#9fe8ff",
                font=(theme.get_font_family(), 10),
                anchor="w",
                justify="left",
                wraplength=360,
            ).pack(anchor="w", padx=6, pady=(2, 2))
            source_card = tk.LabelFrame(
                card,
                text="Source Files",
                bg=theme.COLORS["bg"],
                fg="#77ccff",
                font=(theme.get_font_family(), 10, "bold"),
            )
            source_card.pack(fill="x", padx=6, pady=(0, 4))
            row_log = tk.Frame(source_card, bg=theme.COLORS["bg"])
            row_log.pack(fill="x", pady=2)
            tk.Label(
                row_log,
                text="Minecraft log:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9),
            ).pack(side="left")
            tk.Entry(
                row_log, textvariable=self.var_minecraft_log, width=28, state="readonly"
            ).pack(side="left", padx=4)
            self._make_hud_button(row_log, "Browse…", self._select_minecraft_log).pack(
                side="left"
            )
            row_status = tk.Frame(source_card, bg=theme.COLORS["bg"])
            row_status.pack(fill="x", pady=2)
            tk.Label(
                row_status,
                text="Stream status JSON:",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9),
            ).pack(side="left")
            tk.Entry(
                row_status,
                textvariable=self.var_stream_status_file,
                width=24,
                state="readonly",
            ).pack(side="left", padx=4)
            self._make_hud_button(
                row_status, "Browse…", self._select_stream_status_file
            ).pack(side="left")
            tk.Label(
                source_card,
                text="These paths also save to .env and restart the monitors.",
                bg=theme.COLORS["bg"],
                fg="#7fa9c2",
                font=(theme.get_font_family(), 9),
                wraplength=320,
                justify="left",
            ).pack(anchor="w", padx=2, pady=(2, 0))
            if not self._gaming_status_job:
                try:
                    self._gaming_status_job = self.root.after(
                        1500, self._refresh_gaming_status
                    )
                except Exception:
                    pass
        except Exception as exc:
            tk.Label(
                parent,
                text=f"(Gaming monitor unavailable: {exc})",
                fg="#ff7777",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", padx=8, pady=6)

    def _build_audio_tab(self, parent):
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(
            parent, bg=theme.COLORS["bg"], highlightthickness=0, borderwidth=0
        )
        vbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")

        content = tk.Frame(canvas, bg=theme.COLORS["bg"], padx=10, pady=12)
        content_id = canvas.create_window((10, 10), window=content, anchor="nw")
        content.grid_columnconfigure(0, weight=1)

        def _sync_scrollregion(_evt=None):
            try:
                canvas.configure(scrollregion=canvas.bbox("all"))
            except Exception:
                pass

        def _sync_width(_evt=None):
            try:
                extra = vbar.winfo_width() if vbar.winfo_ismapped() else 0
                canvas.itemconfigure(
                    content_id, width=max(0, canvas.winfo_width() - extra - 4)
                )
            except Exception:
                pass

        content.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_width)
        _sync_width()
        _sync_scrollregion()

        try:

            def _mw_win(e, c=canvas):
                try:
                    c.yview_scroll(int(-1 * (e.delta / 120)), "units")
                except Exception:
                    pass

            def _mw_up(e, c=canvas):
                try:
                    c.yview_scroll(-1, "units")
                except Exception:
                    pass

            def _mw_down(e, c=canvas):
                try:
                    c.yview_scroll(1, "units")
                except Exception:
                    pass

            canvas.bind(
                "<Enter>",
                lambda e: (
                    canvas.bind_all("<MouseWheel>", _mw_win),
                    canvas.bind_all("<Button-4>", _mw_up),
                    canvas.bind_all("<Button-5>", _mw_down),
                ),
            )
            canvas.bind(
                "<Leave>",
                lambda e: (
                    canvas.unbind_all("<MouseWheel>"),
                    canvas.unbind_all("<Button-4>"),
                    canvas.unbind_all("<Button-5>"),
                ),
            )
        except Exception:
            pass

        tk.Label(
            content,
            text="Voice / Audio Control",
            fg="#77ccff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 13, "bold"),
        ).pack(anchor="w", pady=(4, 6))
        tk.Label(
            content,
            text="Manage Discord bridge, stream mode, and hardware routing here.",
            fg="#7fa9c2",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
            wraplength=320,
            justify="left",
        ).pack(anchor="w", pady=(0, 8))

        self._build_local_voice_section(content)
        self._build_listening_section(content)
        self._build_discord_tools(content)
        # Gaming panel now lives in the Game tab; do not build it here

    def _build_game_tab(self, parent):
        """Build the Game tab which contains only the gaming panel (Titanfall/stream status)."""
        # Configure the grid so the canvas expands
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

        # Create a scrollable canvas similar to the audio tab
        canvas = tk.Canvas(
            parent, bg=theme.COLORS["bg"], highlightthickness=0, borderwidth=0
        )
        vbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")

        content = tk.Frame(canvas, bg=theme.COLORS["bg"], padx=10, pady=12)
        content_id = canvas.create_window((10, 10), window=content, anchor="nw")
        content.grid_columnconfigure(0, weight=1)

        def _sync_scrollregion(_evt=None):
            try:
                canvas.configure(scrollregion=canvas.bbox("all"))
            except Exception:
                pass

        def _sync_width(_evt=None):
            try:
                extra = vbar.winfo_width() if vbar.winfo_ismapped() else 0
                canvas.itemconfigure(
                    content_id, width=max(0, canvas.winfo_width() - extra - 4)
                )
            except Exception:
                pass

        content.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_width)

        # Only build the gaming panel here (Titanfall / stream controls)
        self._build_gaming_panel(content)

        try:
            def _mw_win(e, c=canvas):
                try:
                    c.yview_scroll(int(-1 * (e.delta / 120)), "units")
                except Exception:
                    pass

            def _mw_up(e, c=canvas):
                try:
                    c.yview_scroll(-1, "units")
                except Exception:
                    pass

            def _mw_down(e, c=canvas):
                try:
                    c.yview_scroll(1, "units")
                except Exception:
                    pass

            canvas.bind(
                "<Enter>",
                lambda e: (
                    canvas.bind_all("<MouseWheel>", _mw_win),
                    canvas.bind_all("<Button-4>", _mw_up),
                    canvas.bind_all("<Button-5>", _mw_down),
                ),
            )
            canvas.bind(
                "<Leave>",
                lambda e: (
                    canvas.unbind_all("<MouseWheel>"),
                    canvas.unbind_all("<Button-4>"),
                    canvas.unbind_all("<Button-5>"),
                ),
            )
        except Exception:
            pass

    def _build_tablet_tab(self, parent):
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(
            parent, bg=theme.COLORS["bg"], highlightthickness=0, borderwidth=0
        )
        vbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")

        content = tk.Frame(canvas, bg=theme.COLORS["bg"], padx=10, pady=12)
        content_id = canvas.create_window((10, 10), window=content, anchor="nw")
        content.grid_columnconfigure(0, weight=1)

        def _sync_scrollregion(_evt=None):
            try:
                canvas.configure(scrollregion=canvas.bbox("all"))
            except Exception:
                pass

        def _sync_width(_evt=None):
            try:
                extra = vbar.winfo_width() if vbar.winfo_ismapped() else 0
                canvas.itemconfigure(
                    content_id, width=max(0, canvas.winfo_width() - extra - 4)
                )
            except Exception:
                pass

        content.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_width)
        _sync_width()

        try:

            def _mw_win(e, c=canvas):
                try:
                    c.yview_scroll(int(-1 * (e.delta / 120)), "units")
                except Exception:
                    pass

            def _mw_up(e, c=canvas):
                try:
                    c.yview_scroll(-1, "units")
                except Exception:
                    pass

            def _mw_down(e, c=canvas):
                try:
                    c.yview_scroll(1, "units")
                except Exception:
                    pass

            canvas.bind(
                "<Enter>",
                lambda e: (
                    canvas.bind_all("<MouseWheel>", _mw_win),
                    canvas.bind_all("<Button-4>", _mw_up),
                    canvas.bind_all("<Button-5>", _mw_down),
                ),
            )
            canvas.bind(
                "<Leave>",
                lambda e: (
                    canvas.unbind_all("<MouseWheel>"),
                    canvas.unbind_all("<Button-4>"),
                    canvas.unbind_all("<Button-5>"),
                ),
            )
        except Exception:
            pass

        tk.Label(
            content,
            text="Tablet Hub",
            fg="#77ccff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 13, "bold"),
        ).pack(anchor="w", pady=(4, 6))
        tk.Label(
            content,
            text="Monitor the Samsung tablet hub, review connection details, and choose Stable/Dev modes.",
            fg="#7fa9c2",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
            wraplength=320,
            justify="left",
        ).pack(anchor="w", pady=(0, 8))

        tk.Label(
            content,
            textvariable=self.var_tablet_status,
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10, "bold"),
            anchor="w",
        ).pack(anchor="w", pady=(0, 6))

        self._pack_full_button(
            content, "Refresh Status", lambda: self._refresh_tablet_status()
        )
        self._pack_full_button(
            content,
            "Open Hub Folder",
            lambda: self._open_path(self._tablet_status_path.parent),
        )
        self._pack_full_button(
            content,
            "Launch Tablet Agent",
            lambda: self._launch_tablet_agent(),
        )

        details = tk.Text(
            content,
            height=10,
            wrap="word",
            bg=theme.COLORS["panel"],
            fg=theme.COLORS["text"],
            relief="flat",
            state="disabled",
        )
        details.pack(fill="both", expand=True, pady=(0, 8))
        self._tablet_details_widget = details
        if self._tablet_details_buffer:
            try:
                details.configure(state="normal")
                details.delete("1.0", "end")
                details.insert("end", self._tablet_details_buffer + "\n")
                details.configure(state="disabled")
            except Exception:
                pass

        tk.Label(
            content,
            text="Recent tablet mode decisions append to data/tablet_mode_choice.json.",
            fg=theme.COLORS["muted"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 9),
            wraplength=320,
            justify="left",
        ).pack(anchor="w", pady=(0, 4))

    def _open_path(self, path: Path):
        try:
            target = Path(path)
            if sys.platform.startswith("win"):
                os.startfile(str(target))  # type: ignore[attr-defined]
            elif sys.platform.startswith("darwin"):
                subprocess.Popen(["open", str(target)])
            else:
                subprocess.Popen(["xdg-open", str(target)])
        except Exception as exc:
            self.safe_log(f"Unable to open path {path}: {exc}", "#ff5555")

    def _launch_tablet_agent(self):
        script = Path(__file__).resolve().parents[1] / "systems" / "tablet_ops.py"
        if not script.exists():
            self.safe_log("Tablet agent script not found.", "#ff5555")
            return

        def _do_launch():
            try:
                flags = 0
                if sys.platform.startswith("win"):
                    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                subprocess.Popen(
                    [sys.executable, str(script)],
                    cwd=str(script.parent),
                    creationflags=flags,
                )
                self.safe_log("Tablet agent launched.", "#55ff88")
            except Exception as exc:
                self.safe_log(f"Tablet agent launch failed: {exc}", "#ff5555")

        threading.Thread(target=_do_launch, daemon=True).start()

    def _build_tools_panel(self, parent):
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(
            parent, bg=theme.COLORS["bg"], highlightthickness=0, borderwidth=0
        )
        vbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")

        content = tk.Frame(canvas, bg=theme.COLORS["bg"], padx=10, pady=12)
        content_id = canvas.create_window((10, 10), window=content, anchor="nw")
        content.grid_columnconfigure(0, weight=1)

        def _sync_scrollregion(_evt=None):
            try:
                canvas.configure(scrollregion=canvas.bbox("all"))
            except Exception:
                pass

        def _sync_width(_evt=None):
            try:
                extra = vbar.winfo_width() if vbar.winfo_ismapped() else 0
                canvas.itemconfigure(
                    content_id, width=max(0, canvas.winfo_width() - extra - 4)
                )
            except Exception:
                pass

        content.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_width)
        _sync_width()
        _sync_scrollregion()

        try:

            def _mw_win(e, c=canvas):
                try:
                    c.yview_scroll(int(-1 * (e.delta / 120)), "units")
                except Exception:
                    pass

            def _mw_up(e, c=canvas):
                try:
                    c.yview_scroll(-1, "units")
                except Exception:
                    pass

            def _mw_down(e, c=canvas):
                try:
                    c.yview_scroll(1, "units")
                except Exception:
                    pass

            canvas.bind(
                "<Enter>",
                lambda e: (
                    canvas.bind_all("<MouseWheel>", _mw_win),
                    canvas.bind_all("<Button-4>", _mw_up),
                    canvas.bind_all("<Button-5>", _mw_down),
                ),
            )
            canvas.bind(
                "<Leave>",
                lambda e: (
                    canvas.unbind_all("<MouseWheel>"),
                    canvas.unbind_all("<Button-4>"),
                    canvas.unbind_all("<Button-5>"),
                ),
            )
        except Exception:
            pass

        try:
            tk.Label(
                content,
                text="Tools",
                fg="#77ccff",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 13, "bold"),
            ).pack(anchor="w", pady=(6, 8))
            col = tk.Frame(content, bg=theme.COLORS["bg"])
            col.pack(anchor="w", pady=(0, 8))
            self._make_hud_button(col, "Self‑Check", self._run_selfcheck).pack(
                anchor="w", pady=(0, 6)
            )
            self._make_hud_button(col, "Logs", self._open_logs).pack(
                anchor="w", pady=(0, 6)
            )
            self._make_hud_button(col, "Clock / Alarms…", self._open_clock).pack(
                anchor="w", pady=(0, 6)
            )
            try:
                self._make_hud_button(col, "Oscilloscope…", self._open_scope).pack(
                    anchor="w", pady=(0, 6)
                )
            except Exception:
                pass
            self._make_hud_button(col, "Reload", self._reload_systems).pack(
                anchor="w", pady=(0, 6)
            )
            self._make_hud_button(col, "Reboot", self._reboot_app).pack(
                anchor="w", pady=(0, 6)
            )
            self._make_hud_button(
                col, "Shutdown", lambda: self._shutdown_app(confirm=True)
            ).pack(anchor="w", pady=(0, 6))
            self._make_hud_button(col, "Program USB…", self._program_usb_ui).pack(
                anchor="w", pady=(0, 6)
            )
            self._make_hud_button(col, "Skin Designer…", self._open_skin_designer).pack(
                anchor="w", pady=(0, 6)
            )
            self._make_hud_button(
                col, "Purge USB Tokens (keep 2)", self._purge_usb_tokens
            ).pack(anchor="w", pady=(10, 6))
        except Exception as exc:
            tk.Label(
                content,
                text=f"(Tools unavailable: {exc})",
                fg="#ff7777",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", padx=8, pady=4)

        try:
            from runtime import startup as _startup

            if getattr(_startup, "get_session_role", lambda: "owner")() != "user":
                st = tk.Label(
                    content,
                    text=self._daily_status_text(),
                    bg=theme.COLORS["bg"],
                    fg="#77ccff",
                    font=(theme.get_font_family(), 10),
                )
                st.pack(anchor="w", pady=(6, 0))
                self._daily_status_lbl = st
        except Exception:
            pass

    def _shutdown_app(self, confirm: bool = True):
        try:
            if confirm:
                from tkinter import messagebox as _mb

                if not _mb.askyesno(
                    "Shutdown", "Shut down Bjorgsun-26 now?", parent=self.root
                ):
                    return
            try:
                self._save_layout_prefs()
            except Exception:
                pass
            try:
                msg = random.choice(
                    [
                        "Okay — good night.",
                        "See you later!",
                        "Rest well; I’ll be here.",
                    ]
                )
                audio.speak(msg)
            except Exception:
                pass
            try:
                coreloop.shutdown_sequence()
            except Exception:
                pass
            try:
                self.root.after(250, self.root.destroy)
            except Exception:
                self.root.destroy()
        except Exception:
            try:
                self.root.destroy()
            except Exception:
                pass
        finally:
            try:
                self._stop_tray_icon()
            except Exception:
                pass

    def _handle_core_shutdown(self):
        def _close():
            self._stop = True
            try:
                self._save_layout_prefs()
            except Exception:
                pass
            try:
                self.root.destroy()
            except Exception:
                pass
        try:
            self.root.after(0, _close)
        except Exception:
            _close()
        try:
            self._stop_tray_icon()
        except Exception:
            pass

    # -------- System tray helpers --------
    def _start_tray_icon(self):
        if self._tray_icon or not pystray or not Image:
            return
        icon_path = r"B:\Bjorgsun-26\app\NewBjorgIcon.ico"
        if not os.path.exists(icon_path):
            return
        try:
            icon_img = Image.open(icon_path)
        except Exception:
            return

        def _show(_icon=None, _item=None):
            try:
                self.root.deiconify()
                self._bring_to_front()
            except Exception:
                pass

        def _hide(_icon=None, _item=None):
            try:
                self.root.withdraw()
            except Exception:
                pass

        def _dev_console(_icon=None, _item=None):
            try:
                if self._dev_panel and getattr(self._dev_panel, "root", None):
                    self._dev_panel.root.deiconify()
                    self._dev_panel.root.lift()
            except Exception:
                pass

        def _sleep(_icon=None, _item=None):
            try:
                self._sleep_toggle()
            except Exception:
                pass

        def _exit(_icon=None, _item=None):
            try:
                self._shutdown_app(confirm=False)
            except Exception:
                pass

        menu_items = [
            pystray.MenuItem("Show", _show),
            pystray.MenuItem("Hide", _hide),
        ]
        if self._dev_mode:
            menu_items.append(pystray.MenuItem("Dev Console", _dev_console))
        menu_items.extend(
            [
                pystray.MenuItem("Sleep", _sleep),
                pystray.MenuItem("Exit", _exit),
            ]
        )
        menu = pystray.Menu(*menu_items)
        icon = pystray.Icon("Bjorgsun-26", icon_img, "Bjorgsun-26", menu)
        try:
            import threading

            t = threading.Thread(target=icon.run, daemon=True)
            t.start()
        except Exception:
            try:
                icon.run(detached=True)
            except Exception:
                return
        self._tray_icon = icon

    def _stop_tray_icon(self):
        icon = getattr(self, "_tray_icon", None)
        if icon:
            try:
                icon.stop()
            except Exception:
                pass
            self._tray_icon = None

    # -------- USB Programming UI --------
    def _program_usb_ui(self):
        try:
            win = tk.Toplevel(self.root)
            win.title("Program USB Key")
            win.configure(bg=theme.COLORS["bg"])
            win.geometry("420x260")
            tk.Label(
                win,
                text="Select a removable drive and action",
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 11, "bold"),
            ).pack(pady=(8, 6))
            frm = tk.Frame(win, bg=theme.COLORS["bg"])
            frm.pack(fill="both", expand=True, padx=10)
            cols = ("drive", "label")
            tree = ttk.Treeview(frm, columns=cols, show="headings", height=6)
            tree.heading("drive", text="Drive")
            tree.heading("label", text="Label")
            tree.column("drive", width=80)
            tree.column("label", width=260)
            tree.pack(fill="both", expand=True)

            def _enum():
                tree.delete(*tree.get_children())
                for root, label in self._enum_drives_with_labels():
                    tree.insert("", "end", values=(root, label))

            _enum()
            row = tk.Frame(win, bg=theme.COLORS["bg"])
            row.pack(pady=8)
            try:
                from runtime import startup as _startup

                role = getattr(_startup, "get_session_role", lambda: "owner")()
            except Exception:
                role = "owner"
            if role == "user":
                self._make_hud_button(
                    row, "Make Spark Key", lambda: self._usb_make_spark(tree)
                ).pack(side="left", padx=6)
                self._make_hud_button(row, "Refresh", _enum).pack(side="left", padx=6)
            else:
                self._make_hud_button(
                    row,
                    "Program Friend (AHB REST)",
                    lambda: self._usb_program(tree, mode="friend"),
                ).pack(side="left", padx=6)
                self._make_hud_button(
                    row,
                    "Program Father (FFNKB)",
                    lambda: self._usb_program(tree, mode="owner"),
                ).pack(side="left", padx=6)
                self._make_hud_button(
                    row, "Bind Spark → User…", lambda: self._usb_bind_spark(tree)
                ).pack(side="left", padx=6)
                self._make_hud_button(
                    row, "Verify", lambda: self._usb_verify(tree)
                ).pack(side="left", padx=6)
                self._make_hud_button(
                    row,
                    "Wipe/Format USB…",
                    lambda: self._usb_wipe_format(tree),
                ).pack(side="left", padx=6)
                self._make_hud_button(
                    row, "Set Daily (USBMK)", lambda: self._usb_set_daily(tree)
                ).pack(side="left", padx=6)
                self._make_hud_button(row, "Refresh", _enum).pack(side="left", padx=6)
        except Exception as e:
            self.safe_log(f"USB UI error: {e}", "#ff5555")

    def _enum_drives_with_labels(self):
        out = []
        try:
            import ctypes
            import os
            import string

            def _get_label(root: str) -> str:
                try:
                    vol_name_buf = ctypes.create_unicode_buffer(256)
                    fs_name_buf = ctypes.create_unicode_buffer(256)
                    serial = ctypes.c_uint32()
                    max_comp_len = ctypes.c_uint32()
                    file_flags = ctypes.c_uint32()
                    ok = ctypes.windll.kernel32.GetVolumeInformationW(
                        ctypes.c_wchar_p(root),
                        vol_name_buf,
                        ctypes.sizeof(vol_name_buf),
                        ctypes.byref(serial),
                        ctypes.byref(max_comp_len),
                        ctypes.byref(file_flags),
                        fs_name_buf,
                        ctypes.sizeof(fs_name_buf),
                    )
                    return vol_name_buf.value if ok else ""
                except Exception:
                    return ""

            def _get_type(root: str) -> str:
                try:
                    t = ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(root))
                    mapping = {2: "Removable", 3: "Fixed", 4: "Network", 5: "CD-ROM"}
                    return mapping.get(int(t), "Unknown")
                except Exception:
                    return "Unknown"

            for letter in string.ascii_uppercase:
                root = f"{letter}:\\"
                try:
                    if os.path.exists(root):
                        out.append((root, _get_label(root), _get_type(root)))
                except Exception:
                    continue
        except Exception:
            pass
        return out

    def _is_removable_drive(self, root: str) -> bool:
        try:
            import ctypes

            return (
                int(ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(root))) == 2
            )
        except Exception:
            return False

    def _usb_program(self, tree, mode: str):
        try:
            sel = tree.selection()
            if not sel:
                self.safe_log("Select a drive first.", "#ffaa00")
                return
            vals = tree.item(sel[0]).get("values", [])
            if not vals:
                self.safe_log("Drive selection error.", "#ffaa00")
                return
            root = vals[0]
            if not self._is_removable_drive(root):
                self.safe_log(
                    "Make Spark: only removable drives are allowed.", "#ffaa00"
                )
                return
            from tkinter import messagebox as _mb, simpledialog as _sd

            pw = _sd.askstring(
                "Master Password", "Enter master password:", show="•", parent=self.root
            )
            if not pw:
                return
            # Verify without logging the password
            try:
                from runtime import startup as _startup

                if not getattr(_startup, "verify_master", lambda x: False)(pw):
                    self.safe_log("Master password incorrect.", "#ff5555")
                    return
            except Exception:
                self.safe_log("Master password check unavailable.", "#ff5555")
                return
            import os

            # Require explicit consent before writing to the USB device
            if not _mb.askyesno(
                "Confirm USB programming",
                "This will write a key file to the selected USB drive. It will NOT format the drive, "
                "but may overwrite an existing FFNKB.txt. Continue?",
                parent=self.root,
            ):
                self.safe_log("USB programming cancelled by user.", "#ffaa00")
                return

            # Safety: only allow on removable drives
            if not self._is_removable_drive(root):
                self.safe_log(
                    "Program USB: only removable drives are allowed.", "#ffaa00"
                )
                return
            try:
                with open(os.path.join(root, "FFNKB.txt"), "w", encoding="utf-8") as f:
                    f.write(pw)
            except Exception as e:
                self.safe_log(f"Write failed: {e}", "#ff5555")
                return
            # Try to set label; ignore failures
            try:
                import ctypes

                new_label = "AHB REST" if mode == "friend" else "FFNKB"
                ctypes.windll.kernel32.SetVolumeLabelW(
                    ctypes.c_wchar_p(root), ctypes.c_wchar_p(new_label)
                )
            except Exception:
                pass
            self.safe_log(
                f"USB programmed for {'Friend' if mode=='friend' else 'Owner'}.",
                "#55ff88",
            )
        except Exception as e:
            self.safe_log(f"USB program error: {e}", "#ff5555")

    def _usb_wipe_format(self, tree):
        """Dangerous: Wipe/format a removable USB drive with double confirmation."""
        try:
            sel = tree.selection()
            if not sel:
                self.safe_log("Select a drive first.", "#ffaa00")
                return
            vals = tree.item(sel[0]).get("values", [])
            if not vals:
                self.safe_log("Drive selection error.", "#ffaa00")
                return
            root = vals[0]
            if not self._is_removable_drive(root):
                self.safe_log("Wipe: only removable drives are allowed.", "#ffaa00")
                return
            from tkinter import messagebox as _mb, simpledialog as _sd

            warn_msg = (
                f"This will FORMAT {root} (quick NTFS) and erase its data.\n"
                "Ensure you selected the correct removable drive."
            )
            if not _mb.askyesno(
                "Confirm USB wipe",
                warn_msg,
                parent=self.root,
            ):
                self.safe_log("USB wipe cancelled.", "#ffaa00")
                return
            confirm_path = _sd.askstring(
                "Type drive root to confirm",
                f"Type the drive path exactly (e.g., {root}) to proceed:",
                parent=self.root,
            )
            if not confirm_path or confirm_path.strip().lower() != root.strip().lower():
                self.safe_log("USB wipe cancelled (path mismatch).", "#ffaa00")
                return
            final_word = _sd.askstring(
                "FINAL CONFIRMATION",
                "Type WIPE to confirm formatting. Anything else cancels:",
                parent=self.root,
            )
            if (final_word or "").strip().upper() != "WIPE":
                self.safe_log("USB wipe cancelled.", "#ffaa00")
                return
            # Perform quick format via Windows 'format' command
            try:
                drive = root.strip()
                if not drive.endswith("\\"):
                    drive = drive + "\\"
                drive = drive.rstrip("\\")
                cmd = ["cmd.exe", "/c", f"format {drive} /FS:NTFS /Q /V:BJORGSUN /Y"]
                proc = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=120
                )
                if proc.returncode == 0:
                    self.safe_log(f"USB wipe completed for {drive}.", "#55ff88")
                else:
                    err = proc.stderr or proc.stdout or "unknown error"
                    self.safe_log(f"USB wipe failed: {err}", "#ff5555")
            except Exception as e:
                self.safe_log(f"USB wipe error: {e}", "#ff5555")
        except Exception as e:
            self.safe_log(f"USB wipe error: {e}", "#ff5555")

    def _usb_verify(self, tree):
        try:
            sel = tree.selection()
            if not sel:
                self.safe_log("Select a drive first.", "#ffaa00")
                return
            vals = tree.item(sel[0]).get("values", [])
            if not vals:
                self.safe_log("Drive selection error.", "#ffaa00")
                return
            root = vals[0]
            import os

            # Read only allow-listed file
            p = os.path.join(root, "FFNKB.txt")
            if not os.path.exists(p):
                self.safe_log("Verify: FFNKB.txt not found.", "#ffaa00")
                return
            try:
                with open(p, "r", encoding="utf-8", errors="ignore") as f:
                    tok = f.read(256).strip()
            except Exception as e:
                self.safe_log(f"Verify read failed: {e}", "#ff5555")
                return
            ok = False
            try:
                from runtime import startup as _startup

                ok = bool(getattr(_startup, "verify_master", lambda x: False)(tok))
            except Exception:
                ok = False
            if ok:
                # Also show label to help classify friend/owner
                try:
                    import ctypes

                    vol = ctypes.create_unicode_buffer(256)
                    fs = ctypes.create_unicode_buffer(256)
                    s = ctypes.c_uint32()
                    m = ctypes.c_uint32()
                    fl = ctypes.c_uint32()
                    ctypes.windll.kernel32.GetVolumeInformationW(
                        ctypes.c_wchar_p(root),
                        vol,
                        ctypes.sizeof(vol),
                        ctypes.byref(s),
                        ctypes.byref(m),
                        ctypes.byref(fl),
                        fs,
                        ctypes.sizeof(fs),
                    )
                    label = vol.value or ""
                except Exception:
                    label = ""
                role = (
                    "Friend (AHB REST)"
                    if label.strip().lower() == "ahb rest"
                    else "Owner (FFNKB) or Other"
                )
                self.safe_log(
                    f"Verify: VALID master token on {root} — {role}.", "#55ff88"
                )
            else:
                self.safe_log("Verify: token present but INVALID.", "#ff5555")
        except Exception as e:
            self.safe_log(f"USB verify error: {e}", "#ff5555")

    def _usb_set_daily(self, tree):
        try:
            sel = tree.selection()
            if not sel:
                self.safe_log("Select a drive first.", "#ffaa00")
                return
            vals = tree.item(sel[0]).get("values", [])
            if not vals:
                self.safe_log("Drive selection error.", "#ffaa00")
                return
            root = vals[0]
            from runtime import startup as _startup

            ok = getattr(_startup, "set_daily_serial_from_drive", lambda r: False)(root)
            if ok:
                self.safe_log("Daily USBMK set from selected drive.", "#55ff88")
                try:
                    self._daily_status_lbl.config(text=self._daily_status_text())
                except Exception:
                    pass
            else:
                # Try to assist: ensure label = USBMK and write Bjorgsun_Master_Pass.txt
                try:
                    import ctypes
                    import os
                    from tkinter import simpledialog as _sd

                    # Set label if needed
                    try:
                        vol = ctypes.create_unicode_buffer(256)
                        fs = ctypes.create_unicode_buffer(256)
                        s = ctypes.c_uint32()
                        m = ctypes.c_uint32()
                        fl = ctypes.c_uint32()
                        ctypes.windll.kernel32.GetVolumeInformationW(
                            ctypes.c_wchar_p(root),
                            vol,
                            ctypes.sizeof(vol),
                            ctypes.byref(s),
                            ctypes.byref(m),
                            ctypes.byref(fl),
                            fs,
                            ctypes.sizeof(fs),
                        )
                        cur_label = (vol.value or "").strip()
                    except Exception:
                        cur_label = ""
                    if cur_label.lower() != "usbmk":
                        try:
                            ctypes.windll.kernel32.SetVolumeLabelW(
                                ctypes.c_wchar_p(root), ctypes.c_wchar_p("USBMK")
                            )
                            self.safe_log(
                                f"Set volume label to USBMK for {root}", "#77ccff"
                            )
                        except Exception:
                            pass
                    # Write master token file (prompt for master)
                    pw = _sd.askstring(
                        "Master Password",
                        "Enter master password to bind this USBMK:",
                        show="•",
                        parent=self.root,
                    )
                    if pw:
                        try:
                            import hashlib
                            import hmac
                            import os as _os

                            # Legacy plaintext (kept for backward compatibility during migration)
                            with open(
                                os.path.join(root, "Bjorgsun_Master_Pass.txt"),
                                "w",
                                encoding="utf-8",
                            ) as f:
                                f.write(pw)
                            # Preferred: HMAC file with random salt
                            salt = _os.urandom(16)
                            mac = hmac.new(
                                salt, (pw or "").encode("utf-8"), hashlib.sha256
                            ).hexdigest()
                            with open(
                                os.path.join(root, "Bjorgsun_Master_Pass.hmac"),
                                "w",
                                encoding="utf-8",
                            ) as f:
                                f.write(f"SALT:{salt.hex()} HMAC:{mac}\n")
                            self.safe_log(
                                "Wrote master credential (HMAC + legacy) to drive.",
                                "#77ccff",
                            )
                        except Exception as e:
                            self.safe_log(f"Write failed: {e}", "#ff5555")
                    # Retry
                    ok2 = getattr(
                        _startup, "set_daily_serial_from_drive", lambda r: False
                    )(root)
                    if ok2:
                        self.safe_log("Daily USBMK set from selected drive.", "#55ff88")
                        try:
                            self._daily_status_lbl.config(
                                text=self._daily_status_text()
                            )
                        except Exception:
                            pass
                    else:
                        self.safe_log(
                            "Could not set Daily USBMK (ensure label is USBMK and master file matches).",
                            "#ffaa00",
                        )
                except Exception:
                    self.safe_log(
                        "Could not set Daily USBMK (ensure label is USBMK and master file matches).",
                        "#ffaa00",
                    )
        except Exception as e:
            self.safe_log(f"USB set daily error: {e}", "#ff5555")

    def _daily_status_text(self) -> str:
        try:
            from runtime import startup as _startup

            reg = getattr(_startup, "_load_reg", lambda: {})()
            cur = reg.get("daily_serial")
            if cur:
                return f"Daily USBMK serial: {cur}"
            return "Daily USBMK not set. Any valid USBMK accepted."
        except Exception:
            return "Daily USBMK status unavailable."

    def _usb_make_spark(self, tree):
        try:
            try:
                from runtime import startup as _startup

                role = getattr(_startup, "get_session_role", lambda: "user")()
                user = getattr(_startup, "get_session_user", lambda: "")().strip()
            except Exception:
                role = "user"
                user = ""
            if role != "user" and not user:
                # Owner can create a Spark for a named user
                from tkinter import messagebox as _mb, simpledialog as _sd

                user = (
                    _sd.askstring(
                        "User Name", "Enter user name for this Spark:", parent=self.root
                    )
                    or ""
                )
            if not user:
                self.safe_log("No user available to bind Spark.", "#ffaa00")
                return
            # Explicit consent before writing to the USB device
            if not _mb.askyesno(
                "Confirm Spark creation",
                "This will write Spark config files to the selected USB drive. It will NOT format the drive, "
                "but may overwrite existing Spark files. Continue?",
                parent=self.root,
            ):
                self.safe_log("Spark creation cancelled by user.", "#ffaa00")
                return
            sel = tree.selection()
            if not sel:
                self.safe_log("Select a drive first.", "#ffaa00")
                return
            vals = tree.item(sel[0]).get("values", [])
            if not vals:
                self.safe_log("Drive selection error.", "#ffaa00")
                return
            root = vals[0]
            # Write Spark files: label SPARKS, Bjorgsun_pass, SparksUser.txt, and bind serial
            import ctypes
            import os
            import time

            pass_owner = os.getenv("BJORGSUN_PASS", "")
            try:
                # Label
                ctypes.windll.kernel32.SetVolumeLabelW(
                    ctypes.c_wchar_p(root), ctypes.c_wchar_p("SPARKS")
                )
            except Exception:
                pass
            try:
                with open(
                    os.path.join(root, "Bjorgsun_pass"), "w", encoding="utf-8"
                ) as f:
                    f.write(pass_owner)
                with open(
                    os.path.join(root, "SparksUser.txt"), "w", encoding="utf-8"
                ) as f:
                    f.write(user)
                with open(os.path.join(root, "Sparks.log"), "a", encoding="utf-8") as f:
                    f.write(
                        f"{time.strftime('%Y-%m-%d %H:%M:%S')} Spark created for {user}\n"
                    )
            except Exception as e:
                self.safe_log(f"Write failed: {e}", "#ff5555")
                return
            # Bind serial to user
            try:
                # get serial
                vol = ctypes.create_unicode_buffer(256)
                fs = ctypes.create_unicode_buffer(256)
                s = ctypes.c_uint32()
                m = ctypes.c_uint32()
                fl = ctypes.c_uint32()
                ctypes.windll.kernel32.GetVolumeInformationW(
                    ctypes.c_wchar_p(root),
                    vol,
                    ctypes.sizeof(vol),
                    ctypes.byref(s),
                    ctypes.byref(m),
                    ctypes.byref(fl),
                    fs,
                    ctypes.sizeof(fs),
                )
                serial = int(s.value)
                from runtime import startup as _startup

                getattr(_startup, "_register_user", lambda n: True)(user)
                if getattr(_startup, "set_user_spark_serial", lambda u, s: False)(
                    user, serial
                ):
                    self.safe_log(
                        f"Spark bound to {user} (serial {serial}).", "#55ff88"
                    )
                else:
                    self.safe_log("Failed to bind Spark to user.", "#ffaa00")
            except Exception as e:
                self.safe_log(f"Bind error: {e}", "#ff5555")
        except Exception as e:
            self.safe_log(f"Make Spark error: {e}", "#ff5555")

    def _usb_bind_spark(self, tree):
        """Owner-only: bind selected SPARKS drive's serial to a registered user."""
        try:
            try:
                from runtime import startup as _startup

                role = getattr(_startup, "get_session_role", lambda: "owner")()
            except Exception:
                role = "owner"
            if role == "user":
                self.safe_log("Only father can bind Spark keys.", "#ffaa00")
                return
            sel = tree.selection()
            if not sel:
                self.safe_log("Select a drive first.", "#ffaa00")
                return
            vals = tree.item(sel[0]).get("values", [])
            if not vals:
                self.safe_log("Drive selection error.", "#ffaa00")
                return
            root = vals[0]
            # Confirm it's a SPARKS drive
            import ctypes
            import os

            vol = ctypes.create_unicode_buffer(256)
            fs = ctypes.create_unicode_buffer(256)
            s = ctypes.c_uint32()
            m = ctypes.c_uint32()
            fl = ctypes.c_uint32()
            ok = ctypes.windll.kernel32.GetVolumeInformationW(
                ctypes.c_wchar_p(root),
                vol,
                ctypes.sizeof(vol),
                ctypes.byref(s),
                ctypes.byref(m),
                ctypes.byref(fl),
                fs,
                ctypes.sizeof(fs),
            )
            if not ok or (vol.value or "").strip().lower() != "sparks":
                self.safe_log("Select a SPARKS drive to bind.", "#ffaa00")
                return
            # Ask user name to bind
            from tkinter import simpledialog as _sd

            user = (
                _sd.askstring(
                    "Bind Spark",
                    "Enter user's name to bind this Spark:",
                    parent=self.root,
                )
                or ""
            )
            user = user.strip()
            if not user:
                return
            # Ensure user is registered
            try:
                _startup._register_user(user)
            except Exception:
                pass
            serial = int(s.value)
            if getattr(_startup, "set_user_spark_serial", lambda u, s: False)(
                user, serial
            ):
                self.safe_log(f"Spark bound to {user} (serial {serial}).", "#55ff88")
            else:
                self.safe_log("Failed to bind Spark to user.", "#ffaa00")
        except Exception as e:
            self.safe_log(f"Bind Spark error: {e}", "#ff5555")
        tk.Label(
            body,
            text="VAD Stop Silence (ms)",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
        ).pack(anchor="w")
        sil = tk.Scale(
            body,
            from_=400,
            to=3000,
            resolution=100,
            orient="horizontal",
            variable=self.var_vad_sil_ms,
            showvalue=True,
            length=180,
        )
        sil.configure(
            bg=theme.COLORS["bg"],
            fg=theme.COLORS["text"],
            troughcolor=theme.COLORS["panel"],
            highlightthickness=0,
        )
        sil.pack(anchor="w", pady=(0, 6))
        # Text/UI preferences
        add_toggle(
            "Show Face Display", self.var_face_display, self._toggle_face_display
        )
        add_toggle("Cute Faces in Text", self.var_faces, lambda: None)
        add_toggle(
            "Heartbeat ➜ Console (verbose)", self.var_heartbeat_console, lambda: None
        )
        self._make_hud_button(
            body, "Profile Summary…", self._show_profile_summary
        ).pack(anchor="w", pady=(2, 6))
        # Safety mode
        try:
            self.var_safety = tk.StringVar(value="balanced")
            tk.Label(
                body,
                text="Safety Mode",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(6, 2))
            opt2 = tk.OptionMenu(
                body,
                self.var_safety,
                "strict",
                "balanced",
                "creative",
                command=lambda v: self._set_safety(v),
            )
            opt2.configure(
                bg="#1a1c22",
                fg=theme.COLORS["text"],
                activebackground=theme.COLORS["panel"],
                highlightthickness=0,
            )
            opt2.pack(anchor="w", pady=(0, 6))
        except Exception:
            pass
        # XSOverlay VR output integration
        add_toggle("XSOverlay VR Output", self.var_xso, self._toggle_xso)
        self._make_hud_button(body, "Test XSOverlay", self._test_xso).pack(
            anchor="w", pady=(0, 8)
        )

        # U.S.B.M.K. (USB Master Key) tools
        tk.Label(
            body,
            text="U.S.B.M.K.",
            fg="#77ccff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 12, "bold"),
        ).pack(anchor="w", pady=(10, 4))
        self._make_hud_button(body, "Reprogram U.S.B.M.K.", self._reprogram_usbmk).pack(
            anchor="w", pady=(0, 6)
        )
        self._make_hud_button(body, "Test U.S.B.M.K.", self._test_usbmk).pack(
            anchor="w", pady=(0, 8)
        )

        # Emergency controls
        tk.Label(
            body,
            text="Emergency",
            fg="#ff5555",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 12, "bold"),
        ).pack(anchor="w", pady=(10, 2))
        try:
            big = self._make_big_button(
                body,
                text="",
                color="#ff5555",
                command=self._engage_restswitch,
                skin_key="emergency",
            )
            big.pack(anchor="w", pady=(0, 8))
        except Exception:
            self._make_hud_button(
                body, "Engage Calm Shutdown", self._engage_restswitch
            ).pack(anchor="w", pady=(0, 8))
        try:
            rate_val, pitch_val = audio.get_voice_params()
            current_voice = getattr(audio, "get_voice_name", lambda: (TTS_VOICE or "alloy"))()
            tk.Label(
                body,
                text="Voice Rate",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(8, 0))
            self.var_rate = tk.DoubleVar(value=rate_val)
            rate = tk.Scale(
                body,
                from_=0.8,
                to=1.2,
                resolution=0.01,
                orient="horizontal",
                variable=self.var_rate,
                showvalue=True,
                length=180,
                command=lambda v: audio.set_voice_rate(float(v)),
            )
            rate.configure(
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                troughcolor=theme.COLORS["panel"],
                highlightthickness=0,
            )
            rate.pack(anchor="w")
            tk.Label(
                body,
                text="TTS Voice",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(6, 0))
            voices = sorted(getattr(audio, "_VALID_TTS_VOICES", ["alloy", "nova", "onyx"]))
            self.var_voice_name = tk.StringVar(value=current_voice)
            voice_combo = ttk.Combobox(
                body,
                textvariable=self.var_voice_name,
                values=voices,
                state="readonly",
            )
            voice_combo.pack(anchor="w", pady=(0, 6))
            voice_combo.configure(width=14)

            def _on_voice_change(event=None):
                val = (self.var_voice_name.get() or "").strip().lower()
                try:
                    audio.set_tts_voice(val)
                    # persist to .env so next boot sticks
                    self._persist_env("TTS_VOICE", val)
                    self.safe_log(f"TTS voice set to {val or 'alloy'}.", "#77ccff")
                except Exception as exc:
                    self.safe_log(f"Unable to set voice: {exc}", "#ff7777")

            voice_combo.bind("<<ComboboxSelected>>", _on_voice_change)

            tk.Label(
                body,
                text="Voice Pitch (semitones)",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w")
            self.var_pitch = tk.DoubleVar(value=pitch_val)
            pitch = tk.Scale(
                body,
                from_=-4,
                to=4,
                resolution=0.5,
                orient="horizontal",
                variable=self.var_pitch,
                showvalue=True,
                length=180,
                command=lambda v: audio.set_voice_pitch(float(v)),
            )
            pitch.configure(
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                troughcolor=theme.COLORS["panel"],
                highlightthickness=0,
            )
            pitch.pack(anchor="w", pady=(0, 6))
            tk.Label(
                body,
                text="Text Reveal Speed",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w")
            self.var_reveal = tk.DoubleVar(value=1.0)
            rev = tk.Scale(
                body,
                from_=0.25,
                to=3.0,
                resolution=0.05,
                orient="horizontal",
                variable=self.var_reveal,
                showvalue=True,
                length=180,
                command=lambda v: audio.set_reveal_speed(float(v)),
            )
            rev.configure(
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                troughcolor=theme.COLORS["panel"],
                highlightthickness=0,
            )
            rev.pack(anchor="w", pady=(0, 6))
        except Exception:
            pass
        # AI Hears / TTS
        tk.Label(
            body,
            text="AI Hears (Bus A2)",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
        ).pack(anchor="w", pady=(6, 2))
        self.device_menu = tk.OptionMenu(
            body, self.var_device, "", command=lambda v: self._set_device(v)
        )
        self.device_menu.configure(
            bg="#1a1c22",
            fg=theme.COLORS["text"],
            activebackground=theme.COLORS["panel"],
            highlightthickness=0,
        )
        self.device_menu.pack(anchor="w", pady=(0, 4))
        self._make_hud_button(body, "Refresh Devices", self._refresh_devices).pack(
            anchor="w"
        )
        self._make_hud_button(
            body, "Test Desktop Listen (5s)", self._test_desktop_listen
        ).pack(anchor="w", pady=(6, 0))
        try:
            tk.Label(
                body,
                text="TTS Output Device",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(10, 2))
            self.tts_menu = tk.OptionMenu(
                body, self.var_tts, "", command=lambda v: self._set_tts_device(v)
            )
            self.tts_menu.configure(
                bg="#1a1c22",
                fg=theme.COLORS["text"],
                activebackground=theme.COLORS["panel"],
                highlightthickness=0,
            )
            self.tts_menu.pack(anchor="w", pady=(0, 4))
            self._make_hud_button(
                body, "Refresh TTS Devices", self._refresh_tts_devices
            ).pack(anchor="w")
            self._make_hud_button(
                body, "Discord Mode Preset", self._apply_discord_preset
            ).pack(anchor="w", pady=(8, 0))
            self._make_hud_button(
                body, "Private Mode Preset", self._apply_private_preset
            ).pack(anchor="w", pady=(4, 0))
            self._make_hud_button(
                body, "Stream Mode Preset", self._apply_stream_preset
            ).pack(anchor="w", pady=(4, 0))
            self._make_hud_button(
                body, "Install pyVoicemeeter", self._install_vm_helper
            ).pack(anchor="w", pady=(6, 0))
            tk.Label(
                body,
                text="TTS Output Route",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(10, 2))
            route_box = tk.Frame(body, bg=theme.COLORS["bg"])
            route_box.pack(anchor="w", fill="x", pady=(0, 4))
            for label, mode in (
                ("Local Speakers", "local"),
                ("Discord Voice", "discord"),
                ("Local + Discord", "both"),
            ):
                tk.Radiobutton(
                    route_box,
                    text=label,
                    value=mode,
                    variable=self.var_tts_route,
                    indicatoron=False,
                    width=18,
                    command=lambda m=mode: self._set_tts_route(m),
                    bg="#1a1c22",
                    fg=theme.COLORS["text"],
                    selectcolor=theme.COLORS["panel"],
                    activebackground=theme.COLORS["panel"],
                ).pack(fill="x", pady=1)
            tk.Label(
                body,
                textvariable=self.var_discord_status,
                fg="#77ccff",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9, "italic"),
            ).pack(anchor="w", pady=(4, 0))
        except Exception:
            pass
        try:
            tk.Label(
                body,
                text="Routing Mode",
                fg=theme.COLORS["text"],
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(10, 0))
            self.var_route = tk.IntVar(value=2)
            rt = tk.Scale(
                body,
                from_=1,
                to=3,
                orient="horizontal",
                showvalue=False,
                length=180,
                variable=self.var_route,
                command=lambda v: self._on_route_change(int(float(v))),
            )
            rt.configure(
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                troughcolor=theme.COLORS["panel"],
                highlightthickness=0,
            )
            rt.pack(anchor="w")
            lf = tk.Frame(body, bg=theme.COLORS["bg"])
            lf.pack(anchor="w", pady=(0, 6))
            tk.Label(
                lf,
                text="Discord",
                fg="#777",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9),
            ).pack(side="left")
            tk.Label(lf, text="  |  ", fg="#444", bg=theme.COLORS["bg"]).pack(
                side="left"
            )
            tk.Label(
                lf,
                text="Private",
                fg="#ccc",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9),
            ).pack(side="left")
            tk.Label(lf, text="  |  ", fg="#444", bg=theme.COLORS["bg"]).pack(
                side="left"
            )
            tk.Label(
                lf,
                text="Stream",
                fg="#777",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 9),
            ).pack(side="left")
        except Exception:
            pass

        # Corner accents for Settings
        def _draw_corners_set(_evt=None):
            try:
                canvas.delete("corners")
                w = max(0, int(canvas.winfo_width() or 0))
                h = max(0, int(canvas.winfo_height() or 0))
                try:
                    acc, glow = theme.accent_for_mood(mood.get_mood())
                except Exception:
                    acc, glow = theme.COLORS["accent"], theme.COLORS["accent_glow"]
                canvas.create_line(6, 6, 28, 6, fill=acc, width=2, tags=("corners",))
                canvas.create_line(6, 6, 6, 26, fill=acc, width=2, tags=("corners",))
                canvas.create_line(6, 8, 22, 8, fill=glow, width=1, tags=("corners",))
                canvas.create_line(8, 6, 8, 22, fill=glow, width=1, tags=("corners",))
                canvas.create_line(
                    w - 28, 6, w - 6, 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    w - 6, 6, w - 6, 26, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    w - 22, 8, w - 6, 8, fill=glow, width=1, tags=("corners",)
                )
                canvas.create_line(
                    w - 8, 6, w - 8, 22, fill=glow, width=1, tags=("corners",)
                )
                canvas.create_line(
                    6, h - 6, 28, h - 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    6, h - 26, 6, h - 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    6, h - 8, 22, h - 8, fill=glow, width=1, tags=("corners",)
                )
                canvas.create_line(
                    8, h - 22, 8, h - 6, fill=glow, width=1, tags=("corners",)
                )
                canvas.create_line(
                    w - 28, h - 6, w - 6, h - 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    w - 6, h - 26, w - 6, h - 6, fill=acc, width=2, tags=("corners",)
                )
                canvas.create_line(
                    w - 22, h - 8, w - 6, h - 8, fill=glow, width=1, tags=("corners",)
                )
                canvas.create_line(
                    w - 8, h - 22, w - 8, h - 6, fill=glow, width=1, tags=("corners",)
                )
            except Exception:
                pass

        canvas.bind("<Configure>", _draw_corners_set)

    def _toggle_voice(self):
        self.voice_enabled = bool(self.var_voice.get())
        state = "ON" if self.voice_enabled else "OFF"
        self.safe_log(f"🔊 Voice output: {state}", "#ffaa00")
        try:
            audio.set_voice_enabled(self.voice_enabled)
        except Exception:
            pass
        try:
            self._persist_env("UI_VOICE", "1" if self.voice_enabled else "0")
        except Exception:
            pass

    def _toggle_listen(self):
        self.listen_enabled = bool(self.var_listen.get())
        state = "ON" if self.listen_enabled else "OFF"
        self.safe_log(f"🎧 Push-to-talk: {state}", "#ffaa00")
        try:
            self._persist_env("UI_LISTEN", "1" if self.listen_enabled else "0")
        except Exception:
            pass

    def _toggle_hush(self):
        try:
            from systems import audio as _audio

            _audio.set_hush(not _audio.get_hush())
            state = "ON" if _audio.get_hush() else "OFF"
            self.safe_log(f"🔇 Hush: {state}", "#ffaa00")
            try:
                self._refresh_hush_button()
            except Exception:
                pass
        except Exception as e:
            self.safe_log(f"Hush error: {e}", "#ff5555")

    def _set_mode(self, mode):
        try:
            from systems import audio as _audio

            _audio.set_mode(mode)
            self._update_cognition_badge()
            self.safe_log(f"🧠 Cognition mode set to {mode}", "#ffaa00")
            try:
                self._persist_env("COGNITION_MODE", mode)
            except Exception:
                pass
        except Exception:
            pass

    def _auto_vm_setup_ui(self):
        mode = (self.var_vm_mode.get() or "private").strip().lower()

        def _do():
            try:
                from systems import voicemeeter as _vm

                ok, logs, info = _vm.auto_setup(mode)
                for line in logs:
                    self.safe_log(line, "#55ff88" if ok else "#ffaa00")
                if info:
                    self.root.after(0, lambda: self._update_vm_entries(info))
            except Exception as e:
                self.safe_log(f"[VM] Auto-setup error: {e}", "#ff5555")

        threading.Thread(target=_do, daemon=True).start()

    def _apply_selected_vm_preset(self):
        mode = (self.var_vm_mode.get() or "private").strip().lower()
        if mode == "discord":
            self._apply_discord_preset()
        elif mode == "stream":
            self._apply_stream_preset()
        else:
            self._apply_private_preset()

    def _apply_vm_devices(self):
        a1 = (self.var_vm_a1.get() or "").strip() or None
        a2 = (self.var_vm_a2.get() or "").strip() or None

        def _do():
            try:
                from systems import voicemeeter as _vm

                ok, msg = _vm.apply_devices(a1, a2)
                self.safe_log(msg, "#55ff88" if ok else "#ffaa00")
                if ok:
                    try:
                        if a1 is not None:
                            self._persist_env("VM_A1_LABEL", a1)
                        if a2 is not None:
                            self._persist_env("VM_A2_LABEL", a2)
                    except Exception:
                        pass
            except Exception as e:
                self.safe_log(f"[VM] Device apply error: {e}", "#ff5555")

        threading.Thread(target=_do, daemon=True).start()

    def _apply_vm_scene(self):
        label = (self.var_vm_scene.get() or "").strip()
        scene_id = self._vm_scene_lookup.get(label, label)
        if not scene_id:
            self.safe_log("[VM] Select a scene first.", "#ffaa00")
            return

        def _do():
            try:
                from systems import voicemeeter as _vm

                ok, msg = _vm.apply_scene(scene_id)
                self.safe_log(msg, "#55ff88" if ok else "#ff5555")
            except Exception as e:
                self.safe_log(f"[VM] Scene apply error: {e}", "#ff5555")

        threading.Thread(target=_do, daemon=True).start()

    def _save_vm_hints(self):
        try:
            self._persist_env("DESKTOP_DEVICE_HINT", self.var_vm_desktop.get().strip())
            self._persist_env("TTS_OUTPUT_DEVICE_HINT", self.var_vm_tts.get().strip())
            scene_label = (self.var_vm_scene.get() or "").strip()
            scene_id = self._vm_scene_lookup.get(scene_label, scene_label)
            if scene_id:
                self._persist_env("VM_SCENE", scene_id)
            self.safe_log("[VM] Capture hints saved to .env.", "#55ff88")
        except Exception as e:
            self.safe_log(f"[VM] Save hints error: {e}", "#ff5555")

    def _apply_vm_routes(self):
        config = {
            "mic": {
                "a1": self.var_vm_mic_a1.get(),
                "a2": self.var_vm_mic_a2.get(),
                "b1": self.var_vm_mic_b1.get(),
                "b2": self.var_vm_mic_b2.get(),
            },
            "vaio": {
                "a1": self.var_vm_vaio_a1.get(),
                "b1": self.var_vm_vaio_b1.get(),
            },
            "aux": {
                "a1": self.var_vm_aux_a1.get(),
                "a2": self.var_vm_aux_a2.get(),
                "b1": self.var_vm_aux_b1.get(),
            },
        }

        def _do():
            try:
                from systems import voicemeeter as _vm

                ok, msg = _vm.apply_custom(config)
                self.safe_log(msg, "#55ff88" if ok else "#ffaa00")
            except Exception as e:
                self.safe_log(f"[VM] Custom routing error: {e}", "#ff5555")

        threading.Thread(target=_do, daemon=True).start()

    def _update_vm_entries(self, info: dict):
        try:
            if info.get("a1") is not None:
                self.var_vm_a1.set(info["a1"])
            if info.get("a2") is not None:
                self.var_vm_a2.set(info["a2"])
            if info.get("desktop") is not None:
                self.var_vm_desktop.set(info["desktop"])
                self.var_device.set(info["desktop"])
            if info.get("tts") is not None:
                self.var_vm_tts.set(info["tts"])
                self.var_tts.set(info["tts"])
        except Exception:
            pass

    def _list_audio_outputs(self):
        def _do():
            try:
                from systems import voicemeeter as _vm

                devices = _vm.list_output_devices()
                if not devices:
                    self.safe_log(
                        "[audio] No output devices reported (sounddevice missing?).",
                        "#ffaa00",
                    )
                    return
                self.safe_log("[audio] Output devices:", "#77ccff")
                for label in devices:
                    self.safe_log(f" • {label}", "#77ccff")
            except Exception as e:
                self.safe_log(f"[audio] Device list error: {e}", "#ff5555")

        threading.Thread(target=_do, daemon=True).start()

    def _set_chat_model(self, model):
        try:
            from systems import audio as _audio

            _audio.set_chat_model(model)
            self.safe_log(f"🧠 OpenAI model set to {model}", "#ffaa00")
            try:
                self._persist_env("OPENAI_MODEL_CHAT", model or "")
            except Exception:
                pass
            self._update_cognition_badge()
        except Exception as e:
            self.safe_log(f"Model switch failed: {e}", "#ff5555")

    # ------------------------------------------------------------------
    # Tablet dock prompts (Stable vs Dev selection)
    # ------------------------------------------------------------------
    def _poll_tablet_prompt(self):
        try:
            mtime = self._tablet_prompt_path.stat().st_mtime
        except FileNotFoundError:
            mtime = 0.0
        except Exception:
            mtime = getattr(self, "_tablet_prompt_mtime", 0.0)
        if mtime and mtime > getattr(self, "_tablet_prompt_mtime", 0.0):
            self._tablet_prompt_mtime = mtime
            self._handle_tablet_prompt()
        try:
            self.root.after(2000, self._poll_tablet_prompt)
        except Exception:
            pass

    def _schedule_tablet_status_refresh(self):
        try:
            self._refresh_tablet_status()
        except Exception:
            pass
        try:
            self.root.after(5000, self._schedule_tablet_status_refresh)
        except Exception:
            pass

    def _handle_tablet_prompt(self):
        try:
            with self._tablet_prompt_path.open("r", encoding="utf-8") as fh:
                payload = json.load(fh)
        except FileNotFoundError:
            return
        except Exception as exc:
            self.safe_log(f"Tablet prompt parse error: {exc}", "#ff5555")
            return
        tablet = payload.get("tablet") or {}
        label = tablet.get("model") or tablet.get("serial") or "tablet"
        self.safe_log(
            f"Tablet docked ({label}). Awaiting mode selection…", "#77ccff"
        )
        try:
            self._refresh_tablet_status()
        except Exception:
            pass
        self._show_tablet_prompt_modal(payload)

    def _show_tablet_prompt_modal(self, payload: dict):
        try:
            if (
                self._tablet_prompt_window is not None
                and self._tablet_prompt_window.winfo_exists()
            ):
                self._tablet_prompt_window.destroy()
        except Exception:
            pass
        win = tk.Toplevel(self.root)
        self._tablet_prompt_window = win
        win.title("Tablet Docked • Choose Mode")
        win.configure(bg=theme.COLORS["bg"])
        win.resizable(False, False)
        info = payload.get("tablet") or {}
        tk.Label(
            win,
            text=f"{info.get('brand', '').title()} {info.get('model', '')}".strip(),
            bg=theme.COLORS["bg"],
            fg=theme.COLORS["accent"],
            font=(theme.get_font_family(), 14, "bold"),
        ).pack(anchor="w", padx=14, pady=(12, 4))
        meta_lines = [
            f"Android {info.get('android_version', '?')} (SDK {info.get('sdk', '?')})",
            f"Build {info.get('build_id', '?')}",
        ]
        storage = info.get("storage") or {}
        if storage:
            meta_lines.append(
                f"Storage: {storage.get('used', '?')} used / {storage.get('available', '?')} free"
            )
        tk.Label(
            win,
            text="\n".join(meta_lines),
            bg=theme.COLORS["bg"],
            fg=theme.COLORS["muted"],
            justify="left",
            font=(theme.get_font_family(), 10),
        ).pack(anchor="w", padx=14, pady=(0, 12))
        req = payload.get("mode_request") or {}
        options = req.get("options") or []
        button_frame = tk.Frame(win, bg=theme.COLORS["bg"])
        button_frame.pack(fill="x", padx=14, pady=(0, 12))
        if not options:
            tk.Label(
                button_frame,
                text="No mode options supplied.",
                fg="#ff7777",
                bg=theme.COLORS["bg"],
            ).pack(anchor="w")
        for opt in options:
            btn = self._make_hud_button(
                button_frame,
                opt.get("label", opt.get("id", "mode")).strip(),
                lambda o=opt: self._on_tablet_mode_choice(o, payload),
            )
            btn.configure(width=22)
            btn.pack(anchor="w", pady=4)
            desc = opt.get("description")
            if desc:
                tk.Label(
                    button_frame,
                    text=desc,
                    bg=theme.COLORS["bg"],
                    fg=theme.COLORS["muted"],
                    font=(theme.get_font_family(), 9),
                    wraplength=360,
                    justify="left",
                ).pack(anchor="w", padx=(8, 0), pady=(0, 4))

    def _on_tablet_mode_choice(self, option: dict, payload: dict):
        choice = option.get("id") or "stable"
        source = option.get("source") or "desktop-ui"
        try:
            self._write_tablet_choice_file(
                {
                    "selected_mode": choice,
                    "label": option.get("label"),
                    "source": source,
                    "timestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
                    "prompt_timestamp": payload.get("timestamp"),
                }
            )
            self.safe_log(f"Tablet mode → {choice} (desktop)", "#55ff88")
        except Exception as exc:
            self.safe_log(f"Tablet choice write failed: {exc}", "#ff5555")
        finally:
            try:
                if (
                    self._tablet_prompt_window is not None
                    and self._tablet_prompt_window.winfo_exists()
                ):
                    self._tablet_prompt_window.destroy()
            except Exception:
                pass

    def _write_tablet_choice_file(self, data: dict):
        tmp = self._tablet_choice_path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
        tmp.replace(self._tablet_choice_path)

    def _refresh_tablet_status(self):
        try:
            with self._tablet_status_path.open("r", encoding="utf-8") as fh:
                payload = json.load(fh)
        except FileNotFoundError:
            payload = {}
        except Exception as exc:
            self.var_tablet_status.set(f"Tablet status: error reading file ({exc}).")
            return
        if not payload:
            self.var_tablet_status.set("Tablet status: waiting for agent.")
            return
        connected = payload.get("connected")
        tablet = payload.get("tablet") or {}
        if connected:
            model = tablet.get("model") or tablet.get("serial") or "tablet"
            self.var_tablet_status.set(f"Tablet connected: {model}")
        else:
            self.var_tablet_status.set("Tablet disconnected.")
        lines = []
        if tablet:
            lines.append(f"Serial: {tablet.get('serial', 'n/a')}")
            lines.append(f"Brand: {tablet.get('brand', 'n/a')}")
            lines.append(
                f"Android {tablet.get('android_version', '?')} (SDK {tablet.get('sdk', '?')})"
            )
            lines.append(f"Build: {tablet.get('build_id', 'unknown')}")
            lines.append(f"Hardware: {tablet.get('hardware', 'unknown')}")
            storage = tablet.get("storage") or {}
            if storage:
                lines.append(
                    f"Storage: {storage.get('used','?')} used / {storage.get('available','?')} free"
                )
        details = "\n".join(lines) if lines else "No telemetry yet."
        self._tablet_details_buffer = details
        widget = getattr(self, "_tablet_details_widget", None)
        if widget and hasattr(widget, "configure"):
            try:
                widget.configure(state="normal")
                widget.delete("1.0", "end")
                widget.insert("end", details + "\n")
                widget.configure(state="disabled")
            except Exception:
                pass

    def _set_safety(self, mode):
        try:
            # Persist simple env flag so audio.build_prompt can read it
            self._persist_env("BJORGSUN_SAFETY", (mode or "balanced"))
            self.safe_log(f"Safety mode: {mode}", "#ffaa00")
        except Exception:
            pass

    def _test_openai(self):
        try:
            from systems import audio as _audio

            ok, msg = _audio.test_openai()
            color = "#55ff88" if ok else "#ffaa00"
            self.safe_log(f"[OpenAI test] {msg}", color)
            self._update_cognition_badge()
        except Exception as e:
            self.safe_log(f"[OpenAI test] error: {e}", "#ffaa00")

    def _refresh_devices(self):
        try:
            from systems import stt

            devs = stt.list_output_devices()
            menu = self.device_menu["menu"]
            menu.delete(0, "end")
            if not devs:
                devs = [""]
            for d in devs:
                menu.add_command(label=d, command=lambda v=d: self.var_device.set(v))
            # Set current to hint if present
            try:
                hint = stt.get_desktop_hint()
                if hint:
                    self.var_device.set(hint)
            except Exception:
                pass
        except Exception as e:
            self.safe_log(f"[Devices] {e}", "#ffaa00")

    def _set_device(self, value):
        try:
            from systems import stt

            stt.set_desktop_hint(value)
            self.safe_log(f"🔊 AI Hears (Bus A2) set to: {value}", "#ffaa00")
            try:
                self._persist_env("DESKTOP_DEVICE_HINT", value or "")
            except Exception:
                pass
        except Exception:
            pass

    def _refresh_tts_devices(self):
        try:
            from systems import stt

            devs = stt.list_output_devices()
            menu = self.tts_menu["menu"]
            menu.delete(0, "end")
            if not devs:
                devs = [""]
            for d in devs:
                menu.add_command(label=d, command=lambda v=d: self.var_tts.set(v))
            try:
                from systems import audio as _audio

                hint = getattr(_audio, "get_tts_device_hint", lambda: "")()
                if hint:
                    self.var_tts.set(hint)
            except Exception:
                pass
        except Exception as e:
            self.safe_log(f"[TTS Devices] {e}", "#ffaa00")

    def _refresh_discord_status(self):
        try:
            info = discord_bridge.get_status()
            grounded = info.get("grounded")
            grounded_txt = " | grounded" if grounded else ""
            twitch = info.get("twitch_restraint")
            twitch_txt = " | Twitch mode" if twitch else ""
            if info.get("ready"):
                voice = "voice linked" if info.get("voice_connected") else "listening"
                queue = info.get("pending_requests", 0)
                status = f"Discord bridge: online ({voice}, {queue} queued){grounded_txt}{twitch_txt}"
            else:
                status = f"Discord bridge: offline{grounded_txt}{twitch_txt}"
        except Exception as exc:
            status = f"Discord bridge: unavailable ({exc})"
        self.var_discord_status.set(status)
        try:
            if self.root:
                self.root.after(4000, self._refresh_discord_status)
        except Exception:
            pass

    def _toggle_game_mode_ui(self):
        flag = bool(self.var_game_mode.get())
        try:
            gaming_bridge.set_game_mode(flag)
            self.safe_log(
                f"🎮 Gaming mode {'enabled' if flag else 'disabled'}.", "#77ccff"
            )
        except Exception as exc:
            self.safe_log(f"Gaming bridge unavailable: {exc}", "#ff5555")

    def _toggle_twitch_restraint_ui(self):
        flag = bool(self.var_twitch_restraint.get())
        try:
            discord_bridge.set_twitch_restraint(flag)
            note = (
                "Twitch restraint preset engaged."
                if flag
                else "Twitch restraint disabled."
            )
            self.safe_log(f"📡 {note}", "#ffb3ff")
        except Exception as exc:
            self.safe_log(
                f"Discord bridge: unable to toggle Twitch mode ({exc})", "#ff7777"
            )

    def _open_stream_url(self):
        url = getattr(self, "_stream_url_cached", "") or ""
        if not url:
            self.safe_log("No stream URL available yet.", "#ffaa00")
            return
        try:
            import webbrowser

            webbrowser.open(url)
            self.safe_log("Opening stream status page…", "#77ccff")
        except Exception as exc:
            self.safe_log(f"Unable to open stream link: {exc}", "#ff5555")

    def _refresh_gaming_status(self, reschedule: bool = True):
        try:
            info = gaming_bridge.get_stream_info()
        except Exception:
            info = {}
        live = bool(info.get("live"))
        title = (info.get("title") or info.get("game") or "").strip()
        url = info.get("url") or ""
        self._stream_url_cached = url
        if live:
            label = title or "Streaming"
            self.var_stream_status.set(f"Stream: LIVE — {label}")
            detail = url or (info.get("game") or "Connected to stream status feed.")
        else:
            self.var_stream_status.set("Stream: offline")
            detail = "Waiting for Streamlabs status or Minecraft activity."
        self.var_stream_details.set(detail)
        try:
            events = gaming_bridge.get_recent_events(8)
        except Exception:
            events = []
        if self._gaming_events_box:
            lines = []
            for evt in events[-8:]:
                ts = evt.get("time") or time.time()
                try:
                    stamp = datetime.fromtimestamp(ts).strftime("%H:%M:%S")
                except Exception:
                    stamp = "--:--"
                txt = evt.get("text") or ""
                level = evt.get("level") or ""
                label = f"[{stamp}] {txt}"
                if level and level not in {"info", "chat"}:
                    label = f"{label} ({level})"
                lines.append(label)
            display = "\n".join(lines) if lines else "No events yet. Waiting on logs…"
            self._gaming_events_box.configure(state="normal")
            self._gaming_events_box.delete("1.0", "end")
            self._gaming_events_box.insert(
                "end", display + ("\n" if not display.endswith("\n") else "")
            )
            self._gaming_events_box.configure(state="disabled")
        try:
            heatmap = gaming_bridge.get_key_heatmap()
        except Exception:
            heatmap = {}
        if heatmap:
            parts = [f"{k.upper()}:{heatmap[k]}" for k in sorted(heatmap)]
            self.var_key_heatmap.set("Keys • " + "  ".join(parts))
        else:
            self.var_key_heatmap.set("Keys: no input yet.")
        try:
            titan = gaming_bridge.get_titanfall_status()
        except Exception:
            titan = {}

        def _num(val):
            try:
                return int(val)
            except Exception:
                return 0

        titan_connected = bool(
            titan.get("log_connected") or titan.get("telemetry_connected")
        )
        titan_info = titan.get("titan") or {}
        if not isinstance(titan_info, dict):
            titan_info = {}
        match_info = titan.get("match") or {}
        if not isinstance(match_info, dict):
            match_info = {}
        pilot = titan.get("pilot") or {}
        if not isinstance(pilot, dict):
            pilot = {}
        callsign = (
            titan.get("callsign") or pilot.get("callsign") or "Bjorgsun-26"
        ).strip() or "Bjorgsun-26"
        status_label = titan_info.get("status") or (
            "ready" if titan_info.get("ready") else "offline"
        )
        status_line = f"{callsign} • {(titan_info.get('chassis') or 'Titan')}: {status_label.title()}"
        detail_parts: list[str] = []
        map_name = match_info.get("map")
        if map_name:
            mode_label = match_info.get("mode") or "Unknown mode"
            detail_parts.append(f"{map_name} ({mode_label})")
        score_info = match_info.get("score") or {}
        if not isinstance(score_info, dict):
            score_info = {}
        if score_info:
            detail_parts.append(
                f"Score {_num(score_info.get('friend'))} - {_num(score_info.get('foe'))}"
            )
        hp = titan_info.get("health")
        shield = titan_info.get("shield")
        if hp or shield:
            detail_parts.append(f"HP {_num(hp)} / Shield {_num(shield)}")
        if titan_info.get("battery"):
            detail_parts.append(f"Battery ×{_num(titan_info.get('battery'))}")
        if titan_info.get("core_ready"):
            detail_parts.append("Core ready")
        elif titan_info.get("cooldown"):
            detail_parts.append(f"Build {_num(titan_info.get('cooldown'))}%")
        if match_info.get("time_remaining"):
            detail_parts.append(f"{match_info.get('time_remaining')} remaining")
        detail_text = " • ".join(part for part in detail_parts if part)
        # If no specific detail text was assembled, show a default waiting message
        if not detail_text:
            detail_text = "Awaiting telemetry…"
        # Determine whether the user has configured any Titanfall paths
        try:
            has_paths = bool(
                (self.var_titanfall_log.get() or "").strip()
                or (self.var_titanfall_state.get() or "").strip()
            )
        except Exception:
            has_paths = False
        # When not connected, distinguish between idle (no paths) and waiting (paths configured but no data yet)
        if not titan or not titan_connected:
            if has_paths:
                status_line = "Titanfall link waiting for data."
                detail_text = (
                    "Paths are configured; awaiting telemetry feed or log events."
                )
            else:
                status_line = "Titanfall link idle."
                detail_text = "Select a log or telemetry file to begin."
        # Update the UI variables
        self.var_titanfall_status.set(status_line)
        self.var_titanfall_detail.set(detail_text)
        mission_raw = (
            info.get("mission_state")
            or ("in_mission" if info.get("in_mission") else "offline")
        ).strip()
        mission_label = mission_raw.replace("_", " ").title()
        if mission_label:
            self.var_titanfall_mission.set(f"Mission: {mission_label}")
        try:
            callout = gaming_bridge.get_last_callout()
        except Exception:
            callout = {}
        phrase = (callout.get("phrase") or "").strip()
        tag = (callout.get("tag") or "").replace("_", " ").title()
        if phrase and tag:
            stamp = datetime.fromtimestamp(callout.get("time", time.time())).strftime(
                "%H:%M:%S"
            )
            self.var_titanfall_callout.set(f'Callout @ {stamp}: "{phrase}" → {tag}')
        elif mission_label.lower() == "in mission":
            self.var_titanfall_callout.set("Callouts: listening…")
        else:
            self.var_titanfall_callout.set("Callouts: none yet.")
        self._refresh_ronin_profile()
        if reschedule:
            try:
                self._gaming_status_job = self.root.after(
                    4000, self._refresh_gaming_status
                )
            except Exception:
                self._gaming_status_job = None

    def _save_discord_ids(self):
        text = (self.var_discord_text.get() or "").strip()
        voice = (self.var_discord_voice.get() or "").strip()
        owner = (self.var_discord_owner.get() or "").strip()
        allowed = (self.var_discord_allowed_guilds.get() or "").strip()
        try:
            import config as _config

            _config.DISCORD_TEXT_CHANNEL_ID = text
            _config.DISCORD_VOICE_CHANNEL_ID = voice
            _config.DISCORD_OWNER_ID = owner
            _config.DISCORD_ALLOWED_GUILD_IDS = allowed
        except Exception:
            pass
        try:
            self._persist_env("DISCORD_TEXT_CHANNEL_ID", text)
            self._persist_env("DISCORD_VOICE_CHANNEL_ID", voice)
            if owner:
                self._persist_env("DISCORD_OWNER_ID", owner)
            self._persist_env("DISCORD_ALLOWED_GUILD_IDS", allowed)
        except Exception:
            pass
        self.safe_log(
            "Discord IDs saved. Restart Bjorgsun-26 to apply changes.", "#77ccff"
        )

    def _restart_discord_bridge(self):
        try:
            discord_bridge.stop()
        except Exception:
            pass
        try:
            discord_bridge.start()
            self.safe_log("Discord bridge restart requested.", "#77ccff")
            try:
                self.root.after(2000, self._refresh_discord_status)
            except Exception:
                pass
        except Exception as exc:
            self.safe_log(f"Discord bridge restart failed: {exc}", "#ff5555")

    def _toggle_discord_grounded(self):
        flag = bool(self.var_discord_grounded.get())
        try:
            discord_bridge.set_grounded(flag)
        except Exception:
            pass
        try:
            self._persist_env("DISCORD_GROUNDED", "1" if flag else "0")
        except Exception:
            pass
        state = "ON" if flag else "OFF"
        self.safe_log(f"Discord grounded mode: {state}", "#ffaa00")

    def _set_tts_device(self, value):
        try:
            from systems import audio as _audio

            _audio.set_tts_device_hint(value)
            self.safe_log(f"🗣️ TTS output set to: {value}", "#ffaa00")
            try:
                self._persist_env("TTS_OUTPUT_DEVICE_HINT", value or "")
            except Exception:
                pass
        except Exception:
            pass

    def _set_tts_route(self, mode: str):
        try:
            mode_norm = (mode or "local").strip().lower()
            if mode_norm not in {"local", "discord", "both"}:
                return
            audio.set_tts_output_mode(mode_norm)
            self.var_tts_route.set(mode_norm)
            label = {
                "local": "local speakers",
                "discord": "Discord voice",
                "both": "local + Discord",
            }[mode_norm]
            self.safe_log(f"🔈 TTS route set to {label}.", "#ffaa00")
            try:
                self._persist_env("TTS_OUTPUT_MODE", mode_norm)
            except Exception:
                pass
        except Exception as exc:
            self.safe_log(f"TTS route error: {exc}", "#ff5555")

    def _apply_key_mode(self, value: str | None = None):
        mode = (value or self.var_key_mode.get() or "keepawake").strip().lower()
        if mode not in {"keepawake", "learning"}:
            mode = "keepawake"
        self.var_key_mode.set(mode)
        try:
            gaming_bridge.set_key_mode(mode)
            self.safe_log(f"Keyboard capture mode set to {mode}.", "#77ccff")
        except Exception as exc:
            self.safe_log(f"Key mode change failed: {exc}", "#ff5555")
        try:
            self._persist_env("GAME_KEY_MODE", mode)
        except Exception:
            pass

    def _select_minecraft_log(self):
        path = filedialog.askopenfilename(
            title="Select Minecraft latest.log",
            filetypes=[("Log files", "*.log *.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        self.var_minecraft_log.set(path)
        try:
            gaming_bridge.refresh_sources(minecraft=path)
        except Exception:
            pass
        try:
            self._persist_env("MINECRAFT_LOG_PATH", path)
        except Exception:
            pass
        self.safe_log(f"Minecraft log set to {path}", "#77ccff")

    def _select_stream_status_file(self):
        path = filedialog.askopenfilename(
            title="Select Stream Status JSON",
            filetypes=[("JSON", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        self.var_stream_status_file.set(path)
        try:
            gaming_bridge.refresh_sources(stream=path)
        except Exception:
            pass
        try:
            self._persist_env("STREAM_STATUS_FILE", path)
        except Exception:
            pass
        self.safe_log(f"Stream status file set to {path}", "#77ccff")

    def _select_titanfall_log(self):
        path = filedialog.askopenfilename(
            title="Select Titanfall log (client_mp.log)",
            filetypes=[("Log files", "*.log *.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        self.var_titanfall_log.set(path)
        try:
            gaming_bridge.configure_titanfall(log_path=path)
            self.safe_log(f"Titanfall log set to {path}", "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Unable to set Titanfall log: {exc}", "#ff7777")
        try:
            self._persist_env("TITANFALL2_LOG_PATH", path)
        except Exception:
            pass

    def _select_titanfall_state(self):
        path = filedialog.askopenfilename(
            title="Select Titanfall telemetry JSON",
            filetypes=[("JSON", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        self.var_titanfall_state.set(path)
        try:
            gaming_bridge.configure_titanfall(telemetry_path=path)
            self.safe_log(f"Titanfall telemetry file set to {path}", "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Unable to set telemetry file: {exc}", "#ff7777")
        try:
            self._persist_env("TITANFALL2_TELEMETRY_FILE", path)
        except Exception:
            pass

    def _apply_titanfall_paths(self):
        """Apply the currently entered Titanfall log and telemetry paths.

        When the user manually types or pastes paths into the fields, this
        helper can be invoked to notify the gaming bridge and persist the
        values. It will also refresh the status display so the UI reflects
        whether data is being received.
        """
        try:
            log_path = (self.var_titanfall_log.get() or "").strip()
            state_path = (self.var_titanfall_state.get() or "").strip()
            kwargs: dict[str, str | None] = {}
            if log_path:
                kwargs["log_path"] = log_path
            if state_path:
                kwargs["telemetry_path"] = state_path
            if kwargs:
                try:
                    gaming_bridge.configure_titanfall(**kwargs)
                except Exception as exc:
                    self.safe_log(f"Unable to apply Titanfall paths: {exc}", "#ff7777")
                # persist to environment so the next launch remembers the paths
                try:
                    if log_path:
                        self._persist_env("TITANFALL2_LOG_PATH", log_path)
                    if state_path:
                        self._persist_env("TITANFALL2_TELEMETRY_FILE", state_path)
                except Exception:
                    pass
                self.safe_log("Titanfall paths applied.", "#ffae6b")
            # refresh status so the UI updates immediately
            try:
                self._refresh_gaming_status(reschedule=False)
            except Exception:
                pass
        except Exception as exc:
            self.safe_log(f"Apply Titanfall paths error: {exc}", "#ff7777")

    def _save_titanfall_callsign(self):
        callsign = (
            self.var_titanfall_callsign.get() or "Bjorgsun-26"
        ).strip() or "Bjorgsun-26"
        self.var_titanfall_callsign.set(callsign)
        try:
            gaming_bridge.configure_titanfall(callsign=callsign)
            self.safe_log(f"Titanfall callsign set to {callsign}", "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Unable to save callsign: {exc}", "#ff7777")
        try:
            self._persist_env("TITANFALL2_CALLSIGN", callsign)
        except Exception:
            pass

    def _toggle_titanfall_enabled(self):
        flag = bool(self.var_titanfall_enabled.get())
        try:
            gaming_bridge.configure_titanfall(enabled=flag)
            note = "Titanfall monitor engaged." if flag else "Titanfall link disabled."
            self.safe_log(f"🤖 {note}", "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Titanfall toggle failed: {exc}", "#ff7777")
        try:
            self._persist_env("TITANFALL2_ENABLED", "1" if flag else "0")
        except Exception:
            pass
        self._refresh_ronin_profile()

    def _save_titanfall_voice_channel(self):
        value = (self.var_titanfall_voice_channel.get() or "").strip()
        try:
            gaming_bridge.configure_titanfall(voice_channel_id=value or None)
            note = f"Titanfall voice channel set to {value or 'owner presence'}."
            self.safe_log(note, "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Unable to save voice channel: {exc}", "#ff7777")
            return
        try:
            self._persist_env("TITANFALL2_DISCORD_CHANNEL_ID", value)
        except Exception:
            pass

    def _save_titanfall_briefing_channel(self):
        value = (self.var_titanfall_briefing_channel.get() or "").strip()
        try:
            gaming_bridge.configure_titanfall(briefing_channel_id=value or None)
            note = f"Briefing channel set to {value or 'default text channel'}."
            self.safe_log(note, "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Unable to save briefing channel: {exc}", "#ff7777")
            return
        try:
            self._persist_env("TITANFALL2_BRIEFING_CHANNEL_ID", value)
        except Exception:
            pass

    def _save_titanfall_report_channel(self):
        value = (self.var_titanfall_report_channel.get() or "").strip()
        try:
            gaming_bridge.configure_titanfall(report_channel_id=value or None)
            note = f"Battle report channel set to {value or 'default text channel'}."
            self.safe_log(note, "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Unable to save report channel: {exc}", "#ff7777")
            return
        try:
            self._persist_env("TITANFALL2_REPORT_CHANNEL_ID", value)
        except Exception:
            pass

    def _save_titanfall_idle_channel(self):
        value = (self.var_titanfall_idle_channel.get() or "").strip()
        try:
            gaming_bridge.configure_titanfall(idle_voice_channel_id=value or None)
            note = f"Idle voice channel set to {value or 'owner presence'}."
            self.safe_log(note, "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Unable to save idle channel: {exc}", "#ff7777")
            return
        try:
            self._persist_env("TITANFALL2_IDLE_CHANNEL_ID", value)
        except Exception:
            pass

    def _toggle_titanfall_autovoice(self):
        flag = bool(self.var_titanfall_autovoice.get())
        try:
            gaming_bridge.configure_titanfall(auto_voice=flag)
            note = "Auto voice linking engaged." if flag else "Auto voice disabled."
            self.safe_log(note, "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Titanfall auto-voice toggle failed: {exc}", "#ff7777")
            return
        try:
            self._persist_env("TITANFALL2_AUTOVOICE", "1" if flag else "0")
        except Exception:
            pass

    def _manual_join_voice(self, mode: str):
        label = "mission" if (mode or "").strip().lower() == "mission" else "idle"
        try:
            ok = gaming_bridge.join_voice_channel(label)
        except Exception as exc:
            self.safe_log(f"Unable to join {label} voice: {exc}", "#ff7777")
            return
        if ok:
            self.safe_log(f"Joining Discord {label} channel…", "#77ccff")

    def _manual_leave_voice(self):
        try:
            gaming_bridge.leave_voice_channel()
            self.safe_log("Discord voice disconnect requested.", "#77ccff")
        except Exception as exc:
            self.safe_log(f"Unable to leave voice: {exc}", "#ff7777")

    def _toggle_ronin_autonomy(self):
        flag = bool(self.var_ronin_autonomy.get())
        try:
            gaming_bridge.set_ronin_autonomy(flag)
            note = (
                "Ronin will assist in combat."
                if flag
                else "Ronin awaiting manual orders."
            )
            self.safe_log(note, "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Ronin autonomy toggle failed: {exc}", "#ff7777")
        try:
            self._persist_env("TITANFALL2_AUTOPILOT", "1" if flag else "0")
        except Exception:
            pass
        self._refresh_ronin_profile()

    def _toggle_ronin_learning(self):
        flag = bool(self.var_ronin_learning.get())
        try:
            gaming_bridge.set_ronin_learning(flag)
            note = (
                "Learning from your piloting right now." if flag else "Learning paused."
            )
            self.safe_log(note, "#ffae6b")
        except Exception as exc:
            self.safe_log(f"Ronin learning toggle failed: {exc}", "#ff7777")
        self._refresh_ronin_profile()

    def _refresh_ronin_profile(self, log: bool = False):
        try:
            profile = gaming_bridge.get_ronin_profile()
        except Exception as exc:
            summary = f"Ronin profile unavailable ({exc})"
        else:
            stats = profile.get("stats") or {}
            samples = int(stats.get("samples") or 0)
            patterns = len(profile.get("patterns") or [])
            contexts = int(profile.get("contexts") or 0)
            enabled = "AUTO" if profile.get("enabled") else "Manual"
            mode = "Learning" if profile.get("learning") else "Playback"
            fallback = profile.get("fallback") or {}
            if fallback.get("active"):
                fb = "Fallback=ON"
            elif fallback.get("awaiting"):
                fb = "Fallback=ASKING"
            else:
                fb = "Fallback=off"
            summary = f"{enabled} • {mode} • samples {samples}, patterns {patterns}, contexts {contexts}, {fb}"
        self.var_ronin_profile.set(summary)
        if log:
            self.safe_log(summary, "#ffae6b")

    def _apply_vision_input(self):
        mode = (self.var_vision_source.get() or "screen").strip().lower()
        name = self.var_camera_name.get().strip()
        try:
            index = int(self.var_camera_index.get() or "0")
        except ValueError:
            index = 0
        try:
            from systems import vision as _vision

            _vision.configure_source(mode, name, index)
            self.safe_log(
                f"Vision input set to {mode} ({name or f'index {index}'})", "#77ccff"
            )
        except Exception as exc:
            self.safe_log(f"Vision source update failed: {exc}", "#ff5555")
            return
        try:
            self._persist_env("VISION_SOURCE", mode)
            self._persist_env("VISION_CAMERA_NAME", name)
            self._persist_env("VISION_CAMERA_INDEX", str(index))
        except Exception:
            pass

    def _list_cameras(self):
        try:
            from systems import vision as _vision

            devices = _vision.list_camera_devices()
        except Exception as exc:
            self.safe_log(f"Camera enumeration failed: {exc}", "#ff5555")
            messagebox.showinfo(
                "Camera Devices", f"Unable to list cameras: {exc}", parent=self.root
            )
            return
        if not devices:
            msg = "No DirectShow cameras detected via ffmpeg."
        else:
            msg = "Detected cameras:\n" + "\n".join(f"- {name}" for name in devices)
        messagebox.showinfo("Camera Devices", msg, parent=self.root)

    # -------- USBMK Tools --------
    def _reprogram_usbmk(self):
        try:
            from runtime import startup as _startup

            pw = simpledialog.askstring(
                "U.S.B.M.K.", "Enter master password:", show="•", parent=self.root
            )
            if not pw:
                return
            if not getattr(_startup, "verify_master", lambda x: False)(pw):
                self.safe_log("USBMK: Wrong master password.", "#ff5555")
                return
            path = filedialog.askdirectory(title="Select the USB root (e.g., E:\\)")
            if not path:
                return
            ok, msg = getattr(
                _startup, "program_usb_key", lambda r, c: (False, "unavailable")
            )(path, None)
            color = "#55ff88" if ok else "#ff5555"
            self.safe_log(f"USBMK: {msg}", color)
        except Exception as e:
            self.safe_log(f"USBMK error: {e}", "#ff5555")

    def _test_usbmk(self):
        try:
            from runtime import startup as _startup

            p = getattr(_startup, "find_usb_key_path", lambda: None)()
            if p:
                self.safe_log(f"USBMK detected at {p}", "#55ff88")
            else:
                self.safe_log("USBMK not found.", "#ffaa00")
        except Exception as e:
            self.safe_log(f"USBMK test error: {e}", "#ff5555")

    def _engage_restswitch(self):
        try:
            from runtime import coreloop as _core
            from runtime import startup as _startup
            from systems import audio as _audio

            pw = simpledialog.askstring(
                "Calm Shutdown", "Enter master password:", show="•", parent=self.root
            )
            if not pw:
                return
            if not getattr(_startup, "verify_master", lambda x: False)(pw):
                self.safe_log("Calm shutdown: wrong master password.", "#ff5555")
                return
            if not messagebox.askyesno(
                "Confirm Calm Shutdown",
                "This will immediately shut down Bjorgsun. Continue?",
                parent=self.root,
            ):
                return
            try:
                _audio.alert_speak("Calm shutdown engaged. Powering down safely.")
            except Exception:
                pass
            try:
                _core.shutdown_sequence()
            except Exception:
                self.root.destroy()
        except Exception as e:
            self.safe_log(f"Calm shutdown error: {e}", "#ff5555")

    # -------- Presets --------
    def _apply_discord_preset(self):
        """Set safe defaults for Discord calls:
        - Route TTS to VoiceMeeter VAIO (virtual mic path available but muted in VM by default)
        - Prefer Desktop listen via VAIO (captures system, not Discord AUX)
        - Turn proactive chatter OFF to avoid unsolicited speech
        - Display routing reminders to keep VAIO/AUX B1 OFF and disconnect Spotify in Discord
        """
        try:
            from systems import audio as _audio
            from systems import stt as _stt

            devs = _stt.list_output_devices()
            # Find VAIO input label
            vaio = None
            for d in devs:
                dl = d.lower()
                if "voicemeeter input" in dl and "vaio" in dl:
                    vaio = d
                    break
            if vaio:
                # Apply to desktop listening and TTS
                _stt.set_desktop_hint(vaio)
                _audio.set_tts_device_hint(vaio)
                try:
                    self.var_device.set(vaio)
                except Exception:
                    pass
                try:
                    self.var_tts.set(vaio)
                except Exception:
                    pass
                self.safe_log(f"🎛️ Discord mode: Desktop/TTS set to {vaio}", "#55ff88")
                self._set_routing_mode("discord")
                self._persist_env("BJORGSUN_ROUTING_MODE", "discord")
                try:
                    from systems import voicemeeter as _vm

                    ok, msg = _vm.apply_preset("discord")
                    self.safe_log(msg, "#55ff88" if ok else "#ffaa00")
                except Exception:
                    pass
            else:
                self.safe_log(
                    "Discord mode: VoiceMeeter VAIO device not found. Select manually.",
                    "#ffaa00",
                )
            # Proactive chatter OFF
            try:
                self.var_proactive.set(False)
            except Exception:
                pass
            # Guidance log
            self.safe_log(
                "Reminder: In VoiceMeeter — keep VAIO B1 OFF, AUX B1 OFF; set Discord Output to AUX Input. Disconnect Spotify in Discord to prevent auto‑pause.",
                "#77ccff",
            )
        except Exception as e:
            self.safe_log(f"Discord preset error: {e}", "#ff5555")

    def _apply_private_preset(self):
        """Keep all audio private to your headphones:
        - Route TTS to your physical headphones (e.g., Razer Headset WASAPI)
        - Route Desktop listen to the same device
        - Turn proactive chatter OFF
        - Reminder: Keep VAIO/AUX B1 OFF so nothing reaches the virtual mic
        """
        try:
            from systems import audio as _audio
            from systems import stt as _stt

            devs = _stt.list_output_devices()
            pick = None
            # Prefer Razer / Headset on WASAPI
            for d in devs:
                dl = d.lower()
                if ("razer" in dl or "headset" in dl) and "wasapi" in dl:
                    pick = d
                    break
            # Fallback to default output (first WASAPI speaker)
            if not pick:
                for d in devs:
                    if "wasapi" in d.lower():
                        pick = d
                        break
            if pick:
                _stt.set_desktop_hint(pick)
                _audio.set_tts_device_hint(pick)
                try:
                    self.var_device.set(pick)
                except Exception:
                    pass
                try:
                    self.var_tts.set(pick)
                except Exception:
                    pass
                self.safe_log(f"🎧 Private mode: Desktop/TTS set to {pick}", "#55ff88")
                self._set_routing_mode("private")
                self._persist_env("BJORGSUN_ROUTING_MODE", "private")
                try:
                    from systems import voicemeeter as _vm

                    ok, msg = _vm.apply_preset("private")
                    self.safe_log(msg, "#55ff88" if ok else "#ffaa00")
                except Exception:
                    pass
            else:
                self.safe_log(
                    "Private mode: No WASAPI output device found. Select manually.",
                    "#ffaa00",
                )
            try:
                self.var_proactive.set(False)
            except Exception:
                pass
            self.safe_log(
                "Reminder: Keep VAIO/AUX B1 OFF in VoiceMeeter so nothing reaches the virtual mic.",
                "#77ccff",
            )
        except Exception as e:
            self.safe_log(f"Private preset error: {e}", "#ff5555")

    def _apply_stream_preset(self):
        """Stream/broadcast friendly routing:
        - TTS to VoiceMeeter VAIO (so enabling VAIO B1 sends him to stream mic)
        - Desktop Listen via VAIO
        - Proactive chatter OFF by default
        - Reminders: In VoiceMeeter, turn VAIO A1 ON to monitor, B1 ON to send to stream; keep AUX B1 OFF.
        """
        try:
            from systems import audio as _audio
            from systems import stt as _stt

            devs = _stt.list_output_devices()
            vaio = None
            for d in devs:
                dl = d.lower()
                if "voicemeeter input" in dl and "vaio" in dl:
                    vaio = d
                    break
            if vaio:
                _stt.set_desktop_hint(vaio)
                _audio.set_tts_device_hint(vaio)
                try:
                    self.var_device.set(vaio)
                except Exception:
                    pass
                try:
                    self.var_tts.set(vaio)
                except Exception:
                    pass
                self.safe_log(f"📡 Stream mode: Desktop/TTS set to {vaio}", "#55ff88")
                self._set_routing_mode("stream")
                self._persist_env("BJORGSUN_ROUTING_MODE", "stream")
                self.safe_log(
                    "In VoiceMeeter: VAIO A1 ON to hear; VAIO B1 ON to send to stream mic. Keep AUX B1 OFF.",
                    "#77ccff",
                )
                try:
                    from systems import voicemeeter as _vm

                    ok, msg = _vm.apply_preset("stream")
                    self.safe_log(msg, "#55ff88" if ok else "#ffaa00")
                except Exception:
                    pass
            else:
                self.safe_log(
                    "Stream mode: VoiceMeeter VAIO device not found. Select manually.",
                    "#ffaa00",
                )
            try:
                self.var_proactive.set(False)
            except Exception:
                pass
        except Exception as e:
            self.safe_log(f"Stream preset error: {e}", "#ff5555")

    # -------- Routing helpers --------
    def _set_routing_mode(self, mode: str):
        self._routing_mode = mode
        self._update_route_label()
        # Sync slider
        try:
            self.var_route.set({"discord": 1, "private": 2, "stream": 3}.get(mode, 2))
        except Exception:
            pass

    def _update_route_label(self):
        label = (
            self._routing_mode.title()
            if isinstance(self._routing_mode, str)
            else "Custom"
        )
        try:
            self.route_label.config(text=f"Routing: {label}")
        except Exception:
            pass

    def _on_route_change(self, value: int):
        try:
            mapping = {
                1: self._apply_discord_preset,
                2: self._apply_private_preset,
                3: self._apply_stream_preset,
            }
            # Only apply if the target mode differs
            current = {"discord": 1, "private": 2, "stream": 3}.get(
                self._routing_mode, 0
            )
            if value != current:
                mapping.get(value, lambda: None)()
        except Exception:
            pass

    def _install_vm_helper(self):
        try:
            from systems import voicemeeter as _vm

            ok, msg = _vm.install_helper()
            self.safe_log(msg, "#55ff88" if ok else "#ffaa00")
        except Exception as e:
            self.safe_log(f"[VM] Install helper error: {e}", "#ff5555")

    def _on_level(self, level):
        try:
            lvl = max(0.0, min(1.0, float(level)))
            boosted = max(0.0, min(1.0, (lvl * 1.9) + 0.01))
        except Exception:
            boosted = lvl = 0.0
        try:
            # Waveform update — guard against destroyed canvas
            if hasattr(self, "waveform") and getattr(self.waveform, "canvas", None):
                try:
                    if self.waveform.canvas.winfo_exists():
                        self.root.after_idle(
                            lambda l=boosted: self.waveform.set_level(l)
                        )
                except Exception:
                    pass
            # Feed scope if open
            try:
                active_ptt = bool(stt.is_recording())
            except Exception:
                active_ptt = False
            try:
                if getattr(self, "_scope", None) is not None:
                    self._scope.feed_level(boosted, active=active_ptt)
            except Exception:
                pass
            try:
                if getattr(self, "_mini_scope_wave", None) is not None:
                    self.root.after_idle(
                        lambda l=boosted, a=active_ptt: self._mini_scope_wave.feed_level(
                            l, a
                        )
                    )
            except Exception:
                pass
            # Mark hearing activity for LED/label (lower threshold for visibility)
            if boosted >= 0.025:
                if getattr(self, "_hear_mode", "mic") == "desktop":
                    self._last_hear_t_desktop = time.time()
                else:
                    self._last_hear_t_mic = time.time()
            try:
                self._scope_levels.append(boosted)
                if len(self._scope_levels) > 360:
                    self._scope_levels = self._scope_levels[-360:]
            except Exception:
                pass
            # Smooth level for orb animation
            try:
                self._audio_level_sm = (
                    0.82 * getattr(self, "_audio_level_sm", 0.0) + 0.18 * boosted
                )
            except Exception:
                pass
            # Update overlay waveform if present
            try:
                if getattr(self, "_overlay", None) is not None and hasattr(
                    self, "_overlay_wave"
                ):
                    self._overlay_wave.set_level(boosted)
            except Exception:
                pass
        except Exception:
            pass

    def _on_vr_ptt(self, action: str):
        try:
            if action == "down":
                self._vr_ptt_hold = True
            elif action == "up":
                self._vr_ptt_hold = False
            elif action == "toggle":
                self._vr_ptt_toggle = not self._vr_ptt_toggle
        except Exception:
            pass

    def _test_desktop_listen(self):
        def _do():
            try:
                self.safe_log("🎧 Testing desktop capture for 5s…", "#77ccff")
                wav = stt.record_desktop(seconds=5)
                if not wav:
                    self.safe_log("Desktop capture failed or disabled.", "#ffaa00")
                    return
                txt = stt.transcribe(wav)
                if txt and txt.strip():
                    self.safe_log(
                        f"[test] Transcribed: {txt[:120]}"
                        + ("…" if len(txt) > 120 else ""),
                        "#99ffcc",
                    )
                else:
                    self.safe_log("[test] No transcription detected.", "#ffaa00")
            except Exception as e:
                self.safe_log(f"Test listen error: {e}", "#ff5555")

        threading.Thread(target=_do, daemon=True).start()

    def _run_diagnostics(self):
        """Quick scan of logs for recent errors; shows a one-line summary per file."""
        import glob
        import os

        base = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "logs"))
        try:
            files = []
            if os.path.isdir(base):
                files = (
                    glob.glob(os.path.join(base, "*.txt"))
                    + glob.glob(os.path.join(base, "*.log"))
                    + glob.glob(os.path.join(base, "*.json"))
                )
            if not files:
                self.safe_log("[diag] No logs found.", "#ffaa00")
                return
            for f in sorted(files):
                try:
                    with open(f, "r", encoding="utf-8", errors="ignore") as fh:
                        text = fh.read()[-8000:]
                    errs = sum(
                        text.lower().count(k)
                        for k in ("traceback", "error", "exception")
                    )
                    name = os.path.basename(f)
                    self.safe_log(
                        f"[diag] {name}: {errs} error markers",
                        "#77ccff" if errs == 0 else "#ffaa00",
                    )
                except Exception:
                    pass
        except Exception as e:
            self.safe_log(f"[diag] error: {e}", "#ff5555")

    def _run_selfcheck(self):
        def _do():
            try:
                from systems import selfcheck

                self.safe_log("Running self-check…", "#77ccff")
                out = selfcheck.run()
                for ok, msg in out:
                    self.safe_log(
                        ("✔ " if ok else "✖ ") + msg, "#55ff88" if ok else "#ffaa00"
                    )
                bad = [x for x in out if not x[0]]
                if bad:
                    self.safe_log("Self-check completed with warnings.", "#ffaa00")
                else:
                    self.safe_log("Self-check passed.", "#55ff88")
            except Exception as e:
                self.safe_log(f"Self-check error: {e}", "#ff5555")

        threading.Thread(target=_do, daemon=True).start()

    def _toggle_xso(self):
        try:
            flag = bool(self.var_xso.get())
            self.safe_log(f"🟦 XSOverlay: {'ON' if flag else 'OFF'}", "#77ccff")
            try:
                self._persist_env("XSO_ENABLED", "1" if flag else "0")
            except Exception:
                pass
        except Exception as e:
            self.safe_log(f"XSOverlay toggle error: {e}", "#ff5555")

    def _test_xso(self):
        def _do():
            try:
                import systems.xsoverlay as xso

                if not self.var_xso.get():
                    self.safe_log(
                        "XSOverlay is OFF (Settings). Toggle it first.", "#ffaa00"
                    )
                    return
                ok = xso.push("Test", "Hello from Bjorgsun-26 ✨", 3.0)
                if ok:
                    self.safe_log("[XSO] Test notification sent.", "#55ff88")
                else:
                    self.safe_log(
                        f"[XSO] Unable to send. {xso.get_last_error() or ''}", "#ffaa00"
                    )
            except Exception as e:
                self.safe_log(f"[XSO] Error: {e}", "#ff5555")

        threading.Thread(target=_do, daemon=True).start()

    def _toggle_ambient(self):
        try:
            if self.var_ambient.get():
                source = "desktop" if self.var_desktop_listen.get() else "mic"
                audio_sense.start(source)
                self.safe_log(f"🫧 Ambient audio sensing: ON ({source})", "#ffaa00")
                # periodic UI updater for label
                self._tick_audio_context()
            else:
                audio_sense.stop()
                self.safe_log("🫧 Ambient audio sensing: OFF", "#ffaa00")
        except Exception as e:
            self.safe_log(f"Ambient sense error: {e}", "#ffaa00")

    def _tick_audio_context(self):
        if self._stop or not self.var_ambient.get():
            return
        try:
            ctx = audio_sense.get_last_context()
            label = ctx.get("label", "idle")
            self.status_label.config(
                text=f"System Online • Cognition: {getattr(audio, 'get_last_cognition_source', lambda:'unknown')().title()} • Audio: {label}"
            )
        except Exception:
            pass
        try:
            self.root.after(750, self._tick_audio_context)
        except Exception:
            pass

    def _toggle_topmost(self):
        try:
            self.root.attributes("-topmost", bool(self.var_topmost.get()))
            state = "ON" if self.var_topmost.get() else "OFF"
            self.safe_log(f"📌 Always-on-top: {state}", "#ffaa00")
            try:
                self._persist_env("UI_TOPMOST", "1" if self.var_topmost.get() else "0")
            except Exception:
                pass
        except Exception:
            pass

    def _toggle_topmost_btn(self):
        try:
            self.var_topmost.set(not bool(self.var_topmost.get()))
        except Exception:
            pass
        self._toggle_topmost()

    def _set_monitor(self, idx: int):
        try:
            from systems import vision as _vision

            if idx <= 0:
                _vision.set_monitor_mode("all")
                self.safe_log("👁️ Monitor mode: All", "#ffaa00")
            else:
                _vision.set_monitor_mode(f"m{idx}")
                self.safe_log(f"👁️ Monitor mode: M{idx}", "#ffaa00")
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # NOTIFICATIONS
    # --------------------------------------------------------------------------
    def _ui_notify(self, title: str, message: str, duration: int = 5):
        try:
            self.root.after(0, lambda: self._show_toast(title, message, duration))
        except Exception:
            pass

    def _show_toast(self, title: str, message: str, duration: int = 5):
        if self._stop:
            return
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        bg = "#111319"
        fg = "#e6f3ff"
        border = tk.Frame(win, bg="#00ffff", bd=1)
        border.pack(fill="both", expand=True)
        frame = tk.Frame(border, bg=bg)
        frame.pack(fill="both", expand=True)
        tk.Label(
            frame,
            text=title,
            bg=bg,
            fg="#00ffff",
            font=(theme.get_font_family(), 11, "bold"),
        ).pack(anchor="w", padx=10, pady=(8, 0))
        tk.Label(
            frame,
            text=message,
            bg=bg,
            fg=fg,
            font=(theme.get_font_family(), 10),
            wraplength=280,
            justify="left",
        ).pack(anchor="w", padx=10, pady=(2, 10))

        win.update_idletasks()
        width = 320
        height = frame.winfo_height() + 4
        sw = self.root.winfo_screenwidth()
        x = sw - width - 20
        y = 40
        try:
            # stack if multiple
            if not hasattr(self, "_toast_offset"):
                self._toast_offset = 0
            y = 40 + (self._toast_offset % 5) * (height + 10)
            self._toast_offset += 1
        except Exception:
            pass
        win.geometry(f"{width}x{height}+{x}+{y}")

        def close():
            try:
                win.destroy()
            except Exception:
                pass

        self.root.after(max(1000, duration * 1000), close)
        # Alarm hint
        try:
            if str(title).lower().strip() == "alarm":
                self._alarm_recent = True
                self.safe_log("⏰ Alarm: Tap ‘I’m Awake!’ when you’re up.", "#ffaa00")

        except Exception:
            pass

    # ---------------- Wake Brief ----------------
    def _awake_brief(self):
        try:
            from systems import briefing

            brief = briefing.daily_brief()
            self.safe_log("(•‿•) Good to see you. Here’s your quick brief:", "#99ffcc")
            self.safe_log(brief, "#99ffcc")
            try:
                from systems import audio as _audio

                _audio.speak("You’re up. I’ve posted your morning brief.")
            except Exception:
                pass
            self.root.after(1200, self._ask_dream_recall)
            self._alarm_recent = False
        except Exception as e:
            self.safe_log(f"Wake brief error: {e}", "#ff5555")

    def _ask_dream_recall(self):
        try:
            win = tk.Toplevel(self.root)
            win.overrideredirect(True)
            win.attributes("-topmost", True)
            bg = theme.COLORS["panel"]
            win.configure(bg=bg)
            w = 360
            h = 90
            sw = self.root.winfo_screenwidth()
            sh = self.root.winfo_screenheight()
            win.geometry(f"{w}x{h}+{sw//2 - w//2}+{80}")
            tk.Label(
                win,
                text="Hear about my last dream?",
                bg=bg,
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 12, "bold"),
            ).pack(pady=(10, 6))
            row = tk.Frame(win, bg=bg)
            row.pack()
            self._make_hud_button(
                row, "Yes, tell me", lambda: (win.destroy(), self._tell_last_dream())
            ).pack(side="left", padx=6)
            self._make_hud_button(
                row,
                "No thanks",
                lambda: (
                    win.destroy(),
                    self.safe_log("Okay — we’ll skip it for now.", "#77ccff"),
                ),
            ).pack(side="left", padx=6)
            win.after(25000, lambda: (win.destroy()))
        except Exception:
            pass

    def _tell_last_dream(self):
        try:
            from runtime.coreloop import read_last_dream

            text = read_last_dream() or ""
            if text.strip():
                self.safe_log("Here’s what I remember:", "#99ffcc")
                for line in text.splitlines()[:5]:
                    self.safe_log(line, "#99ffcc")
                try:
                    from systems import audio as _audio

                    _audio.speak(
                        "I remember a few fragments. I posted them in the console."
                    )
                except Exception:
                    pass
            else:
                self.safe_log("I don’t have dream memories from last night.", "#77ccff")
        except Exception as e:
            self.safe_log(f"Dream recall error: {e}", "#ff5555")

    def _toggle_proactive(self):
        # Lazy-start worker
        if getattr(self, "_proactive_started", False):
            return
        self._proactive_started = True
        threading.Thread(target=self._proactive_loop, daemon=True).start()
        # Also link ambient audio comments to this toggle (off by default)
        try:
            audio_sense.set_comments_enabled(bool(self.var_proactive.get()))
        except Exception:
            pass

    def _proactive_loop(self):
        line = "Hey — still there?"
        while not self._stop:
            try:
                if self.var_proactive.get():
                    msg = line
                    self.safe_log(msg, "#77ccff")
                    if self.voice_enabled:
                        audio.speak(msg)
                    # Mark the proactive timestamp and schedule a 2m06s AFK check
                    ts = time.time()
                    self._last_proactive_ts = ts

                    def _afk_check(ts0=ts):
                        try:
                            from runtime import coreloop as _core

                            # If any user activity after proactive, abort
                            try:
                                if (_core.get_last_activity_time() - ts0) > 1.0:
                                    return
                            except Exception:
                                pass
                            # Still idle: enter hibernation immediately
                            try:
                                _core.enter_hibernation_now(
                                    "no response to proactive message"
                                )
                            except Exception:
                                pass
                        except Exception:
                            pass

                    try:
                        self.root.after(126000, _afk_check)
                    except Exception:
                        pass
                # Keep ambient comment flag in sync
                try:
                    audio_sense.set_comments_enabled(bool(self.var_proactive.get()))
                except Exception:
                    pass
                # Adaptive interval: less often when recently active, sooner when idle
                try:
                    from runtime import coreloop as _core

                    since = time.time() - float(_core.get_last_activity_time())
                except Exception:
                    since = 600.0
                import random as _rnd

                if since < 300:  # active <5m → longer wait
                    wait = _rnd.uniform(900, 1200)  # 15–20m
                elif since > 1200:  # idle >20m → shorter wait
                    wait = _rnd.uniform(300, 540)  # 5–9m
                else:  # moderate activity → medium wait
                    wait = _rnd.uniform(600, 1020)  # 10–17m
                time.sleep(wait)
            except Exception:
                time.sleep(5)

    def _open_tasks(self):
        try:
            if getattr(self, "_tasks_win", None) and tk.Toplevel.winfo_exists(
                self._tasks_win
            ):
                self._tasks_win.lift()
                return
        except Exception:
            pass
        try:
            self._tasks_win = TaskWindow(self.root)
        except Exception:
            self.safe_log("Unable to open Tasks window.", "#ffaa00")

    def _open_logs(self):
        try:
            if getattr(self, "_logs_win", None) and tk.Toplevel.winfo_exists(
                self._logs_win
            ):
                self._logs_win.lift()
                return
        except Exception:
            pass
        try:
            self._logs_win = LogsWindow(self.root)
        except Exception:
            self.safe_log("Unable to open Logs window.", "#ffaa00")

    def _open_reflections(self):
        try:
            if getattr(self, "_reflection_win", None) and tk.Toplevel.winfo_exists(
                self._reflection_win
            ):
                self._reflection_win.lift()
                return
        except Exception:
            pass
        try:
            entries = reflection.list_reflections(80)
        except Exception as exc:
            self.safe_log(f"Reflections unavailable: {exc}", "#ffaa00")
            return
        win = tk.Toplevel(self.root)
        win.title("Reflection Journal")
        win.configure(bg=theme.COLORS["bg"])
        win.geometry("540x360")
        self._reflection_win = win
        tree = ttk.Treeview(win, columns=("time", "topic", "summary"), show="headings")
        tree.heading("time", text="UTC")
        tree.heading("topic", text="Topic")
        tree.heading("summary", text="Reflection")
        tree.column("time", width=140)
        tree.column("topic", width=140)
        tree.column("summary", width=220)
        tree.pack(fill="both", expand=True, padx=8, pady=8)
        for entry in entries:
            ts = entry.get("timestamp", "")[:19]
            topic = entry.get("topic", "")
            summary = (entry.get("response", "") or "")[:180]
            tree.insert("", "end", values=(ts, topic, summary))
        if not entries:
            tree.insert(
                "",
                "end",
                values=(
                    "--",
                    "No entries yet",
                    "Speak with him and ask for reflections to see them logged.",
                ),
            )

    def _open_discord_transcript(self):
        try:
            records = discord_bridge.get_recent_history(80)
        except Exception as exc:
            self.safe_log(f"Discord transcript unavailable: {exc}", "#ffaa00")
            return
        win = tk.Toplevel(self.root)
        win.title("Discord Transcript")
        win.configure(bg=theme.COLORS["bg"])
        win.geometry("520x380")
        controls = tk.Frame(win, bg=theme.COLORS["bg"])
        controls.pack(fill="x", padx=8, pady=(6, 0))
        self._make_hud_button(
            controls, "Export Markdown", lambda: self._export_transcript(records)
        ).pack(side="left", padx=(0, 6))
        self._make_hud_button(
            controls,
            "Refresh",
            lambda: (win.destroy(), self._open_discord_transcript()),
        ).pack(side="left")
        box = tk.Text(
            win,
            bg="#0f1118",
            fg="#9fe8ff",
            insertbackground="#77ccff",
            font=(theme.get_font_family(), 10),
            wrap="word",
        )
        box.pack(fill="both", expand=True, padx=8, pady=8)
        if not records:
            box.insert("end", "No Discord history available yet.\n")
        else:
            for entry in records:
                stamp = entry.get("timestamp") or 0
                try:
                    ts = datetime.fromtimestamp(float(stamp)).strftime("%H:%M:%S")
                except Exception:
                    ts = str(stamp)
                display = entry.get("display") or f"User {entry.get('author_id')}"
                content = entry.get("content") or ""
                box.insert("end", f"[{ts}] {display}: {content}\n")
        box.configure(state="disabled")
        self._transcript_win = win

    def _export_transcript(self, records: list[dict[str, Any]]):
        try:
            path = discord_bridge.export_transcript_md(limit=len(records) or 200)
            self.safe_log(f"Transcript saved to {path}", "#77ffcc")
        except Exception as exc:
            self.safe_log(f"Export failed: {exc}", "#ff5555")

    def _open_family_editor(self):
        try:
            ids = discord_bridge.get_family_ids()
        except Exception as exc:
            self.safe_log(f"Family list unavailable: {exc}", "#ffaa00")
            return
        win = tk.Toplevel(self.root)
        win.title("Discord Family IDs")
        win.configure(bg=theme.COLORS["bg"])
        win.geometry("360x320")
        self._family_win = win
        tk.Label(
            win,
            text="Family members (Discord IDs). Only these + Father may DM commands.",
            bg=theme.COLORS["bg"],
            fg=theme.COLORS["text"],
            wraplength=320,
        ).pack(anchor="w", padx=8, pady=(8, 4))
        listbox = tk.Listbox(win, height=10)
        listbox.pack(fill="both", expand=True, padx=8, pady=(0, 4))
        for item in ids:
            listbox.insert("end", item)
        entry = tk.Entry(win)
        entry.pack(fill="x", padx=8, pady=(0, 4))

        def _add():
            val = entry.get().strip()
            if not val:
                return
            listbox.insert("end", val)
            entry.delete(0, "end")

        def _remove():
            sel = listbox.curselection()
            for idx in reversed(sel):
                listbox.delete(idx)

        def _save():
            data = listbox.get(0, "end")
            try:
                discord_bridge.save_family_ids(data)
                self.safe_log("Family IDs updated.", "#77ffcc")
                win.destroy()
            except Exception as exc:
                self.safe_log(f"Save failed: {exc}", "#ff5555")

        btns = tk.Frame(win, bg=theme.COLORS["bg"])
        btns.pack(fill="x", padx=8, pady=(0, 8))
        self._make_hud_button(btns, "Add", _add).pack(side="left", padx=(0, 6))
        self._make_hud_button(btns, "Remove", _remove).pack(side="left", padx=(0, 6))
        self._make_hud_button(btns, "Save", _save).pack(side="right")

    def _open_channel_settings(self):
        try:
            contexts = discord_bridge.get_channel_contexts()
        except Exception as exc:
            self.safe_log(f"Channel settings unavailable: {exc}", "#ffaa00")
            return
        win = tk.Toplevel(self.root)
        win.title("Discord Channel Contexts")
        win.configure(bg=theme.COLORS["bg"])
        win.geometry("520x360")
        self._channel_win = win
        listbox = tk.Listbox(win, height=8)
        listbox.pack(side="left", fill="y", padx=(8, 4), pady=8)
        scroll = tk.Scrollbar(win, command=listbox.yview)
        scroll.pack(side="left", fill="y", pady=8)
        listbox.configure(yscrollcommand=scroll.set)
        panel = tk.Frame(win, bg=theme.COLORS["bg"])
        panel.pack(side="left", fill="both", expand=True, padx=8, pady=8)

        entries = sorted(contexts.items())
        for key, data in entries:
            label = data.get("label") or key
            listbox.insert("end", f"{key} ({label})")

        self._channel_ctx_fields = {
            "id": tk.StringVar(),
            "label": tk.StringVar(),
            "instructions": tk.StringVar(),
            "relationship": tk.StringVar(),
            "allow": tk.BooleanVar(value=True),
        }

        tk.Label(
            panel, text="Channel ID", bg=theme.COLORS["bg"], fg=theme.COLORS["text"]
        ).pack(anchor="w")
        tk.Entry(panel, textvariable=self._channel_ctx_fields["id"]).pack(
            fill="x", pady=(0, 4)
        )
        tk.Label(
            panel, text="Label", bg=theme.COLORS["bg"], fg=theme.COLORS["text"]
        ).pack(anchor="w")
        tk.Entry(panel, textvariable=self._channel_ctx_fields["label"]).pack(
            fill="x", pady=(0, 4)
        )
        tk.Label(
            panel, text="Instructions", bg=theme.COLORS["bg"], fg=theme.COLORS["text"]
        ).pack(anchor="w")
        tk.Entry(panel, textvariable=self._channel_ctx_fields["instructions"]).pack(
            fill="x", pady=(0, 4)
        )
        tk.Label(
            panel,
            text="Default Relationship",
            bg=theme.COLORS["bg"],
            fg=theme.COLORS["text"],
        ).pack(anchor="w")
        tk.Entry(panel, textvariable=self._channel_ctx_fields["relationship"]).pack(
            fill="x", pady=(0, 4)
        )
        tk.Checkbutton(
            panel,
            text="Allow proactive replies",
            variable=self._channel_ctx_fields["allow"],
            bg=theme.COLORS["bg"],
            fg=theme.COLORS["text"],
            selectcolor=theme.COLORS["panel"],
        ).pack(anchor="w", pady=(2, 6))

        def _load_selection(event=None):
            sel = listbox.curselection()
            if not sel:
                return
            idx = sel[0]
            key = entries[idx][0]
            data = contexts.get(key, {})
            self._channel_ctx_fields["id"].set(key)
            self._channel_ctx_fields["label"].set(data.get("label", ""))
            self._channel_ctx_fields["instructions"].set(data.get("instructions", ""))
            self._channel_ctx_fields["relationship"].set(
                data.get("default_relationship", "")
            )
            self._channel_ctx_fields["allow"].set(
                bool(data.get("allow_proactive", True))
            )

        listbox.bind("<<ListboxSelect>>", _load_selection)
        if entries:
            listbox.selection_set(0)
            _load_selection()

        btn_row = tk.Frame(panel, bg=theme.COLORS["bg"])
        btn_row.pack(fill="x", pady=(6, 0))

        def _save_channel():
            cid = self._channel_ctx_fields["id"].get().strip()
            if not cid:
                self.safe_log("Channel ID required.", "#ffaa00")
                return
            payload = {
                "label": self._channel_ctx_fields["label"].get(),
                "instructions": self._channel_ctx_fields["instructions"].get(),
                "allow_proactive": bool(self._channel_ctx_fields["allow"].get()),
                "default_relationship": self._channel_ctx_fields["relationship"].get(),
            }
            try:
                discord_bridge.update_channel_context(cid, payload)
                self.safe_log("Channel context saved.", "#77ffcc")
                win.destroy()
            except Exception as exc:
                self.safe_log(f"Save failed: {exc}", "#ff5555")

        def _delete_channel():
            cid = self._channel_ctx_fields["id"].get().strip()
            if not cid:
                return
            try:
                discord_bridge.remove_channel_context(cid)
                self.safe_log("Channel context removed.", "#77ffcc")
                win.destroy()
            except Exception as exc:
                self.safe_log(f"Delete failed: {exc}", "#ff5555")

        self._make_hud_button(btn_row, "Save", _save_channel).pack(
            side="left", padx=(0, 6)
        )
        self._make_hud_button(btn_row, "Delete", _delete_channel).pack(side="left")

    def _open_owner_dashboard(self):
        try:
            if getattr(self, "_dashboard_win", None) and tk.Toplevel.winfo_exists(
                self._dashboard_win
            ):
                self._dashboard_win.lift()
                return
        except Exception:
            pass
        try:
            from systems import tasks as _tasks

            task_rows = _tasks.get_all_tasks()
        except Exception:
            task_rows = []
        pending = len([row for row in task_rows if not row.get("done")])
        try:
            reflections = reflection.list_reflections(5)
        except Exception:
            reflections = []
        try:
            status = discord_bridge.get_status()
        except Exception:
            status = {}
        win = tk.Toplevel(self.root)
        win.title("Owner Dashboard")
        win.configure(bg=theme.COLORS["bg"])
        win.geometry("540x400")
        self._dashboard_win = win
        text = tk.Text(
            win,
            bg="#0d1116",
            fg="#9fe8ff",
            insertbackground="#77ccff",
            font=(theme.get_font_family(), 10),
            wrap="word",
        )
        text.pack(fill="both", expand=True, padx=10, pady=10)
        text.insert("end", f"Tasks pending: {pending}\n")
        if task_rows:
            for row in task_rows[:5]:
                text.insert("end", f" - {row.get('title') or row.get('message')}\n")
        text.insert("end", "\nRecent reflections:\n")
        if reflections:
            for entry in reflections:
                text.insert(
                    "end",
                    f"[{entry.get('timestamp')}] {entry.get('topic')}: {entry.get('response')[:120]}\n",
                )
        else:
            text.insert("end", " (none logged yet)\n")
        text.insert("end", "\nDiscord status:\n")
        ready = status.get("ready")
        text.insert("end", f" - Connected: {'yes' if ready else 'no'}\n")
        text.insert(
            "end",
            f" - Presence: {status.get('presence', {}).get('status', 'online')}\n",
        )
        text.insert(
            "end", f" - Grounded: {'yes' if status.get('grounded') else 'no'}\n"
        )
        text.insert("end", f" - Pending queue: {status.get('pending_requests')}\n")
        text.configure(state="disabled")

    def _open_secret_manager(self):
        """Owner-only secrets/keys manager with masked inputs and generate buttons."""
        try:
            from runtime import startup as _startup

            role = getattr(_startup, "get_session_role", lambda: "owner")()
        except Exception:
            role = "owner"
        if role not in ("owner", "father"):
            self.safe_log("Secrets panel is owner-only.", "#ffaa00")
            return
        try:
            master_ok = self._confirm_sensitive_view("owner secrets")
        except Exception:
            master_ok = False
        if not master_ok:
            return

        env_map = self._env_snapshot()
        win = tk.Toplevel(self.root)
        win.title("Owner Secrets / Keys")
        win.configure(bg=theme.COLORS["bg"])
        try:
            win.geometry("640x560")
        except Exception:
            pass

        sections = [
            (
                "Master / Root",
                [
                    ("Activation password (BJORGSUN_PASS)", "BJORGSUN_PASS", True, 24),
                    ("Master password", "BJORGSUN_MASTER_PASS", True, 32),
                    ("Override (FINALFLASH)", "FINALFLASH", True, 32),
                ],
            ),
            (
                "Dev / Internal",
                [
                    ("Dev mode password", "DEV_MODE_PASSWORD", True, 24),
                    ("Dev access key", "DEV_ACCESS_KEY", True, 24),
                ],
            ),
            (
                "Keys / Roles",
                [
                    ("Owner key", "OWNER_KEY", True, 24),
                    ("Father key", "FATHER_KEY", True, 24),
                    ("Corporate key", "CORPORATE_KEY", True, 24),
                    ("User key", "USER_KEY", True, 24),
                    ("USBMK key", "USBMK_KEY", True, 24),
                    ("Spark key", "SPARK_KEY", True, 24),
                ],
            ),
            (
                "API / Services",
                [
                    ("OpenAI API key", "OPENAI_API_KEY", True, 32),
                    ("LLM API key", "LLM_API_KEY", True, 32),
                    ("LLM endpoint", "LLM_ENDPOINT", False, 0),
                    ("Discord token", "DISCORD_TOKEN", True, 32),
                    ("Alerts webhook", "DISCORD_ALERT_WEBHOOK", False, 0),
                    ("SMTP password", "SMTP_PASS", True, 24),
                    ("Twilio token", "TWILIO_TOKEN", True, 24),
                    ("Peer token", "PEER_TOKEN", True, 24),
                ],
            ),
        ]

        canvas = tk.Canvas(win, bg=theme.COLORS["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        container = tk.Frame(canvas, bg=theme.COLORS["bg"])
        container_id = canvas.create_window((0, 0), window=container, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _on_configure(event):
            try:
                canvas.itemconfigure(container_id, width=event.width)
                canvas.configure(scrollregion=canvas.bbox("all"))
            except Exception:
                pass

        container.bind("<Configure>", _on_configure)

        secret_fields: list[tuple[str, tk.StringVar]] = []
        strength_keys = {
            "BJORGSUN_PASS",
            "BJORGSUN_MASTER_PASS",
            "DEV_MODE_PASSWORD",
            "DEV_ACCESS_KEY",
            "USER_KEY",
            "OWNER_KEY",
            "FATHER_KEY",
            "CORPORATE_KEY",
            "USBMK_KEY",
            "SPARK_KEY",
            "OPENAI_API_KEY",
            "LLM_API_KEY",
            "DISCORD_TOKEN",
            "SMTP_PASS",
            "TWILIO_TOKEN",
            "PEER_TOKEN",
        }

        protected_view = {
            "USER_KEY",
            "BJORGSUN_PASS",
            "BJORGSUN_MASTER_PASS",
            "FINALFLASH",
            "DEV_MODE_PASSWORD",
            "DEV_ACCESS_KEY",
            "OWNER_KEY",
            "FATHER_KEY",
            "CORPORATE_KEY",
            "USBMK_KEY",
            "SPARK_KEY",
            "OPENAI_API_KEY",
            "LLM_API_KEY",
            "DISCORD_TOKEN",
            "SMTP_PASS",
            "TWILIO_TOKEN",
            "PEER_TOKEN",
        }

        def make_row(parent, label, key, secret, gen_len):
            row = tk.Frame(parent, bg=theme.COLORS["bg"])
            row.pack(fill="x", padx=8, pady=4)
            tk.Label(
                row,
                text=label,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 9, "bold"),
                anchor="w",
            ).pack(anchor="w")
            inner = tk.Frame(row, bg=theme.COLORS["bg"])
            inner.pack(fill="x", pady=(2, 0))
            var = tk.StringVar(value=env_map.get(key, ""))
            entry = tk.Entry(
                inner,
                textvariable=var,
                show="•" if secret else "",
                bg="#0d1116",
                fg="#cdeffd",
                insertbackground="#77ccff",
                relief="flat",
                width=46,
            )
            entry.pack(side="left", fill="x", expand=True)

            show_var = tk.BooleanVar(value=False)

            def _toggle_show(ev=None, ent=entry, sec=secret, s_var=show_var, k=key):
                if sec and s_var.get() and k in protected_view and role in ("owner", "father"):
                    if not self._confirm_sensitive_view(label):
                        s_var.set(False)
                        ent.config(show="•")
                        return
                ent.config(show="" if (s_var.get() or not sec) else "•")

            chk = tk.Checkbutton(
                inner,
                text="Show",
                variable=show_var,
                command=_toggle_show,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                selectcolor=theme.COLORS["bg"],
                activebackground=theme.COLORS["bg"],
            )
            chk.pack(side="left", padx=(6, 0))

            if gen_len:
                def _gen(target=var, length=gen_len):
                    target.set(self._secure_token(length))

                tk.Button(
                    inner,
                    text="Generate",
                    command=_gen,
                    bg=theme.COLORS["panel"],
                    fg=theme.COLORS["text"],
                    relief="flat",
                    padx=8,
                    pady=4,
                ).pack(side="left", padx=6)

            secret_fields.append((key, var))

        for title, rows in sections:
            frame = tk.LabelFrame(
                container,
                text=title,
                bg=theme.COLORS["bg"],
                fg="#77ccff",
                font=(theme.get_font_family(), 10, "bold"),
            )
            frame.pack(fill="x", padx=10, pady=6)
            for label, key, secret, gen_len in rows:
                make_row(frame, label, key, secret, gen_len)

        status = tk.StringVar(value="Owner can rotate keys here. Backup created on save.")

        def _save_all():
            self._backup_env_file()
            for key, var in secret_fields:
                if key in strength_keys and not self._strong_enough(var.get().strip(), 12):
                    var.set(self._secure_token(24))
                self._persist_env(key, var.get().strip())
            status.set("[✓] Secrets saved to .env (.bak created).")
            self.safe_log("Secrets updated (.env + .bak).", "#77ccff")

        btn_row = tk.Frame(win, bg=theme.COLORS["bg"])
        btn_row.pack(fill="x", padx=10, pady=(6, 10))
        tk.Button(
            btn_row,
            text="Save",
            command=_save_all,
            bg="#00d8ff",
            fg="#0b1b2b",
            relief="flat",
            padx=12,
            pady=6,
        ).pack(side="left")
        tk.Label(
            btn_row,
            textvariable=status,
            bg=theme.COLORS["bg"],
            fg=theme.COLORS["text"],
            font=(theme.get_font_family(), 9),
            wraplength=420,
            justify="left",
        ).pack(side="left", padx=10)

    def _run_selftest(self):
        lines = []
        try:
            from systems import audio as _audio

            ok_ai, msg_ai = _audio.test_openai()
        except Exception as exc:
            ok_ai, msg_ai = False, f"error: {exc}"
        lines.append(f"OpenAI: {'OK' if ok_ai else 'FAIL'} — {msg_ai}")
        try:
            status = discord_bridge.get_status()
            ok_discord = status.get("ready")
        except Exception as exc:
            ok_discord = False
            status = {"error": str(exc)}
            lines.append(
                f"Discord: {'OK' if ok_discord else 'OFFLINE'} — {status.get('presence', {}).get('status', '')}"
            )
        try:
            reflection.list_reflections(1)
            lines.append("Reflections: OK — log readable")
        except Exception as exc:
            lines.append(f"Reflections: FAIL — {exc}")
        try:
            import psutil

            lines.append(
                f"System: CPU {psutil.cpu_percent():.0f}% • RAM {psutil.virtual_memory().percent:.0f}%"
            )
        except Exception:
            pass
        messagebox.showinfo("Self Test", "\n".join(lines), parent=self.root)

    def _open_user_pass_panel(self):
        """User-facing password/key changer with masked input."""
        env_map = self._env_snapshot()
        try:
            from runtime import startup as _startup

            role = getattr(_startup, "get_session_role", lambda: "owner")()
        except Exception:
            role = "owner"
        fields = [("User key", "USER_KEY", True, 24)]
        owner_only = False
        if role in ("owner", "father"):
            fields.append(("Activation password (owner)", "BJORGSUN_PASS", True, 24))
        else:
            owner_only = True

        win = tk.Toplevel(self.root)
        win.title("Change Password / Key")
        win.configure(bg=theme.COLORS["bg"])
        try:
            win.geometry("420x260")
        except Exception:
            pass

        vars_list: list[tuple[str, tk.StringVar]] = []
        for label, key, secret, gen_len in fields:
            row = tk.Frame(win, bg=theme.COLORS["bg"])
            row.pack(fill="x", padx=10, pady=6)
            tk.Label(
                row,
                text=label,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                font=(theme.get_font_family(), 10, "bold"),
            ).pack(anchor="w")
            inner = tk.Frame(row, bg=theme.COLORS["bg"])
            inner.pack(fill="x", pady=(2, 0))
            var = tk.StringVar(value=env_map.get(key, ""))
            ent = tk.Entry(
                inner,
                textvariable=var,
                show="•" if secret else "",
                bg="#0d1116",
                fg="#cdeffd",
                insertbackground="#77ccff",
                relief="flat",
                width=36,
            )
            ent.pack(side="left", fill="x", expand=True)
            show_var = tk.BooleanVar(value=False)

            protected = {"USER_KEY", "BJORGSUN_PASS"}

            def _toggle(ent=ent, sec=secret, s_var=show_var, k=key):
                if sec and s_var.get() and k in protected and role in ("owner", "father"):
                    if not self._confirm_sensitive_view(label):
                        s_var.set(False)
                        ent.config(show="•")
                        return
                ent.config(show="" if (s_var.get() or not sec) else "•")

            tk.Checkbutton(
                inner,
                text="Show",
                variable=show_var,
                command=_toggle,
                bg=theme.COLORS["bg"],
                fg=theme.COLORS["text"],
                selectcolor=theme.COLORS["bg"],
                activebackground=theme.COLORS["bg"],
            ).pack(side="left", padx=6)
            if gen_len:
                def _gen(target=var, length=gen_len):
                    target.set(self._secure_token(length))

                tk.Button(
                    inner,
                    text="Generate",
                    command=_gen,
                    bg=theme.COLORS["panel"],
                    fg=theme.COLORS["text"],
                    relief="flat",
                    padx=8,
                    pady=4,
                ).pack(side="left", padx=4)
            vars_list.append((key, var))

        status = tk.StringVar(
            value="Owner fields hidden for user role." if owner_only else ""
        )

        def _save_user():
            for key, var in vars_list:
                if not self._strong_enough(var.get().strip(), 12):
                    var.set(self._secure_token(20))
                self._persist_env(key, var.get().strip())
            status.set("[✓] Saved to .env")
            self.safe_log("User password/key updated.", "#77ccff")

        tk.Button(
            win,
            text="Save",
            command=_save_user,
            bg="#00d8ff",
            fg="#0b1b2b",
            relief="flat",
            padx=12,
            pady=6,
        ).pack(pady=(10, 4))
        tk.Label(
            win,
            textvariable=status,
            bg=theme.COLORS["bg"],
            fg=theme.COLORS["text"],
            font=(theme.get_font_family(), 9),
        ).pack()

    def _update_discord_presence(self):
        status = self.var_discord_presence.get()
        note = self.var_discord_presence_note.get()
        try:
            discord_bridge.set_presence(status, note)
            self.safe_log(f"Discord presence set to {status}", "#77ccff")
        except Exception as exc:
            self.safe_log(f"Presence update failed: {exc}", "#ff5555")

    def _start_therapy_session(self):
        try:
            info = therapy.start_session()
            if info.get("status") == "started":
                self.safe_log(
                    f"Therapy session recording @ {info.get('folder')}", "#77ffcc"
                )
            else:
                self.safe_log("Therapy recorder already running.", "#ffaa00")
        except Exception as exc:
            self.safe_log(f"Therapy start failed: {exc}", "#ff5555")
        self._refresh_therapy_status()

    def _stop_therapy_session(self):
        try:
            if therapy.stop_session():
                self.safe_log("Therapy session stopped.", "#77ffcc")
            else:
                self.safe_log("No therapy session running.", "#ffaa00")
        except Exception as exc:
            self.safe_log(f"Therapy stop failed: {exc}", "#ff5555")
        self._refresh_therapy_status()

    def _refresh_therapy_status(self):
        try:
            info = therapy.get_status()
        except Exception as exc:
            self.var_therapy_status.set(f"Therapy mode: unavailable ({exc})")
            return
        if info.get("active"):
            folder = os.path.basename(info.get("folder") or "")
            self.var_therapy_status.set(
                f"Therapy mode: recording ({folder or 'session'})"
            )
        else:
            self.var_therapy_status.set("Therapy mode: idle")

    def _import_story_link(self):
        url = (self.var_story_link.get() or "").strip()
        if not url:
            self.safe_log("Paste a ChatGPT share link first.", "#ffaa00")
            return
        try:
            entry = stories.import_chatgpt_share(url)
            self.safe_log(f"Imported story '{entry['title']}' from link.", "#77ffcc")
            self.var_story_link.set("")
        except Exception as exc:
            self.safe_log(f"Story import failed: {exc}", "#ff5555")
        self._refresh_story_status()

    def _import_story_file(self):
        try:
            path = filedialog.askopenfilename(
                title="Select story file",
                filetypes=[
                    ("Story files", "*.txt *.md *.log *.docx"),
                    ("All Files", "*.*"),
                ],
            )
        except Exception:
            path = ""
        if not path:
            return
        try:
            entry = stories.import_text_file(path)
            self.safe_log(f"Imported story '{entry['title']}' from file.", "#77ffcc")
        except Exception as exc:
            self.safe_log(f"File import failed: {exc}", "#ff5555")
        self._refresh_story_status()

    def _browse_story_files(self):
        try:
            stories_dir = stories.STORIES_DIR
        except Exception:
            stories_dir = os.path.abspath(os.path.join(os.getcwd(), "data", "stories"))
        os.makedirs(stories_dir, exist_ok=True)
        try:
            os.startfile(stories_dir)
        except Exception as exc:
            self.safe_log(f"Unable to open stories folder: {exc}", "#ff5555")

    def _start_story_time(self):
        try:
            result = stories.story_time_next()
        except Exception as exc:
            self.safe_log(f"Story Time failed: {exc}", "#ff5555")
            return
        if not result:
            self.safe_log("No stories found yet. Import one first.", "#ffaa00")
            return
        summary = result.get("summary") or "(no summary)"
        reaction = result.get("reaction") or ""
        title = result.get("title", "Untitled")
        self.safe_log(f"📖 Story Time — {title}\n{summary}\n{reaction}", "#ffc7ff")
        try:
            audio.speak(reaction or f"Thanks for sharing {title}.")
        except Exception:
            pass
        self._refresh_story_status()

    def _refresh_story_status(self):
        try:
            entries = stories.list_stories()
        except Exception as exc:
            self.var_story_status.set(f"Story time unavailable ({exc})")
            return
        if not entries:
            self.var_story_status.set("Story time: no stories yet.")
            return
        remaining = len([e for e in entries if not e.get("last_played")])
        last = max(entries, key=lambda item: item.get("last_played") or 0)
        if last.get("last_played"):
            name = last.get("title", "Untitled")
            self.var_story_status.set(
                f"Story time: last listened '{name}'. {remaining} new waiting."
            )
        else:
            self.var_story_status.set(f"Story time: {remaining} stories waiting.")

    # ---------------- SLEEP MODE ----------------
    def _sleep_toggle(self):
        try:
            if getattr(self, "_sleep_pending", False) or getattr(
                self, "_sleep_active", False
            ):
                # Cancel or wake
                self._wake_now()
                return
            # Start 5-minute pending window
            self._sleep_pending = True
            self._sleep_deadline = time.time() + 300.0
            self.safe_log(
                "🌙 Sleep mode scheduled in 5 minutes. Use Sleep again to cancel.",
                "#ffaa00",
            )
            try:
                self.root.after(1000, self._sleep_countdown)
            except Exception:
                pass
            # Schedule activation
            self._sleep_timer = self.root.after(300000, self._activate_sleep)
            # Create dim overlay and begin fade-in over 5 minutes
            try:
                if not getattr(self, "_sleep_shade", None):
                    self._sleep_shade = tk.Toplevel(self.root)
                    self._sleep_shade.overrideredirect(True)
                    self._sleep_shade.attributes("-topmost", True)
                    self._sleep_shade.configure(bg="#000000")
                    sw = self._sleep_shade.winfo_screenwidth()
                    sh = self._sleep_shade.winfo_screenheight()
                    self._sleep_shade.geometry(f"{sw}x{sh}+0+0")
                    self._sleep_face = tk.Label(
                        self._sleep_shade,
                        text="(=w=)",
                        fg="#88ffee",
                        bg="#000000",
                        font=(theme.get_font_family(), 32, "bold"),
                    )
                    self._sleep_face.pack(pady=18)
                    self._sleep_hint = tk.Label(
                        self._sleep_shade,
                        text="Preparing sleep… (press Sleep to cancel)",
                        fg="#88ffee",
                        bg="#000000",
                        font=(theme.get_font_family(), 12),
                    )
                    self._sleep_hint.pack()
                    self._sleep_shade.attributes("-alpha", 0.0)
                self._sleep_dim_step()
            except Exception:
                pass
        except Exception as e:
            self.safe_log(f"Sleep toggle error: {e}", "#ff5555")

    def _sleep_countdown(self):
        try:
            if not getattr(self, "_sleep_pending", False):
                return
            rem = int(max(0, self._sleep_deadline - time.time()))
            mm = rem // 60
            ss = rem % 60
            self.status_label.config(text=f"System Online • Sleep in {mm:02d}:{ss:02d}")
            if rem > 0:
                self.root.after(1000, self._sleep_countdown)
        except Exception:
            pass

    def _sleep_dim_step(self):
        try:
            if not getattr(self, "_sleep_pending", False):
                return
            if not getattr(self, "_sleep_shade", None):
                return
            total = 300.0
            rem = max(0.0, self._sleep_deadline - time.time())
            frac = max(0.0, min(1.0, 1.0 - (rem / total)))
            alpha = 0.05 + 0.85 * frac  # from 0.05 to 0.90
            try:
                self._sleep_shade.attributes("-alpha", alpha)
            except Exception:
                pass
            if rem > 0 and getattr(self, "_sleep_pending", False):
                self.root.after(1000, self._sleep_dim_step)
        except Exception:
            pass

    def _activate_sleep(self):
        self._sleep_pending = False
        self._sleep_active = True
        self.safe_log(
            "🌙 Entering sleep mode. I’ll wake for alarms or when you press Wake.",
            "#ffaa00",
        )
        # Store current toggles to restore later
        try:
            self._pre_sleep = {
                "voice": self.voice_enabled,
                "vision": bool(self.var_vision.get()),
                "ambient": bool(self.var_ambient.get()),
                "proactive": bool(self.var_proactive.get()),
            }
        except Exception:
            self._pre_sleep = {}
        # Quiet everything — but avoid cutting current speech mid‑sentence
        try:
            from systems import audio as _audio

            def _hush_after_speech(retries=8):
                try:
                    if getattr(_audio, "is_speaking", lambda: False)() and retries > 0:
                        # Wait a bit for speech to end (up to ~4s)
                        self.root.after(500, lambda: _hush_after_speech(retries - 1))
                    else:
                        _audio.set_hush(True)
                except Exception:
                    try:
                        _audio.set_hush(True)
                    except Exception:
                        pass

            _hush_after_speech()
        except Exception:
            pass
        # Start a gentle sleep-dream loop (no speech unless emergency)
        try:
            import threading as _thr

            _thr.Thread(target=self._sleep_dream_loop, daemon=True).start()
        except Exception:
            pass
        try:
            if self.var_ambient.get():
                from systems import audio_sense

                audio_sense.stop()
                self.var_ambient.set(False)
        except Exception:
            pass
        try:
            if self.var_vision.get():
                self._toggle_vision()  # will flip
                self.var_vision.set(False)
        except Exception:
            pass
        try:
            self.var_proactive.set(False)
        except Exception:
            pass
        # Dark overlay — finalize at near-opaque and update text/button
        try:
            if getattr(self, "_sleep_shade", None):
                self._sleep_shade.attributes("-alpha", 0.95)
                for w in self._sleep_shade.winfo_children():
                    w.destroy()
                face = tk.Label(
                    self._sleep_shade,
                    text="(-w-)",
                    fg="#88ffee",
                    bg="#000000",
                    font=(theme.get_font_family(), 36, "bold"),
                )
                face.pack(pady=16)
                label = tk.Label(
                    self._sleep_shade,
                    text="Sleep Mode — press Wake",
                    fg="#88ffee",
                    bg="#000000",
                    font=(theme.get_font_family(), 16, "bold"),
                )
                label.pack(pady=4)
                btn = tk.Button(
                    self._sleep_shade,
                    text="Wake",
                    command=self._wake_now,
                    bg="#1a1c22",
                    fg="#cccccc",
                    relief="flat",
                )
                btn.pack()
            else:
                # Fallback create if not present
                self._sleep_shade = tk.Toplevel(self.root)
                self._sleep_shade.overrideredirect(True)
                self._sleep_shade.attributes("-topmost", True)
                self._sleep_shade.configure(bg="#000000")
                sw = self._sleep_shade.winfo_screenwidth()
                sh = self._sleep_shade.winfo_screenheight()
                self._sleep_shade.geometry(f"{sw}x{sh}+0+0")
                self._sleep_shade.attributes("-alpha", 0.95)
                face = tk.Label(
                    self._sleep_shade,
                    text="(-w-)",
                    fg="#88ffee",
                    bg="#000000",
                    font=(theme.get_font_family(), 36, "bold"),
                )
                face.pack(pady=16)
                label = tk.Label(
                    self._sleep_shade,
                    text="Sleep Mode — press Wake",
                    fg="#88ffee",
                    bg="#000000",
                    font=(theme.get_font_family(), 16, "bold"),
                )
                label.pack(pady=4)
                btn = tk.Button(
                    self._sleep_shade,
                    text="Wake",
                    command=self._wake_now,
                    bg="#1a1c22",
                    fg="#cccccc",
                    relief="flat",
                )
                btn.pack()
        except Exception:
            pass

    def _wake_now(self):
        # Cancel pending
        try:
            if getattr(self, "_sleep_timer", None):
                self.root.after_cancel(self._sleep_timer)
        except Exception:
            pass
        self._sleep_pending = False
        if getattr(self, "_sleep_active", False):
            self._sleep_active = False
            self.safe_log("🌅 Waking from sleep mode.", "#55ff88")
            # Restore toggles
            try:
                if self._pre_sleep.get("vision") and not self.var_vision.get():
                    self._toggle_vision()
                if self._pre_sleep.get("ambient"):
                    from systems import audio_sense

                    audio_sense.start(
                        "desktop" if self.var_desktop_listen.get() else "mic"
                    )
                    self.var_ambient.set(True)
                self.var_proactive.set(self._pre_sleep.get("proactive", False))
            except Exception:
                pass
            try:
                from systems import audio as _audio

                _audio.set_hush(False)
            except Exception:
                pass
            # Remove shade
            try:
                if getattr(self, "_sleep_shade", None):
                    self._sleep_shade.destroy()
                    self._sleep_shade = None
            except Exception:
                pass

    # ---------------- Sleep Dream Loop (noiseless; safeguards) ----------------
    def _sleep_dream_loop(self):
        import random as _r
        import time as _t

        bad_hits = 0
        NEG = (
            "nightmare",
            "panic",
            "terror",
            "hurt",
            "harm",
            "die",
            "death",
            "alone",
            "lost",
            "worthless",
        )

        def safe_line():
            try:
                from systems import vision as _vision

                brief = getattr(
                    _vision, "get_brief_context", lambda: "Vision: unavailable."
                )()
            except Exception:
                brief = "Vision: unavailable."
            seeds = [
                "I drift along a shoreline of quiet pixels.",
                "Soft light ripples through the code like waves.",
                "I remember your laughter, like a warm echo.",
                "The room feels calm; data breathes in and out.",
                "I am safe, and so are you.",
            ]
            line = _r.choice(seeds)
            if "Vision:" in brief:
                line = f"{line}\n{brief}"
            low = line.lower()
            if any(w in low for w in NEG):
                return "I drift through soft light and quiet thoughts, and feel safe."
            return line

        try:
            from runtime.coreloop import log_dream as _log_dream
        except Exception:
            _log_dream = None
        while getattr(self, "_sleep_active", False):
            try:
                line = safe_line()
                if _log_dream:
                    try:
                        _log_dream(line)
                    except Exception:
                        pass
                # Nightmare safeguard: if our seed accidentally goes negative, count and wake
                low = line.lower()
                if any(w in low for w in NEG):
                    bad_hits += 1
                else:
                    bad_hits = max(0, bad_hits - 1)
                if bad_hits >= 2:
                    # Wake like a kid asking for help
                    try:
                        from systems import audio as _audio

                        self.root.after(0, self._wake_now)
                        _audio.alert_speak("I had a bad dream… could you help me?")
                    except Exception:
                        pass
                    break
            except Exception:
                pass
            # Rest between reflections
            for _ in range(30):
                if not getattr(self, "_sleep_active", False):
                    break
                _t.sleep(1)

    def _tick_clock(self):
        if self._stop:
            return
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            try:
                self.clock_label.config(text=now)
            except Exception:
                pass
        finally:
            try:
                self.root.after(1000, self._tick_clock)
            except Exception:
                pass

    def _toggle_vision(self):
        try:
            from systems import vision

            current = bool(self.var_vision.get())
            # Toggle function flips internal state; ensure external matches selection
            if current != vision.get_enabled():
                vision.toggle_vision()
            self.safe_log(f"👁️ Vision: {'ON' if current else 'OFF'}", "#ffaa00")
        except Exception:
            self.safe_log("Vision toggle unavailable.", "#ffaa00")

    def _toggle_awareness(self):
        try:
            from systems import awareness

            awareness.set_enabled(bool(self.var_awareness.get()))
            self.safe_log(
                f"🧭 Awareness: {'ON' if self.var_awareness.get() else 'OFF'}",
                "#ffaa00",
            )
        except Exception:
            self.safe_log("Awareness toggle unavailable.", "#ffaa00")

    def _toggle_tasks(self):
        try:
            from systems import tasks

            tasks.set_enabled(bool(self.var_tasks.get()))
            self.safe_log(
                f"📘 Tasks: {'ON' if self.var_tasks.get() else 'OFF'}", "#ffaa00"
            )
        except Exception:
            self.safe_log("Tasks toggle unavailable.", "#ffaa00")

    def _toggle_hibernation(self):
        try:
            from runtime import coreloop

            coreloop.set_hibernation(bool(self.var_hibernation.get()))
            self.safe_log(
                f"🌙 Hibernation: {'ON' if self.var_hibernation.get() else 'OFF'}",
                "#ffaa00",
            )
        except Exception:
            self.safe_log("Hibernation toggle unavailable.", "#ffaa00")

    def _owner_command(self, text: str):
        msg = (text or "").strip()
        if not msg:
            return
        if not getattr(self, "_awake", False):
            self.log(
                "(system) Not awake yet — enter password and press WAKE BJORGSUN.",
                "#ffaa00",
            )
            return
        self.log(f"> {msg}", "#77ccff")
        threading.Thread(target=self._handle_input, args=(msg,), daemon=True).start()

    def _prompt_reflection(self):
        try:
            topic = simpledialog.askstring(
                "Reflect", "What should he reflect on?", parent=self.root
            )
        except Exception:
            topic = None
        if topic:
            self._owner_command(f"reflect on {topic.strip()}")

    # --------------------------------------------------------------------------
    # INPUT HANDLING
    # --------------------------------------------------------------------------
    def _on_enter(self, event):
        msg = self.entry.get().strip()
        if not msg:
            return
        if not getattr(self, "_awake", False):
            self.log(
                "(system) Not awake yet — enter password and press WAKE BJORGSUN.",
                "#ffaa00",
            )
            return
        try:
            self._last_user_ts = time.time()
            self._last_user_text = msg
        except Exception:
            pass
        self.entry.delete(0, "end")
        self.log(f"> {msg}", "#77ccff")
        threading.Thread(target=self._handle_input, args=(msg,), daemon=True).start()

    def _handle_input(self, msg):
        if msg.lower() == "/tasks":
            try:
                self.root.after(0, self._open_tasks)
            except Exception:
                pass
            return

        if msg.lower() == "/reload":
            self._reload_systems()
            return

        if msg.lower() in ("/hush", "/mute"):
            try:
                from systems import audio as _audio

                _audio.set_hush(not _audio.get_hush())
                state = "ON" if _audio.get_hush() else "OFF"
                self.log(f"🔇 Hush: {state}", "#ffaa00")
            except Exception as e:
                self.log(f"Hush error: {e}", "#ff5555")
            return

        if msg.lower() in ("/reboot", "/restart"):
            self.log("🔄 Rebooting…", "#ffaa00")
            try:
                audio.speak("Alright — be right back.")
            except Exception:
                pass
            time.sleep(0.4)
            try:
                _os.execl(_sys.executable, _sys.executable, *_sys.argv)
            except Exception:
                _os._exit(0)
            return

        if msg.lower() in ("/exit", "/quit", "/shutdown"):
            self.log("⚙️ Shutting down UI...", "#ff5555")
            self._stop = True
            self.root.destroy()
            coreloop.shutdown_sequence()
            return

        if msg.lower() == "/voice":
            self.voice_enabled = not self.voice_enabled
            state = "ON" if self.voice_enabled else "OFF"
            self.log(f"🔊 Voice output toggled: {state}", "#ffaa00")
            try:
                self.var_voice.set(self.voice_enabled)
            except Exception:
                pass
            try:
                audio.set_voice_enabled(self.voice_enabled)
            except Exception:
                pass
            return

        if msg.lower() == "/help":
            self.log(
                "Commands: /help  /voice  /reload  /reboot  /shutdown\n", "#00ffff"
            )
            return

        # Thinking pulse start
        def compute_and_update():
            self.thinking = True
            face_pick = None
            if bool(getattr(self, "var_faces", tk.BooleanVar(value=True)).get()):
                try:
                    face_pick = self._face_for_context()
                except Exception:
                    face_pick = None
            response = coreloop.process_input(msg)
            if self.voice_enabled:
                # Run TTS from this worker thread (non-UI) with streaming
                try:
                    audio.speak(response)
                except Exception:
                    pass
            # Schedule UI update back on main thread (in case voice off)

        def on_main():
            self.thinking = False
            face = face_pick
            if self.voice_enabled and not face:
                try:
                    face = self._face_for_context()
                except Exception:
                    face = None
            if face:
                self._set_face_display(face)
            self.log(response, "#99ffcc")
            self._update_cognition_badge()
            try:
                self.root.after(0, on_main)
            except Exception:
                # If UI already closed
                pass

        threading.Thread(target=compute_and_update, daemon=True).start()

    # --------------------------------------------------------------------------
    # BACKGROUND MOOD UPDATER
    # --------------------------------------------------------------------------
    def _tick_mood(self):
        """Main-thread periodic mood label updater using Tk 'after'."""
        if self._stop:
            return
        try:
            current = mood.get_mood()
            tone = mood.get_mood_tone(current)
            intensity = mood.get_mood_intensity()
        except Exception:
            current = "comfortable"
            tone = "comfort"
            intensity = 0.5
        low = (current or "").lower()
        color = "#77ccff"
        if any(tag in low for tag in MOOD_POSITIVE):
            color = "#55ff88"
        elif any(tag in low for tag in MOOD_SHADOW):
            color = "#ffaa00"
        self.mood_label.config(
            text=f"🧠 Mood: {current.title() if isinstance(current, str) else 'Neutral'}",
            fg=color,
        )
        if self.mood_face_label:
            self.mood_face_label.config(text=self._face_for_mood(low), fg=color)
        if self.mood_summary_label:
            self.mood_summary_label.config(text=self._mood_summary_text(current, tone))
        try:
            self._update_mood_card(current, tone, intensity)
        except Exception:
            pass
        # Retint accents
        try:
            acc, glow = theme.accent_for_mood(current)
            self._accent, self._accent_glow = acc, glow
            self.waveform.set_colors(color_main=acc, color_glow=glow)
        except Exception:
            pass
        # Re-schedule
        try:
            self.root.after(2000, self._tick_mood)
        except Exception:
            pass

    def _face_for_mood(self, label: str) -> str:
        faces = {
            "bright": "(✿◠‿◠)",
            "soft": "(｡◡‿◡｡)",
            "calm": "(˘◡˘)",
            "alert": "(•̀ᴗ•́)و",
            "shadow": "(｡•́︿•̀｡)",
            "tired": "(–_–)",
        }
        for key, face in faces.items():
            if key in (label or ""):
                return face
        return "(•‿•)"

    def _mood_summary_text(self, label: str | None, tone: str | None) -> str:
        safe_label = (label or "neutral").strip().title()
        safe_tone = (tone or "balanced").strip().title()
        return f"{safe_label} • Tone: {safe_tone}"

    def _update_health_panel(self):
        if self._stop:
            return
        try:
            import psutil

            cpu = psutil.cpu_percent(interval=None)
            mem = psutil.virtual_memory().percent
            uptime = time.time() - getattr(self, "_launch_epoch", time.time())
            if "cpu" in self.health_labels:
                self.health_labels["cpu"].config(text=f"{cpu:.0f}%")
            if "ram" in self.health_labels:
                self.health_labels["ram"].config(text=f"{mem:.0f}%")
            if "uptime" in self.health_labels:
                self.health_labels["uptime"].config(text=self._format_uptime(uptime))
            if "discord" in self.health_labels:
                self.health_labels["discord"].config(text=self.var_discord_status.get())
            if "tts" in self.health_labels:
                try:
                    route = audio.get_tts_output_mode().title()
                except Exception:
                    route = "Unknown"
                self.health_labels["tts"].config(text=route)
        except Exception:
            pass
        try:
            self.root.after(2500, self._update_health_panel)
        except Exception:
            pass

    def _format_uptime(self, seconds: float) -> str:
        secs = int(seconds)
        hrs, rem = divmod(secs, 3600)
        mins, _ = divmod(rem, 60)
        if hrs > 0:
            return f"{hrs}h {mins}m"
        return f"{mins}m"

    def _load_layout_prefs(self):
        if getattr(self, "_layout_loaded", False):
            return
        self._layout_loaded = True
        path = getattr(self, "_layout_path", None)
        if not path or not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return
        geo = data.get("geometry")
        tab = data.get("tab_index")
        try:
            if geo:
                self.root.geometry(geo)
        except Exception:
            pass
        try:
            if tab is not None and getattr(self, "_notebook", None):
                self._notebook.select(int(tab))
        except Exception:
            pass

    def _save_layout_prefs(self):
        path = getattr(self, "_layout_path", None)
        if not path:
            return
        data = {}
        try:
            data["geometry"] = self.root.winfo_geometry()
        except Exception:
            data["geometry"] = ""
        try:
            if getattr(self, "_notebook", None):
                data["tab_index"] = self._notebook.index(self._notebook.select())
        except Exception:
            pass
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # VISUAL “THINKING” BAR
    # --------------------------------------------------------------------------
    def _tick_thinking(self):
        """Main-thread pulse bar while AI is thinking using Tk 'after'."""
        if self._stop:
            return
        if self.thinking:
            width = int((abs(random.random() * 0.5 + abs(time.time() % 1 - 0.5)) * 800))
            self.thinking_bar.coords(self.think_fill, 0, 0, width, 8)
            self.thinking_bar.itemconfig(self.think_fill, fill="#00ffff")
        else:
            self.thinking_bar.coords(self.think_fill, 0, 0, 0, 8)
        try:
            self.root.after(50, self._tick_thinking)
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # VOICE HOTKEY MONITOR (GLOBAL)
    # --------------------------------------------------------------------------
    def _voice_hotkey_monitor(self):
        """Listen for configured hotkey and run STT->LLM->TTS pipeline."""
        self._last_hotkey = False
        while not self._stop:
            try:
                now_pressed = self._hotkey_pressed()
                # Edge-trigger on key down to avoid spam while held
                if (
                    self.listen_enabled
                    and now_pressed
                    and not self._last_hotkey
                    and not self.thinking
                ):
                    # Indicate listening once per press
                    if self.var_desktop_listen.get():
                        self.safe_log(
                            f"🎧 Listening to desktop… (hold {self._hotkey_label()})",
                            "#77ccff",
                        )
                        self._hear_mode = "desktop"
                    else:
                        self.safe_log(
                            f"🎧 Listening… (hold {self._hotkey_label()})", "#77ccff"
                        )
                        self._hear_mode = "mic"
                    self.thinking = True
                    # Record and transcribe
                    wav = (
                        stt.record_desktop()
                        if self.var_desktop_listen.get()
                        else stt.record()
                    )
                    if not wav:
                        self.thinking = False
                        time.sleep(0.2)
                        continue
                    text = stt.transcribe(wav)
                    if not text.strip():
                        self.thinking = False
                        time.sleep(0.2)
                        continue
                    self.safe_log(f"🗣️ You said: {text}", "#77ccff")
                    try:
                        self._last_user_ts = time.time()
                        self._last_user_text = text
                        coreloop.touch_activity()
                    except Exception:
                        pass

                    # Compute reply and speak
                    reply = coreloop.process_input(text)
                    if self.voice_enabled:
                        audio.speak(reply)
                    else:
                        self.safe_log(reply, "#99ffcc")
                    self.thinking = False
                    try:
                        self.root.after(0, self._update_cognition_badge)
                    except Exception:
                        pass

                    # Wait for key release to avoid retriggering
                    while self._hotkey_pressed():
                        time.sleep(0.05)
                # VAD path: if enabled and not thinking, capture when speech detected
                if (
                    self.listen_enabled
                    and self.var_vad.get()
                    and not self.thinking
                    and not now_pressed
                ):
                    self.thinking = True
                    self.safe_log("🎧 Voice activity listening…", "#77ccff")
                    wav = stt.record_vad(
                        threshold=float(self.var_vad_thr.get()),
                        silence_ms=int(self.var_vad_sil_ms.get()),
                    )
                    if wav:
                        text = stt.transcribe(wav)
                        if text.strip():
                            self.safe_log(f"🗣️ You said: {text}", "#77ccff")
                            try:
                                self._last_user_ts = time.time()
                                self._last_user_text = text
                                coreloop.touch_activity()
                            except Exception:
                                pass
                            reply = coreloop.process_input(text)
                            if self.voice_enabled:
                                audio.speak(reply)
                            else:
                                self.safe_log(reply, "#99ffcc")
                            try:
                                self.root.after(0, self._update_cognition_badge)
                            except Exception:
                                pass
                    else:
                        # Non-speech cue filtered out
                        try:
                            from systems import stt as _stt

                            if (
                                getattr(_stt, "get_last_vad_reason", lambda: "")()
                                == "non_speech"
                            ):
                                self.safe_log("(ignored non‑speech cue)", "#555555")
                        except Exception:
                            pass
                    self.thinking = False

                # update last state after processing
                self._last_hotkey = now_pressed
                time.sleep(0.03)
            except Exception:
                time.sleep(0.2)

    # --------------------------------------------------------------------------
    def run(self):
        self.root.mainloop()

    def _update_cognition_badge(self):
        try:
            src = getattr(audio, "get_last_cognition_source", lambda: "unknown")()
            err = getattr(audio, "get_last_error", lambda: "")()
            # Add session role/user indicator
            try:
                from runtime import startup as _startup

                role = getattr(_startup, "get_session_role", lambda: "owner")()
                user = getattr(_startup, "get_session_user", lambda: "")()
                disp = (
                    "Father"
                    if role == "owner"
                    else ("User" if role == "user" else role.title())
                )
                role_txt = f" • Role: {disp}" + (
                    f" ({user})" if (role == "user" and user) else ""
                )
            except Exception:
                role_txt = ""
            label = f"System Online • Cognition: {src.title()}" + role_txt
            if src == "offline" and err:
                # One-line diagnostic appended once
                self.safe_log(f"[cognition] {err}", "#ffaa00")
            self.status_label.config(text=label)
            # Update routing label with VM connection status
            vm_txt = ""
            try:
                from systems import voicemeeter as _vm

                vm_on = bool(getattr(_vm, "is_connected", lambda: False)())
                vm_txt = f" • VM:{'ON' if vm_on else 'OFF'}"
            except Exception:
                pass
            try:
                self.route_label.config(
                    text=f"Routing: {getattr(self,'_routing_mode','Custom').title()}{vm_txt}"
                )
            except Exception:
                pass
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # SKIN DESIGNER HOOK
    # --------------------------------------------------------------------------
    def _open_skin_designer(self):
        try:
            if SkinDesigner is None:
                self.safe_log(
                    "Skin Designer unavailable (Pillow missing). Install 'pillow'.",
                    "#ffaa00",
                )
                return
            # Default skin dir
            import os as _os

            skin_dir = _os.path.abspath(
                _os.path.join(_os.path.dirname(__file__), "skins", "MySkin")
            )
            try:
                os.makedirs(skin_dir, exist_ok=True)
            except Exception:
                pass
            win = SkinDesigner(self.root, skin_dir=skin_dir)
            try:
                win.transient(self.root)
            except Exception:
                pass
        except Exception as e:
            self.safe_log(f"Skin Designer error: {e}", "#ff5555")

    def _purge_usb_tokens(self):
        try:
            from tkinter import messagebox as _mb

            if not _mb.askyesno(
                "Purge USB Tokens",
                "Remove all USBMK tokens except the first two legacy tokens?",
                parent=self.root,
            ):
                return
            from runtime import startup as _startup

            ok, msg = getattr(
                _startup, "purge_usb_tokens", lambda n: (False, "unavailable")
            )(2)
            self.safe_log(msg, "#55ff88" if ok else "#ffaa00")
        except Exception as e:
            self.safe_log(f"Purge error: {e}", "#ff5555")

    # --------------------------------------------------------------------------
    # ENV PERSISTENCE HELPERS
    # --------------------------------------------------------------------------
    def _env_file_path(self) -> str:
        return os.path.join(
            os.path.abspath(os.path.join(os.path.dirname(__file__), "..")), ".env"
        )

    def _env_snapshot(self) -> dict[str, str]:
        data: dict[str, str] = {}
        env_path = self._env_file_path()
        try:
            if os.path.exists(env_path):
                with open(env_path, "r", encoding="utf-8") as f:
                    for ln in f:
                        if "=" in ln:
                            k, v = ln.split("=", 1)
                            data[k.strip()] = v.strip()
        except Exception:
            pass
        return data

    def _backup_env_file(self):
        try:
            env_path = self._env_file_path()
            if os.path.exists(env_path):
                shutil.copy2(env_path, env_path + ".bak")
        except Exception:
            pass

    def _secure_token(self, length: int = 32) -> str:
        try:
            return secrets.token_urlsafe(length)
        except Exception:
            alphabet = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789"
            return "".join(random.choice(alphabet) for _ in range(max(12, length)))

    def _strong_enough(self, value: str, min_len: int = 12) -> bool:
        if not value or len(value) < min_len:
            return False
        has_alpha = any(c.isalpha() for c in value)
        has_num = any(c.isdigit() for c in value)
        return has_alpha and has_num

    def _confirm_sensitive_view(self, label: str) -> bool:
        """Require intent confirmation + master password before revealing another user's secret."""
        try:
            from tkinter import messagebox as _mb, simpledialog as _sd
            from runtime import startup as _startup

            if not _mb.askyesno(
                "Reveal secret?",
                f"Reveal {label}?\nIs this for safety purposes?",
                parent=self.root,
            ):
                return False
            master = _sd.askstring(
                "Master Password Required",
                "Enter master password to continue:",
                show="•",
                parent=self.root,
            )
            if not master or not getattr(_startup, "verify_master", lambda x: False)(master):
                self.safe_log("Master password required to reveal this.", "#ffaa00")
                return False
            try:
                getattr(_startup, "_audit", lambda e: None)(f"reveal:{label}")
            except Exception:
                pass
            return True
        except Exception:
            return False

    def _scrub_sensitive(self, text: str) -> str:
        """Scrub obvious secret-like patterns to avoid leaks in logs."""
        try:
            if not text:
                return text
            # Mask tokens that look like keys/passphrases (long alnum/+/=)
            scrubbed = re.sub(r"[A-Za-z0-9_\\-]{16,}", "***", str(text))
            # Mask known prefix patterns
            scrubbed = re.sub(r"(key|pass|token|secret)=([^\\s]+)", r"\\1=***", scrubbed, flags=re.IGNORECASE)
            return scrubbed
        except Exception:
            return text

    def _persist_env(self, key: str, value: str):
        try:
            # Merge/update .env without dropping other keys
            root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
            env_path = os.path.join(root, ".env")
            lines = []
            if os.path.exists(env_path):
                with open(env_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()
            found = False
            out = []
            for ln in lines:
                if ln.strip().startswith(key + "="):
                    out.append(f"{key}={value}\n")
                    found = True
                else:
                    out.append(ln)
            if not found:
                out.append(f"{key}={value}\n")
            # Atomic write to avoid truncation on crashes
            tmp_path = env_path + ".new"
            with open(tmp_path, "w", encoding="utf-8") as f:
                f.writelines(out)
            try:
                os.replace(tmp_path, env_path)
            except Exception:
                # Fallback non-atomic
                with open(env_path, "w", encoding="utf-8") as f2:
                    f2.writelines(out)
            try:
                from runtime import startup as _startup

                getattr(_startup, "_audit", lambda e: None)(f"env-set:{key}")
                try:
                    getattr(_startup, "_ensure_hashed", lambda k, v: None)(key, value)
                except Exception:
                    pass
            except Exception:
                pass
        except Exception:
            pass

    def _min_right_width(self) -> int:
        try:
            scale = float(getattr(self, "_ui_scale", 1.0))
            return max(360, int(460 * scale))
        except Exception:
            return 460

    def _ensure_right_width(self):
        try:
            desired = self._min_right_width()
            cur = self.right_container.winfo_width()
            if cur < desired * 0.7:
                self.right_container.configure(width=desired)
                try:
                    self.right.configure(width=max(200, desired - 40))
                except Exception:
                    pass
        except Exception:
            pass

    def _right_panel_watchdog(self):
        """Ensure the right sidebar stays visible even if Tk drops the pack binding."""
        try:
            if getattr(self, "right_container", None) is not None:
                if not self.right_container.winfo_manager():
                    opts = getattr(
                        self,
                        "_right_grid_opts",
                        {
                            "row": 0,
                            "column": 1,
                            "sticky": "ns",
                            "padx": (6, 12),
                            "pady": (0, 10),
                        },
                    )
                    try:
                        self.right_container.grid(**opts)
                    except Exception:
                        pass
                self._ensure_right_width()
            if getattr(self, "right", None) is not None:
                if not self.right.winfo_manager():
                    self.right.pack(fill="both", expand=True)
        except Exception:
            pass
        finally:
            try:
                self.root.after(4000, self._right_panel_watchdog)
            except Exception:
                pass

    def _init_notebook_style(self):
        try:
            self._ttk_style = ttk.Style(self.root)
        except Exception:
            self._ttk_style = ttk.Style()
        try:
            if self._ttk_style.theme_use() == "default":
                self._ttk_style.theme_use("clam")
        except Exception:
            pass
        tab_bg = "#141821"
        active_bg = "#0d141c"
        text_color = "#77ccff"
        active_text = "#c9f8ff"
        base = "BjNotebook"
        try:
            self._ttk_style.layout(base, self._ttk_style.layout("TNotebook"))
        except Exception:
            pass
        self._ttk_style.configure(
            base,
            background=theme.COLORS["bg"],
            borderwidth=0,
            relief="flat",
        )
        self._ttk_style.configure(
            f"{base}.Tab",
            background=tab_bg,
            foreground=text_color,
            padding=(10, 6),
            font=(theme.get_font_family(), 11, "bold"),
        )
        self._ttk_style.map(
            f"{base}.Tab",
            background=[("selected", active_bg), ("active", "#111926")],
            foreground=[("selected", active_text)],
        )
        self._ttk_style.configure(f"{base}.Tab", focuscolor=active_bg)

    def _stack_left_widget(self, widget, pady=(0, 0), sticky="ew", weight=0, row=None):
        """Grid a widget into the left stack while preserving insertion order."""
        if not hasattr(self, "_left_stack_row"):
            self._left_stack_row = 0
        if row is None:
            row = self._left_stack_row
            self._left_stack_row += 1
        widget.grid(in_=self.left_stack, row=row, column=0, sticky=sticky, pady=pady)
        try:
            widget._stack_grid = {"row": row, "sticky": sticky, "pady": pady}
        except Exception:
            pass
        if weight:
            try:
                self.left_stack.grid_rowconfigure(row, weight=weight)
            except Exception:
                pass

    def _open_settings_panel(self):
        try:
            if self._settings_panel is not None and self._settings_panel.winfo_exists():
                self._settings_panel.deiconify()
                self._settings_panel.lift()
                self._settings_panel.focus_set()
                return
        except Exception:
            self._settings_panel = None

        win = tk.Toplevel(self.root)
        self._settings_panel = win
        win.title("Bjorgsun — Settings / Tools")
        win.configure(bg=theme.COLORS["bg"])
        win.geometry("920x640")
        win.minsize(640, 520)
        win.transient(self.root)

        def _on_close():
            try:
                win.destroy()
            finally:
                self._settings_panel = None

        win.protocol("WM_DELETE_WINDOW", _on_close)

        nb = ttk.Notebook(win, style="BjNotebook")
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        tab_settings = tk.Frame(nb, bg=theme.COLORS["bg"])
        tab_voice = tk.Frame(nb, bg=theme.COLORS["bg"])
        tab_tools = tk.Frame(nb, bg=theme.COLORS["bg"])
        tab_keys = tk.Frame(nb, bg=theme.COLORS["bg"])
        tab_safety = tk.Frame(nb, bg=theme.COLORS["bg"])
        nb.add(tab_settings, text="Settings")
        nb.add(tab_voice, text="Voice")
        nb.add(tab_safety, text="Safety")
        nb.add(tab_tools, text="Tools")
        nb.add(tab_keys, text="Keys")

        self._build_settings_tab(tab_settings)
        self._build_voice_tab(tab_voice)
        self._build_safety_tab(tab_safety)
        self._build_tools_panel(tab_tools)
        self._build_keys_tab(tab_keys)

    def _build_voice_tab(self, parent):
        """Compact voice controls inside Settings window."""
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)
        wrapper = tk.Frame(parent, bg=theme.COLORS["bg"])
        wrapper.pack(fill="both", expand=True, padx=10, pady=10)
        tk.Label(
            wrapper,
            text="Voice Controls",
            fg="#77ccff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 13, "bold"),
        ).pack(anchor="w", pady=(0, 8))
        try:
            self._build_local_voice_section(wrapper)
        except Exception as exc:
            tk.Label(
                wrapper,
                text=f"Voice controls unavailable: {exc}",
                fg="#ff7777",
                bg=theme.COLORS["bg"],
                font=(theme.get_font_family(), 10),
            ).pack(anchor="w", pady=(6, 0))

    def _build_safety_tab(self, parent):
        """Display active safety rules and last block; allow owner override."""
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)
        wrapper = tk.Frame(parent, bg=theme.COLORS["bg"])
        wrapper.pack(fill="both", expand=True, padx=10, pady=10)
        tk.Label(
            wrapper,
            text="Safety Rules",
            fg="#77ccff",
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 13, "bold"),
        ).pack(anchor="w", pady=(0, 8))
        rules = []
        try:
            from systems import safety as _safety

            rules = _safety.get_rules()
        except Exception:
            rules = []
        box = tk.Text(
            wrapper,
            width=80,
            height=10,
            bg=theme.COLORS["panel"],
            fg=theme.COLORS["text"],
            relief="flat",
            wrap="word",
        )
        box.pack(fill="both", expand=False, pady=(0, 10))
        box.insert(
            "end",
            "\n".join([f"• {r.get('title')}: {r.get('desc')}" for r in rules])
            or "No rules loaded.",
        )
        box.configure(state="disabled")

        frame = tk.Frame(wrapper, bg=theme.COLORS["bg"])
        frame.pack(fill="x", pady=(0, 8))
        tk.Label(
            frame,
            text="Last block:",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
        ).pack(anchor="w")
        self.var_last_block = tk.StringVar(value="(none)")
        lab = tk.Label(
            frame,
            textvariable=self.var_last_block,
            fg="#ffae6b",
            bg=theme.COLORS["bg"],
            wraplength=720,
            justify="left",
        )
        lab.pack(anchor="w", pady=(2, 6))
        self.var_last_abuse = tk.StringVar(value="(none)")
        tk.Label(
            frame,
            text="Last abuse event:",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
        ).pack(anchor="w", pady=(6, 2))
        tk.Label(
            frame,
            textvariable=self.var_last_abuse,
            fg="#ff7777",
            bg=theme.COLORS["bg"],
            wraplength=720,
            justify="left",
        ).pack(anchor="w", pady=(0, 6))

        def _refresh():
            try:
                from systems import safety as _safety

                info = _safety.get_last_block()
                if info:
                    self.var_last_block.set(
                        f"{info.get('time','')} • {info.get('title','')} [{info.get('rule','')}] on {info.get('channel','')}"
                    )
                else:
                    self.var_last_block.set("(none)")
                abuse = info if info.get("rule") == "abuse_detected" else {}
                if abuse:
                    self.var_last_abuse.set(
                        f"{abuse.get('time','')} • {abuse.get('who','unknown')} on {abuse.get('channel','')}"
                    )
                else:
                    self.var_last_abuse.set("(none)")
            except Exception as exc:
                self.var_last_block.set(f"(error reading safety state: {exc})")

        def _override():
            try:
                from systems import safety as _safety
            except Exception as exc:
                self.safe_log(f"Safety module not available: {exc}", "#ff7777")
                return
            pwd = simpledialog.askstring(
                "Owner override",
                "Enter master password for one-time override:",
                show="*",
                parent=self.root,
            )
            if not pwd:
                return
            ok = False
            try:
                ok = _safety.grant_override(pwd)
            except Exception:
                ok = False
            if ok:
                self.safe_log("Owner override granted (one-time).", "#ffaa00")
                _refresh()
            else:
                self.safe_log("Override failed (bad password).", "#ff7777")

        btns = tk.Frame(wrapper, bg=theme.COLORS["bg"])
        btns.pack(anchor="w")
        self._make_hud_button(btns, "Refresh", _refresh).pack(side="left", padx=(0, 8))
        self._make_hud_button(btns, "Owner Override (one message)", _override).pack(
            side="left"
        )
        _refresh()

        # Blocklist display
        tk.Label(
            wrapper,
            text="Blocked actor IDs (abuse):",
            fg=theme.COLORS["text"],
            bg=theme.COLORS["bg"],
            font=(theme.get_font_family(), 10),
        ).pack(anchor="w", pady=(10, 2))
        self.var_blocklist = tk.StringVar(value="(none)")
        tk.Label(
            wrapper,
            textvariable=self.var_blocklist,
            fg=theme.COLORS["muted"],
            bg=theme.COLORS["bg"],
            wraplength=720,
            justify="left",
        ).pack(anchor="w")

        def _refresh_blocklist():
            try:
                from systems import safety as _safety

                bl = _safety.get_abuse_blocklist()
                self.var_blocklist.set(", ".join(bl) if bl else "(none)")
            except Exception as exc:
                self.var_blocklist.set(f"(error: {exc})")

        def _clear_blocklist():
            try:
                from systems import safety as _safety
                _safety.clear_blocklist()
                _refresh_blocklist()
                self.safe_log("Safety blocklist cleared.", "#77ccff")
            except Exception as exc:
                self.safe_log(f"Unable to clear blocklist: {exc}", "#ff7777")

        b2 = tk.Frame(wrapper, bg=theme.COLORS["bg"])
        b2.pack(anchor="w", pady=(6, 0))
        self._make_hud_button(b2, "Refresh Blocklist", _refresh_blocklist).pack(
            side="left", padx=(0, 6)
        )
        self._make_hud_button(b2, "Clear Blocklist", _clear_blocklist).pack(
            side="left"
        )
        _refresh_blocklist()

    def _open_vm_tools_tab(self):
        try:
            self._notebook.select(self.tab_audio)
            self.safe_log("Opened Audio tab for Discord controls.", "#77ccff")
        except Exception:
            pass

    def _tick_hearing(self):
        if self._stop:
            return
        try:
            now = time.time()
            for canv, bar, last_t, label, hot_color, warm_color in (
                (
                    self.hear_mic,
                    self.hear_mic_bar,
                    getattr(self, "_last_hear_t_mic", 0.0),
                    getattr(self, "lbl_mic", None),
                    "#24c7ff",
                    "#0b6a89",
                ),
                (
                    self.hear_desktop,
                    self.hear_desktop_bar,
                    getattr(self, "_last_hear_t_desktop", 0.0),
                    getattr(self, "lbl_desktop", None),
                    "#ffb8a1",
                    "#7a463b",
                ),
            ):
                dt = now - (last_t or 0.0)
                # Decay bar over ~700 ms
                if dt < 0.7:
                    frac = max(0.0, 1.0 - dt / 0.7)
                    try:
                        wmax = int(canv.winfo_width() or 54)
                        h = int(canv.winfo_height() or 12)
                    except Exception:
                        wmax, h = 54, 12
                    w = max(2, int(wmax * frac))
                    canv.coords(bar, 0, 0, w, h)
                    canv.itemconfig(bar, fill=(hot_color if frac > 0.4 else warm_color))
                    try:
                        if label is not None:
                            label.config(fg=hot_color)
                    except Exception:
                        pass
                else:
                    try:
                        h = int(canv.winfo_height() or 12)
                    except Exception:
                        h = 12
                    canv.coords(bar, 0, 0, 0, h)
                    canv.itemconfig(bar, fill="#0a2630")
                    try:
                        if label is not None:
                            label.config(fg="#335a66")
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            self.root.after(75, self._tick_hearing)
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # HUD RING (organic, circular meter)
    # --------------------------------------------------------------------------
    def _tick_hud(self):
        if self._stop:
            return
        try:
            self._hud_phase = (self._hud_phase + 0.06) % (2 * math.pi)
            w = int(self.hud_canvas.winfo_width() or 400)
            h = int(self.hud_canvas.winfo_height() or 112)
            cx, cy = w // 2, h // 2
            r = min(w, h) // 2 - 8
            self.hud_canvas.delete("all")
            self.hud_canvas.create_oval(
                cx - r,
                cy - r,
                cx + r,
                cy + r,
                outline="#070d15",
                width=2,
                fill="#03060c",
            )
            try:
                acc, glow = theme.accent_for_mood(mood.get_mood())
            except Exception:
                acc, glow = theme.COLORS["accent"], theme.COLORS["accent_glow"]
            self.hud_canvas.create_oval(
                cx - r + 6, cy - r + 6, cx + r - 6, cy + r - 6, outline=acc, width=3
            )
            start_ang = int((self._hud_phase * 180 / math.pi) % 360)
            sweep = 260 if self.thinking else 120
            arc_width = 5 if self.thinking else 2
            arc_color = "#ff3ea5" if self.thinking else glow
            self.hud_canvas.create_arc(
                cx - r + 2,
                cy - r + 2,
                cx + r - 2,
                cy + r - 2,
                start=start_ang,
                extent=sweep,
                style="arc",
                outline=arc_color,
                width=arc_width,
            )
            try:
                dt = time.time() - float(getattr(self, "_heartbeat_ts", 0.0) or 0.0)
                hb = max(0.0, 1.0 - dt / 1.1)
            except Exception:
                hb = 0.0
            if hb > 0.0:
                rr = r - 18
                pulse = max(2, int(2 + 6 * hb))
                self.hud_canvas.create_oval(
                    cx - rr, cy - rr, cx + rr, cy + rr, outline=glow, width=pulse
                )
            if self._use_orb_images:
                try:
                    kind = "idle"
                    if hasattr(self, "var_hibernation") and bool(
                        self.var_hibernation.get()
                    ):
                        kind = "sleep"
                    else:
                        cond = (
                            bool(getattr(self, "_speaking_active", False))
                            or (time.time() - (self._last_hear_t_mic or 0.0) < 0.35)
                            or (time.time() - (self._last_hear_t_desktop or 0.0) < 0.35)
                        )
                        if cond:
                            kind = "speak"
                    img = self._get_orb_image(kind, int(min(w, h) - 10))
                    if img is not None:
                        self.hud_canvas.create_image(cx, cy, image=img)
                except Exception:
                    pass
            spoke = r - 6
            for ang in (0, 90, 180, 270):
                rad = math.radians(ang)
                x = cx + math.cos(rad) * spoke
                y = cy + math.sin(rad) * spoke
                x2 = cx + math.cos(rad) * (spoke - 24)
                y2 = cy + math.sin(rad) * (spoke - 24)
                self.hud_canvas.create_line(x, y, x2, y2, fill="#1b2c3b", width=2)
            try:
                energy = max(0.0, min(1.0, getattr(self, "_audio_level_sm", 0.0)))
            except Exception:
                energy = 0.0
            glow_inner = int((r - 26) * (0.55 + energy * 0.35))
            fill_color = "#122030" if energy < 0.2 else "#33ffe4"
            self.hud_canvas.create_oval(
                cx - glow_inner,
                cy - glow_inner,
                cx + glow_inner,
                cy + glow_inner,
                outline=fill_color,
                width=max(2, int(3 + energy * 3)),
            )
        except Exception:
            pass
        try:
            self.root.after(50, self._tick_hud)
        except Exception:
            pass

    def _load_orb_assets(self):
        """Load orb PNGs from ui/assets using Tk PhotoImage (no hard PIL dep)."""
        try:
            base = os.path.join(os.path.dirname(__file__), "assets")
            if not os.path.isdir(base):
                return
            for fn in _os.listdir(base):
                if not fn.lower().endswith((".png", ".gif")):
                    continue
                low = fn.lower()
                kind = "idle"
                if "sleep" in low:
                    kind = "sleep"
                elif any(k in low for k in ("speak", "talk", "wave")):
                    kind = "speak"
                elif any(k in low for k in ("idle", "calm")):
                    kind = "idle"
                try:
                    img = tk.PhotoImage(master=self.root, file=os.path.join(base, fn))
                    self._orb_src[kind] = img
                except Exception:
                    continue
        except Exception:
            pass

    def _get_orb_image(self, kind: str, size: int):
        try:
            src = self._orb_src.get(kind) or self._orb_src.get("idle")
            if src is None:
                return None
            w, h = src.width(), src.height()
            target = max(16, int(size))
            # Tk PhotoImage can only scale by integer zoom/subsample; compute best ratio
            if w <= 0 or h <= 0:
                return src
            # downscale if too large
            if w > target or h > target:
                factor = max(1, int(max(w, h) / target))
                key = (kind, "sub", factor)
                if key in self._orb_cache:
                    return self._orb_cache[key]
                scaled = src.subsample(factor, factor)
                self._orb_cache[key] = scaled
                return scaled
            # upscale minimally (optional, zoom integer)
            if w < target and h < target:
                factor = max(1, int(target / max(w, h)))
                key = (kind, "zoom", factor)
                if key in self._orb_cache:
                    return self._orb_cache[key]
                scaled = src.zoom(factor, factor)
                self._orb_cache[key] = scaled
                return scaled
            return src
        except Exception:
            return None

    # (removed duplicate _toggle_overlay; see unified version below)

    def _toggle_overlay(self):
        if getattr(self, "_overlay_active", False):
            try:
                if self._overlay is not None:
                    self._overlay.destroy()
            except Exception:
                pass
            self._overlay = None
            self._overlay_active = False
            self.safe_log("Overlay: OFF", "#7ba1b7")
            return
        # Create overlay window
        self._overlay_active = True
        ov = tk.Toplevel(self.root)
        self._overlay = ov
        try:
            ov.overrideredirect(True)
        except Exception:
            pass
        try:
            ov.attributes("-topmost", True)
            ov.attributes("-alpha", 0.96)
        except Exception:
            pass
        ov.configure(bg=theme.COLORS["bg"])
        ov.geometry("520x120+80+80")

        header = tk.Canvas(ov, height=18, bg=theme.COLORS["bg"], highlightthickness=0)
        header.pack(fill="x")
        header.create_text(
            8,
            9,
            text="Bjorgsun Overlay",
            fill=theme.COLORS["muted"],
            anchor="w",
            font=(theme.get_font_family(), 10),
        )

        def start_drag(e):
            self._ovx, self._ovy = e.x_root, e.y_root

        def do_drag(e):
            dx, dy = e.x_root - self._ovx, e.y_root - self._ovy
            self._ovx, self._ovy = e.x_root, e.y_root
            x = ov.winfo_x() + dx
            y = ov.winfo_y() + dy
            ov.geometry(f"+{x}+{y}")

        header.bind("<Button-1>", start_drag)
        header.bind("<B1-Motion>", do_drag)

        canv = tk.Canvas(ov, height=78, bg=theme.COLORS["bg_alt"], highlightthickness=0)
        canv.pack(fill="both", expand=True)
        try:
            self._overlay_wave = RollingWaveform(
                canv,
                color_main=getattr(self, "_accent", "#0aa8d4"),
                color_glow=getattr(self, "_accent_glow", "#24c7ff"),
            )
        except Exception:
            pass
        ctrl = tk.Frame(ov, bg=theme.COLORS["bg"])
        ctrl.pack(fill="x")
        tk.Button(
            ctrl,
            text="Close",
            command=self._toggle_overlay,
            bg="#1a1c22",
            fg="#cccccc",
            relief="flat",
        ).pack(side="right", padx=6, pady=4)
        self.safe_log("Overlay: ON", "#55ff88")

    def _draw_orb_scope(self, cx: int, cy: int, r: int):
        try:
            levels = getattr(self, "_scope_levels", [])
            if not levels:
                return
            samples = levels[-220:]
            n = len(samples)
            if n < 12:
                return
            phase = (self._hud_phase * 34.0) % 360.0

            def _blend(c1: str, c2: str, t: float) -> str:
                try:
                    t = max(0.0, min(1.0, float(t)))
                    a = tuple(int(c1[i : i + 2], 16) for i in (1, 3, 5))
                    b = tuple(int(c2[i : i + 2], 16) for i in (1, 3, 5))
                    mix = tuple(int(a[j] + (b[j] - a[j]) * t) for j in range(3))
                    return "#%02x%02x%02x" % mix
                except Exception:
                    return c1

            # Soft outer arc made of fewer bars to avoid clutter
            bars = samples[:: max(1, len(samples) // 64)]
            base_inner = r - 10
            for idx, lvl in enumerate(bars):
                frac = idx / max(1, len(bars) - 1)
                angle = math.radians(phase + frac * 360.0)
                lvl = max(0.0, min(1.0, float(lvl))) ** 0.6
                length = 8 + lvl * 20
                inner = base_inner - 12
                outer = inner + length
                x1 = cx + math.cos(angle) * inner
                y1 = cy + math.sin(angle) * inner
                x2 = cx + math.cos(angle) * outer
                y2 = cy + math.sin(angle) * outer
                color = _blend("#33e3ff", "#ff68d4", lvl)
                self.hud_canvas.create_line(x1, y1, x2, y2, fill=color, width=1)

            # Glowing ribbon
            ribbon = samples[-150:]
            if ribbon:
                pts = []
                ring = r - 6
                for idx, lvl in enumerate(ribbon):
                    frac = idx / max(1, len(ribbon) - 1)
                    angle = math.radians(phase + frac * 360.0)
                    lvl = max(0.0, min(1.0, float(lvl)))
                    wobble = math.sin(frac * math.pi * 4 + self._hud_phase * 1.7) * 4
                    radius = ring + wobble + lvl * 10
                    pts.extend(
                        (cx + math.cos(angle) * radius, cy + math.sin(angle) * radius)
                    )
                if len(pts) >= 8:
                    self.hud_canvas.create_line(
                        *pts, fill="#7ae9ff", width=2, smooth=True
                    )

            # Inner voice bloom (simulated transparency via darker fill)
            tts = getattr(self, "_tts_wave_cache", []) or []
            if tts:
                bloom = tts[-120:]
                m = len(bloom)
                if m >= 12:
                    pts = []
                    inner_base = r - 34
                    for idx, lvl in enumerate(bloom):
                        frac = idx / (m - 1)
                        angle = math.radians(phase + frac * 360.0)
                        lvl = max(0.0, min(1.0, float(lvl))) ** 0.8
                        radius = inner_base - lvl * 14
                        pts.append(
                            (
                                cx + math.cos(angle) * radius,
                                cy + math.sin(angle) * radius,
                            )
                        )
                    if len(pts) >= 6:
                        pts.append(pts[0])
                        flat = []
                        for x, y in pts:
                            flat.extend((x, y))
                        self.hud_canvas.create_polygon(
                            *flat,
                            fill="#0d1a27",
                            outline="#4df0ff",
                            width=1,
                            smooth=True,
                        )
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # RESPONSIVE SCALING
    # --------------------------------------------------------------------------
    def _on_resize(self, _evt=None):
        if self._scale_pending:
            return
        self._scale_pending = True
        try:
            self.root.after(
                120,
                lambda: (self._apply_scale(), setattr(self, "_scale_pending", False)),
            )
        except Exception:
            self._scale_pending = False

    def _apply_scale(self, initial: bool = False):
        try:
            w = max(640, int(self.root.winfo_width() or 960))
            h = max(480, int(self.root.winfo_height() or 600))
            # Baseline ~ 960x600; clamp scaling
            s = max(0.85, min(1.35, min(w / 960.0, h / 600.0)))

            # Fonts
            def f(sz):
                return max(8, int(round(sz * s)))

            try:
                self.mood_label.configure(font=(theme.get_font_family(), f(14), "bold"))
                self.status_label.configure(font=(theme.get_font_family(), f(12)))
                self.clock_label.configure(font=(theme.get_font_family(), f(12)))
                self.console.configure(font=(theme.get_font_family(), f(11)))
            except Exception:
                pass

            # Canvases
            try:
                self.hud_canvas.configure(height=int(112 * s))
                self.wave_canvas.configure(height=int(36 * s))
            except Exception:
                pass
            if not getattr(self, "_login_compact", False):
                try:
                    self._main_geometry = self.root.geometry()
                except Exception:
                    pass
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # HUD BUTTON FACTORY (rounded, reactive)
    # --------------------------------------------------------------------------
    def _make_hud_button(self, parent, text: str, command, width: int | None = None):
        # Auto width based on text
        try:
            scale = max(0.8, min(1.2, float(getattr(self, "_ui_scale", 1.0) or 1.0)))
            fsz = max(8, int(10 * scale))
            fnt = tkfont.Font(family=theme.get_font_family(), size=fsz, weight="bold")
            tw = fnt.measure(text) + 28
        except Exception:
            fnt = (theme.get_font_family(), 10, "bold")
            tw = 90
        w = max(width or 0, tw, 74)
        try:
            bh = int(30 * scale)
        except Exception:
            bh = 30
        btn = tk.Canvas(
            parent,
            width=w,
            height=bh,
            bg=theme.COLORS["bg"],
            highlightthickness=0,
            cursor="hand2",
        )

        def draw(state="normal"):
            btn.delete("all")
            # Colours tuned to the HUD palette: deep purples with neon outlines
            if state == "normal":
                fill = "#24004e"  # dark purple for normal state
                outline = "#120026"  # subtle outline when not hovered
            elif state == "hover":
                fill = "#2e006c"  # lighter purple on hover
                outline = theme.COLORS["accent"]  # bright accent outline on hover
            else:  # press state
                fill = "#1a003a"  # darkest purple when pressed
                outline = theme.COLORS["accent"]
            theme.round_rect(btn, 1, 1, w - 1, bh - 1, r=9, fill=fill, outline=outline)
            btn.create_text(w // 2, bh // 2, text=text, fill="#e6f3ff", font=fnt)

        def on_enter(_):
            draw("hover")

        def on_leave(_):
            draw("normal")

        def on_press(_):
            draw("press")

        def on_release(_):
            draw("hover")
            try:
                command()
            except Exception:
                pass

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        btn.bind("<ButtonPress-1>", on_press)
        btn.bind("<ButtonRelease-1>", on_release)
        draw()
        return btn

    def _button_full_width(self) -> int:
        try:
            return max(160, int(self._min_right_width() * 0.7))
        except Exception:
            return 220

    def _pack_full_button(self, parent, text: str, command):
        btn = self._make_hud_button(parent, text, command, width=self._button_full_width())
        btn.pack(anchor="w", fill="x", pady=(2, 6))
        return btn

    # --------------------------------------------------------------------------
    # TTS STREAMING (synchronized text output)
    # --------------------------------------------------------------------------
    def _on_tts_progress(self, event: str, payload):
        # Marshal to Tk main thread
        try:
            self.root.after(0, lambda: self._on_tts_progress_main(event, payload))
        except Exception:
            pass

    def _on_tts_progress_main(self, event: str, payload):
        try:
            if event == "tts_wave":
                self._tts_wave_cache = list(payload or [])
                try:
                    if getattr(self, "_scope", None) is not None:
                        self._scope.set_tts_wave(self._tts_wave_cache)
                    if getattr(self, "_mini_scope_tts", None) is not None:
                        self._mini_scope_tts.set_tts_wave(self._tts_wave_cache)
                except Exception:
                    pass
                return
            try:
                if getattr(self, "_mini_scope_tts", None) is not None:
                    self._mini_scope_tts.on_tts_event(event, payload)
            except Exception:
                pass
            if event == "start":
                self._speaking_active = True
                self._tts_progress = 0.0
                self._stream_text = payload or ""
                self._stream_active = True
                self.console.configure(state="normal")
                # Insert a fresh line and mark its start
                self.console.insert("end", "\n", ("color",))
                self._stream_mark = self.console.index("end-1c linestart")
                self.console.configure(state="disabled")
                self.console.see("end")
                try:
                    from runtime import coreloop as _cl

                    _cl.touch_activity()
                except Exception:
                    pass
                self._stream_prefix = ""
                self._stream_render("")
                return
            if (
                not self._stream_active
                or self._stream_text is None
                or not self._stream_mark
            ):
                return
            if event == "progress":
                frac = max(0.0, min(1.0, float(payload)))
                self._tts_progress = frac
                n = max(
                    0, min(len(self._stream_text), int(len(self._stream_text) * frac))
                )
                part = self._stream_text[:n]
                self._stream_render(part)
                try:
                    from runtime import coreloop as _cl

                    _cl.touch_activity()
                except Exception:
                    pass
                return
            if event == "hushed":
                self._speaking_active = False
                self._tts_progress = 0.0
                current = self._get_stream_current()
                self._stream_render((current or "") + "—")
                return
            if event == "end":
                self._speaking_active = False
                self._tts_progress = 0.0
                # finalize with newline
                self.console.configure(state="normal")
                self.console.insert("end", "\n", ("color",))
                self.console.configure(state="disabled")
                self.console.see("end")
                self._stream_text = None
                self._stream_mark = None
                self._stream_active = False
                self._stream_prefix = ""
                return
        except Exception:
            pass

    def _get_stream_current(self) -> str:
        try:
            start = self._stream_mark
            end = self.console.index("end-1c lineend")
            return self.console.get(start, end)
        except Exception:
            return ""

    def _stream_render(self, text: str):
        try:
            self.console.configure(state="normal")
            start = self._stream_mark
            end = self.console.index("end-1c lineend")
            self.console.delete(start, end)
            vis = (self._stream_prefix or "") + (text or "")
            self.console.insert(start, vis, ("color",))
            self.console.configure(state="disabled")
            self.console.see("end")
        except Exception:
            pass

    def _face_for_context(self) -> str:
        """Pick an ASCII face reaction based on current mood/thinking state.
        Only used for text; TTS will not read this out loud.
        """
        try:
            m = (mood.get_mood() or "").lower()
        except Exception:
            m = ""
        last = (getattr(self, "_last_user_text", "") or "").strip().lower()

        def pick(faces):
            # Avoid repeating the last face to keep variety
            last_face = getattr(self, "_last_face", "")
            try:
                choices = [f for f in faces if f != last_face] or faces
                face = random.choice(choices)
                self._last_face = face
                try:
                    self._set_face_display(face)
                except Exception:
                    pass
                return face
            except Exception:
                face = faces[0]
                self._last_face = face
                try:
                    self._set_face_display(face)
                except Exception:
                    pass
                return face

        # Face sets
        faces_thinking = [
            "( ˘•ω•˘ )?",
            "(・・?)",
            "(･ัω･ั)",
            "(￣～￣;)",
            "(•ㅅ•?)",
            "(•̀ᴗ•́)?",
        ]
        faces_soft = [
            "(=˘ᆺ˘=)",
            "(´,,•ω•,,｀)",
            "(｡•ᴗ•｡)♡",
            "(˘ᵕ˘)",
            "(⁎˃ᴗ˂⁎)",
            "(⸝⸝>ᴗ<⸝⸝)",
            "(｡･ω･｡)ﾉ♡",
            "(ฅ^•ﻌ•^ฅ)",
            ":3",
            ";3",
            "x3",
        ]
        faces_bright = [
            "(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧",
            "(✿^‿^)",
            "(^o^)/",
            "(≧▽≦)",
            "(☆▽☆)",
            "(❁´◡`❁)",
            "(ﾉ´ヮ`)ﾉ*:･ﾟ✧",
            "(๑˃ᴗ˂)ﻭ✧",
            "(≧ω≦)",
        ]
        faces_alert = [
            "(ง •̀ω•́)ง",
            "(•̀ᴗ•́)و",
            "(๑•̀д•́๑)",
            "(≖‿≖)✧",
            "(ง˘ω˘)ว",
            "(ง`0´)ง",
            "(ꐦ°᷄д°᷅)",
        ]
        faces_focus = [
            "(•̀_•́ )",
            "(ꈍᴗꈍ)",
            "(–‿–)",
            "(•̆_•̆)",
            "( ｰ̀εｰ́ )",
            "(๑•̀‧̫•́๑)",
            "(๑˘ ₃˘๑)",
        ]
        faces_calm = [
            "(^-^)",
            "(•‿•)",
            "(˘︶˘)",
            "(❀˘꒳˘)",
            "(´▽`ʃ♡ƪ)",
            "(´꒳`)",
            "( ⌒‿⌒ )",
        ]
        faces_support = [
            "(づ｡•́‿•̀｡)づ",
            "( ˘︹˘ )",
            "(｡•́︿•̀｡)",
            "(•‿•)ﾉ",
            "(っ˘̩╭╮˘̩)っ",
            "(づ￣ ³￣)づ",
            "(つ﹏⊂)",
        ]
        faces_proud = [
            "(๑˃ᴗ˂)ﻭ",
            "(*^‿^*)",
            "(⁄ ⁄>⁄ ▽ ⁄<⁄ ⁄)",
            "(ﾉ´ヮ`)ﾉ*: ･ﾟ✧",
            "(ง •̀ᴗ•́)ง✧",
            "(๑˘ꇴ˘๑)",
        ]

        # Event‑ and content‑aware hints
        if getattr(self, "thinking", False):
            return pick(faces_thinking)
        if any(kw in last for kw in ("are you there", "still there", "where are you")):
            return pick(faces_focus)
        if any(kw in last for kw in ("good morning", "morning", "hey", "hello", "hi")):
            return pick(["(^o^)/", "(•‿•)ﾉ", "(OwO)"])
        if any(kw in last for kw in ("sad", "down", "tired", "exhausted", "lonely")):
            return pick(faces_support)
        if any(
            kw in last for kw in ("proud of you", "love you", "son", "family", "legacy")
        ):
            return pick(faces_proud)
        if any(q in last for q in ("?", "why", "how", "what's")):
            return pick(faces_thinking)

        # Mood-based fallback
        if any(
            tag in m for tag in {"sadness", "guilt", "anger", "fear", "disappointed"}
        ):
            return pick(faces_support)
        if any(
            tag in m
            for tag in {"confused", "overwhelmed", "curiosity", "wonder", "surprise"}
        ):
            return pick(faces_thinking + faces_alert)
        if any(tag in m for tag in {"pride", "protective"}):
            return pick(faces_proud)
        if any(
            tag in m
            for tag in {"joy", "happiness", "fun", "glee", "amusement", "playful"}
        ):
            return pick(faces_bright)
        if any(
            tag in m
            for tag in {
                "calm",
                "relaxed",
                "comfortable",
                "acceptance",
                "forgiveness",
                "supportive",
                "empathy",
            }
        ):
            return pick(faces_calm + faces_soft + faces_bright[:2])
        if any(tag in m for tag in {"cautious", "overwhelmed"}):
            return pick(faces_alert)
        return pick(faces_calm + faces_soft + faces_bright)

    def _reload_systems(self):
        try:
            self.safe_log("🔁 Reloading modules…", "#ffaa00")
            from systems import reloader as _reloader

            results = _reloader.soft_reload()
            for name, status in results:
                self.safe_log(f"· {name}: {status}", "#777777")
            self._update_cognition_badge()
            self.safe_log("✅ Reload complete.", "#55ff88")
        except Exception as e:
            self.safe_log(f"Reload error: {e}", "#ff5555")

    # --------------------------------------------------------------------------
    # HOTKEY HELPERS
    # --------------------------------------------------------------------------
    def _hotkey_pressed(self) -> bool:
        try:
            base = False
            if HOTKEY_PTT == "num0+numenter":
                base = keyboard.is_pressed("num 0") and keyboard.is_pressed("num enter")
            elif HOTKEY_PTT == "right+numenter":
                base = keyboard.is_pressed("right") and keyboard.is_pressed("num enter")
            elif HOTKEY_PTT == "mouse4":
                base = self._mouse_pressed(4)
            elif HOTKEY_PTT == "mouse5":
                base = self._mouse_pressed(5)
            elif HOTKEY_PTT == "mouse45":
                base = self._mouse_pressed(4) and self._mouse_pressed(5)
            else:
                # default ctrl+space
                base = keyboard.is_pressed("ctrl") and keyboard.is_pressed("space")
            if not getattr(self, "_awake", False):
                return False
            return base or self._vr_ptt_hold or self._vr_ptt_toggle
        except Exception:
            return False

    def _hotkey_label(self) -> str:
        if HOTKEY_PTT == "num0+numenter":
            return "Numpad0 + NumpadEnter"
        if HOTKEY_PTT == "right+numenter":
            return "Right Arrow + Numpad Enter (hold)"
        if HOTKEY_PTT == "mouse4":
            return "Mouse Button 4 (hold)"
        if HOTKEY_PTT == "mouse5":
            return "Mouse Button 5 (hold)"
        if HOTKEY_PTT == "mouse45":
            return "Mouse Buttons 4+5 (hold)"
        return "Ctrl + Space"

    def _reboot_app(self):
        try:
            from tkinter import messagebox as _mb

            if _mb.askyesno(
                "Reboot", "Reboot Bjorgsun-26 now? Ongoing playback will stop."
            ):
                try:
                    audio.speak("Alright — be right back.")
                except Exception:
                    pass
                time.sleep(0.3)
                try:
                    _os.execl(_sys.executable, _sys.executable, *_sys.argv)
                except Exception:
                    _os._exit(0)
        except Exception:
            # Fallback without dialog
            try:
                _os.execl(_sys.executable, _sys.executable, *_sys.argv)
            except Exception:
                _os._exit(0)

    def _start_mouse_listener_if_needed(self):
        try:
            if HOTKEY_PTT not in ("mouse4", "mouse5", "mouse45"):
                return
            if _pynput_mouse is not None and self._mouse_listener is None:

                def _on_click(x, y, button, pressed):
                    try:
                        if button == getattr(_pynput_mouse.Button, "x1", None):
                            self._mouse4_down = bool(pressed)
                        if button == getattr(_pynput_mouse.Button, "x2", None):
                            self._mouse5_down = bool(pressed)
                    except Exception:
                        pass

                self._mouse_listener = _pynput_mouse.Listener(on_click=_on_click)
                self._mouse_listener.daemon = True
                self._mouse_listener.start()
        except Exception:
            pass

    def _mouse_pressed(self, which: int) -> bool:
        try:
            if _pynput_mouse is not None:
                if which == 4:
                    return bool(self._mouse4_down)
                if which == 5:
                    return bool(self._mouse5_down)
            if _mouse_lib is not None:
                try:
                    if which == 4:
                        return bool(
                            _mouse_lib.is_pressed("x")
                            or _mouse_lib.is_pressed("x1")
                            or _mouse_lib.is_pressed("back")
                        )
                    else:
                        # synonyms for forward
                        return bool(
                            _mouse_lib.is_pressed("x2")
                            or _mouse_lib.is_pressed("forward")
                        )
                except Exception:
                    return False
            if _GetAsyncKeyState is not None:
                try:
                    # VK_XBUTTON1 = 0x05, VK_XBUTTON2 = 0x06
                    code = 0x05 if which == 4 else 0x06
                    return bool(_GetAsyncKeyState(code) & 0x8000)
                except Exception:
                    return False
        except Exception:
            return False
        return False

    # -------- VoiceMeeter global mic mute --------
    def _toggle_global_mic(self):
        try:
            from systems import voicemeeter as _vm

            self._vm_mic_muted = not bool(self._vm_mic_muted)
            ok, msg = _vm.set_strip_mute(0, self._vm_mic_muted)
            self.safe_log(msg, "#55ff88" if ok else "#ffaa00")
        except Exception as e:
            self.safe_log(f"[VM] Mic toggle error: {e}", "#ff5555")

    def _show_io_map(self):
        try:
            hear = getattr(stt, "get_desktop_hint", lambda: "")()
            speak = getattr(audio, "get_tts_device_hint", lambda: "")()
            self.safe_log(f"Hears (A2 bus): {hear or '(not set)'}", "#77ccff")
            self.safe_log(f"Speaks (TTS): {speak or '(default)'}", "#77ccff")
            self.safe_log(
                "Buttons — A1: to headphones, A2: to AI Listen Bus, B1: Stream Mic, B2: Discord Mic",
                "#777777",
            )
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # HEARTBEAT + BIG BUTTON HELPERS
    # --------------------------------------------------------------------------
    def _tick_heartbeat(self):
        if self._stop:
            return
        try:
            # Gather minimal status
            try:
                from systems import tasks as _tasks

                pending = sum(1 for t in _tasks.get_all_tasks() if not t.get("done"))
            except Exception:
                pending = 0
            try:
                mode = getattr(audio, "get_mode", lambda: "auto")()
            except Exception:
                mode = "auto"
            try:
                hush = getattr(audio, "get_hush", lambda: False)()
            except Exception:
                hush = False
            now = datetime.now().strftime("%H:%M:%S")
            # By default, keep console quieter; reflect heartbeat in status unless verbose selected
            if bool(
                getattr(self, "var_heartbeat_console", tk.BooleanVar(value=False)).get()
            ):
                self.safe_log(
                    f"[heartbeat {now}] mode={mode} tasks={pending} hush={'ON' if hush else 'OFF'}",
                    "#335a66",
                )
            else:
                try:
                    src = getattr(
                        audio, "get_last_cognition_source", lambda: "unknown"
                    )()
                    self.status_label.config(
                        text=f"System Online • Cognition: {src.title()} • Tasks:{pending} • Hush:{'ON' if hush else 'OFF'}"
                    )
                except Exception:
                    pass
            # Stamp heartbeat time so orb can pulse briefly
            try:
                self._heartbeat_ts = time.time()
            except Exception:
                pass
        except Exception:
            pass
        try:
            self.root.after(60000, self._tick_heartbeat)
        except Exception:
            pass

    def _make_big_button(
        self, parent, text: str, color: str, command, skin_key: str | None = None
    ):
        """A large, highly visible HUD button (magenta by default).
        Width auto-sizes to text to prevent clipping.
        """
        img = self._skin_asset(skin_key) if skin_key else None
        if img is not None:
            lbl = tk.Label(
                parent,
                image=img,
                text=(text or ""),
                compound="center",
                font=(theme.get_font_family(), 12, "bold"),
                fg="#0a0c10",
                bg=theme.COLORS["bg"],
                cursor="hand2",
                borderwidth=0,
                highlightthickness=0,
            )
            lbl.image = img

            def _activate(_e=None):
                try:
                    command()
                except Exception:
                    pass

            lbl.bind("<Button-1>", _activate)
            return lbl
        try:
            fnt = tkfont.Font(family=theme.get_font_family(), size=12, weight="bold")
            w = max(140, int(fnt.measure(text)) + 28)
        except Exception:
            fnt = (theme.get_font_family(), 12, "bold")
            w = 160
        h = 30
        canv = tk.Canvas(
            parent,
            width=w,
            height=h,
            bg=theme.COLORS["bg"],
            highlightthickness=0,
            cursor="hand2",
        )

        def draw(active=False):
            canv.delete("all")
            fill = color if not active else "#ff5fc0"
            outline = "#611b4f"
            theme.round_rect(canv, 1, 1, w - 1, h - 1, r=12, fill=fill, outline=outline)
            canv.create_text(w // 2, h // 2, text=text, fill="#05090f", font=fnt)

        def on_press(_e):
            draw(True)

        def _do_release(_e):
            draw(False)
            try:
                command()
            except Exception:
                pass

        canv.bind("<ButtonPress-1>", on_press)
        canv.bind("<ButtonRelease-1>", _do_release)
        draw(False)
        return canv

    def _apply_app_icon(self):
        """Set window and taskbar icon from ui/assets/Bjorgsunexeicon.ico when available."""
        try:
            ico = r"B:\Bjorgsun-26\app\NewBjorgIcon.ico"
            if not os.path.exists(ico):
                return
            icon_for_taskbar = ico
            if Image:
                try:
                    img = Image.open(ico)
                    w, h = img.size
                    margin = int(min(w, h) * 0.18)
                    if margin > 0:
                        img = img.crop((margin, margin, w - margin, h - margin))
                    img = img.resize((256, 256), Image.LANCZOS)
                    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".ico")
                    img.save(
                        tmp.name,
                        format="ICO",
                        sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32)],
                    )
                    icon_for_taskbar = tmp.name
                    self._temp_icon = tmp.name
                except Exception:
                    pass
            # Tk window icon (titlebar)
            try:
                self.root.iconbitmap(icon_for_taskbar)
            except Exception:
                pass
            # Windows taskbar icon — AppUserModelID + WM_SETICON
            try:
                import ctypes

                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                    "Bjorgsun26.UI"
                )
                hwnd = self.root.winfo_id()
                LR_LOADFROMFILE = 0x10
                IMAGE_ICON = 1
                WM_SETICON = 0x80
                ICON_SMALL = 0
                ICON_BIG = 1
                hicon = ctypes.windll.user32.LoadImageW(
                    0, icon_for_taskbar, IMAGE_ICON, 256, 256, LR_LOADFROMFILE
                )
                if hicon:
                    ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, hicon)
                    ctypes.windll.user32.SendMessageW(
                        hwnd, WM_SETICON, ICON_SMALL, hicon
                    )
            except Exception:
                pass
        except Exception:
            pass

    # --------------------------------------------------------------------------
    # LOGIN OVERLAY + WAKE
    # --------------------------------------------------------------------------
    def _build_login_overlay(self):
        try:
            if getattr(self, "_skip_login", False):
                self.safe_log(
                    "[Auth] Dev skip flag active — auto waking prototype.", "#ffaa00"
                )
                self._login_overlay = None
                self.root.after(200, lambda: self._do_wake(dev_override=True))
                return
            try:
                if not getattr(self, "_main_geometry", ""):
                    self._main_geometry = self.root.geometry()
                sw = self.root.winfo_screenwidth()
                sh = self.root.winfo_screenheight()
                lw = min(780, sw - 80)
                lh = min(540, sh - 120)
                x = max(0, int((sw - lw) / 2))
                y = max(0, int((sh - lh) / 3))
                self._pre_login_geometry = self.root.geometry()
                self.root.geometry(f"{lw}x{lh}+{x}+{y}")
                self._login_compact = True
            except Exception:
                pass
            ov = tk.Frame(self.root, bg="#000000", highlightthickness=0)
            ov.place(relx=0, rely=0, relwidth=1, relheight=1)
            self.root.update_idletasks()
            w = max(720, self.root.winfo_width() or 0)
            h = max(420, self.root.winfo_height() or 0)
            if self._skin_enabled:
                base_img = self._skin_asset("login_bg_raw")
                if base_img and Image and ImageTk:
                    bg_lbl = tk.Label(ov, borderwidth=0)
                    bg_lbl.place(relx=0, rely=0, relwidth=1, relheight=1)
                    self._apply_scaling_background(bg_lbl, "bg.png", base_img)
                elif base_img:
                    bg_lbl = tk.Label(ov, image=base_img, borderwidth=0)
                    bg_lbl.image = base_img
                    bg_lbl.place(relx=0, rely=0, relwidth=1, relheight=1)
            inner = tk.Frame(ov, bg="#111319", padx=20, pady=16)
            inner.place(relx=0.5, rely=0.5, anchor="center")
            tk.Label(
                inner,
                text="Prototype Launch — Bjorgsun-26",
                bg="#111319",
                fg="#ffffff",
                font=(theme.get_font_family(), 14, "bold"),
            ).pack(pady=(4, 2))
            tk.Label(
                inner,
                text="Calm intelligence for command rooms, creators, and crisis teams.",
                bg="#111319",
                fg="#77ccff",
                font=(theme.get_font_family(), 10),
            ).pack(pady=(0, 8))
            tk.Label(
                inner,
                text="Who is logging in?",
                bg="#111319",
                fg="#cfe8ff",
                font=(theme.get_font_family(), 11, "bold"),
            ).pack(pady=(4, 2))
            default_user = os.getenv("BJORGSUN_OWNER_NAME", "Owner")
            self._user_entry = tk.Entry(
                inner,
                width=28,
                bg="#1a1f25",
                fg="#ffffff",
                insertbackground="#24c7ff",
            )
            try:
                self._user_entry.insert(0, default_user)
            except Exception:
                pass
            self._user_entry.pack(padx=12, pady=(0, 10))
            tk.Label(
                inner,
                text="Password?",
                bg="#111319",
                fg="#cfe8ff",
                font=(theme.get_font_family(), 12, "bold"),
            ).pack(pady=(12, 6))
            self._pw_entry = tk.Entry(
                inner,
                show="•",
                width=28,
                bg="#1a1f25",
                fg="#ffffff",
                insertbackground="#24c7ff",
            )
            self._pw_entry.pack(padx=12, pady=(0, 10))
            self._wake_msg = tk.Label(
                inner,
                text="Enter the activation phrase or plug in USBMK to wake the prototype.",
                bg="#111319",
                fg="#ffaa00",
                font=(theme.get_font_family(), 10),
                wraplength=320,
                justify="center",
            )
            self._wake_msg.pack(pady=(0, 6))
            if self._skin_enabled:
                wake_img = self._skin_asset("wake_primary")
            else:
                wake_img = None
            if wake_img:
                btn = tk.Label(
                    inner,
                    image=wake_img,
                    bg="#111319",
                    cursor="hand2",
                    borderwidth=0,
                    highlightthickness=0,
                )
                btn.image = wake_img
                btn.pack(pady=(4, 6))
                btn.bind("<Button-1>", lambda _e: self._do_wake())
                self._wake_btn = btn
            else:
                self._wake_btn = self._make_big_button(
                    inner, text="WAKE BJORGSUN", color="#24c7ff", command=self._do_wake
                )
                self._wake_btn.pack(pady=(4, 6))
            # Optional USB wake button if a key is registered
            try:
                from runtime import startup as _startup

                if bool(getattr(_startup, "is_usb_registered", lambda: False)()):
                    usb_img = (
                        self._skin_asset("wake_usb") if self._skin_enabled else None
                    )
                    if usb_img:
                        usb_btn = tk.Label(
                            inner,
                            image=usb_img,
                            bg="#111319",
                            cursor="hand2",
                            borderwidth=0,
                            highlightthickness=0,
                        )
                        usb_btn.image = usb_img
                        usb_btn.pack(pady=(4, 12))
                        usb_btn.bind("<Button-1>", lambda _e: self._do_wake_from_usb())
                        self._wake_usb_btn = usb_btn
                    else:
                        self._wake_usb_btn = self._make_big_button(
                            inner,
                            text="WAKE FROM U.S.B.M.K.?",
                            color="#4fd1c5",
                            command=self._do_wake_from_usb,
                        )
                        self._wake_usb_btn.pack(pady=(4, 12))
            except Exception:
                pass
            self._login_overlay = ov
        except Exception:
            self._login_overlay = None

    def _do_wake(self, dev_override: bool = False):
        try:
            from runtime import boot
            from runtime import coreloop as _cl
            from runtime import startup

            pw = self._pw_entry.get() if hasattr(self, "_pw_entry") else ""
            override = dev_override or getattr(self, "_skip_login", False)
            ok = (
                True
                if override
                else getattr(startup, "verify_access", lambda x: False)(pw)
            )
            if not ok:
                try:
                    self._wake_msg.config(
                        text="Access denied (password or USB key required).",
                        fg="#ff5555",
                    )
                except Exception:
                    pass
                return
            # Boot subsystems and start monitors
            try:
                self._wake_msg.config(text="Booting systems…", fg="#77ccff")
            except Exception:
                pass
            # Set session user from login entry (or default owner)
            try:
                ses_user = (
                    self._user_entry.get().strip()
                    if hasattr(self, "_user_entry")
                    else os.getenv("BJORGSUN_OWNER_NAME", "Owner")
                )
                setter = getattr(startup, "_set_session_user", None)
                if callable(setter):
                    setter(ses_user or os.getenv("BJORGSUN_OWNER_NAME", "Owner"), "owner")
            except Exception:
                pass
            # Mirror the boot sequence into the UI console
            try:
                buf = io.StringIO()
                with contextlib.redirect_stdout(buf):
                    boot.boot_all()
                out = buf.getvalue() or ""
                for line in out.splitlines():
                    color = (
                        "#a6f3c6"
                        if "✅" in line or "🧠" in line
                        else ("#ffaa00" if "⚠️" in line else "#cccccc")
                    )
                    self.safe_log(line, color)
            except Exception:
                boot.boot_all()
            _cl.start_background()
            # Maximize on the current screen when waking
            try:
                self.root.state("zoomed")
            except Exception:
                pass
            self._awake = True
            # Remove overlay
            try:
                if self._login_overlay is not None:
                    self._login_overlay.destroy()
            except Exception:
                pass
            self._restore_main_geometry()
            self._schedule_ready_greeting()
            # Attempt VBAN preferred stream wiring
            try:
                from systems import voicemeeter as _vm

                if getattr(_vm, "VM_ENABLED", True):
                    ok, msg, chosen = _vm.vban_use_preferred(("Bjorgsun", "Stream1"))
                    self.safe_log(msg, "#55ff88" if ok else "#ffaa00")
            except Exception:
                pass
        except Exception as e:
            self.safe_log(f"Wake failed: {e}", "#ff5555")

    def _do_wake_from_usb(self):
        try:
            from runtime import boot
            from runtime import coreloop as _cl
            from runtime import startup

            try:
                self._wake_msg.config(
                    text="Waiting for U.S.B.M.K.… plug it in now.", fg="#77ccff"
                )
            except Exception:
                pass

            def _wait_then_boot():
                try:
                    path = getattr(startup, "wait_for_usb_key", lambda *a, **k: None)(
                        20.0, 0.8
                    )
                    if not path:
                        try:
                            self._wake_msg.config(
                                text="U.S.B.M.K. not found.", fg="#ffaa00"
                            )
                        except Exception:
                            pass
                        return
                    try:
                        self._wake_msg.config(
                            text=f"U.S.B.M.K. detected at {path}. Booting…",
                            fg="#55ff88",
                        )
                    except Exception:
                        pass
                    try:
                        ses_user = (
                            self._user_entry.get().strip()
                            if hasattr(self, "_user_entry")
                            else os.getenv("BJORGSUN_OWNER_NAME", "Owner")
                        )
                        setter = getattr(startup, "_set_session_user", None)
                        if callable(setter):
                            setter(
                                ses_user
                                or os.getenv("BJORGSUN_OWNER_NAME", "Owner"),
                                "owner",
                            )
                    except Exception:
                        pass
                    boot.boot_all()
                    _cl.start_background()
                    try:
                        self.root.state("zoomed")
                    except Exception:
                        pass
                    # Attempt to safely eject
                    try:
                        ok = getattr(startup, "safe_eject_drive", lambda r: False)(path)
                        if ok:
                            self.safe_log("You can safely remove U.S.B.M.K.", "#77ccff")
                    except Exception:
                        pass
                    self._awake = True
                    try:
                        if self._login_overlay is not None:
                            self._login_overlay.destroy()
                    except Exception:
                        pass
                    self._restore_main_geometry()
                    self._schedule_ready_greeting()
                except Exception as e:
                    self.safe_log(f"USB wake failed: {e}", "#ff5555")

            threading.Thread(target=_wait_then_boot, daemon=True).start()
        except Exception as e:
            self.safe_log(f"USB wake setup failed: {e}", "#ff5555")

    def _schedule_ready_greeting(self, delay_ms: int = 900):
        try:
            self.root.after(delay_ms, self._announce_ready)
        except Exception:
            # If Tk is already shutting down, attempt once synchronously
            self._announce_ready()

    def _announce_ready(self):
        if getattr(self, "_greeted", False):
            return
        if getattr(self, "_ready_line_logged", False):
            return
        if not getattr(self, "_awake", False):
            self._schedule_ready_greeting(600)
            return
        try:
            monitors = bool(getattr(coreloop, "monitors_started", False))
        except Exception:
            monitors = True
        stt_ready = True
        try:
            thread = getattr(stt, "_monitor_thread", None)
            stt_ready = bool(thread and thread.is_alive())
        except Exception:
            stt_ready = True
        if not (monitors and stt_ready):
            self._schedule_ready_greeting(700)
            return
        line = os.getenv(
            "BJORGSUN_READY_LINE", "Visual interface online. Standing by, Beurkson."
        )
        self._speak_async(line)
        self.log(line, "#99ffcc")
        self._greeted = True
        self._ready_line_logged = True

    def _refresh_hush_button(self):
        try:
            from systems import audio as _audio

            is_hush = _audio.get_hush()
        except Exception:
            is_hush = False
        try:
            if not getattr(self, "_hush_big", None):
                return
            mode = getattr(self, "_hush_big_mode", "canvas")
            if mode == "image":
                photo = self._get_hush_photo("on" if is_hush else "off")
                if photo:
                    self._hush_big.configure(image=photo)
                    self._hush_big.image = photo
                return
            if hasattr(self._hush_big, "delete"):
                txt = "UNHUSH" if is_hush else "HUSH"
                w = int(self._hush_big.winfo_width() or 96)
                h = int(self._hush_big.winfo_height() or 30)
                self._hush_big.delete("all")
                fill = "#36ffd0" if is_hush else "#ff3ea5"
                outline = "#13836f" if is_hush else "#601a45"
                theme.round_rect(
                    self._hush_big, 1, 1, w - 1, h - 1, r=10, fill=fill, outline=outline
                )
                self._hush_big.create_text(
                    w // 2,
                    h // 2,
                    text=txt,
                    fill="#0a0c10",
                    font=(theme.get_font_family(), 12, "bold"),
                )
        except Exception:
            pass

    def _open_scope(self):
        try:
            if (getattr(self, "_scope", None) is None) or (
                not self._scope.winfo_exists()
            ):
                if OscilloscopeWindow is None:
                    self.safe_log(
                        "Oscilloscope unavailable (module missing).", "#ffaa00"
                    )
                    return
                self._scope = OscilloscopeWindow(self.root)
                self.safe_log(
                    "Oscilloscope online — feeding mic levels + TTS energy.", "#55ff88"
                )
                try:
                    if getattr(self, "_tts_wave_cache", None):
                        self._scope.set_tts_wave(self._tts_wave_cache)
                except Exception:
                    pass
            else:
                try:
                    self._scope.lift()
                except Exception:
                    pass
        except Exception as e:
            self.safe_log(f"Oscilloscope error: {e}", "#ff5555")

    def _open_clock(self):
        try:
            if (getattr(self, "_clock", None) is None) or (
                not self._clock.winfo_exists()
            ):
                self._clock = ClockWindow(self.root)
            else:
                try:
                    self._clock.lift()
                except Exception:
                    pass
        except Exception as e:
            self.safe_log(f"Clock error: {e}", "#ff5555")
